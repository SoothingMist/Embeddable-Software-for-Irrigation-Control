
It is best to ready Background.pdf first to get a sense of the overall system and to see what changes were made to AquaCrop-OSPy.

Then read Running-the-Software.pdf. This discusses the system's individual modules and how to work with them. It also shows how to run the overall system, AquaCrop-OSpy, as modified.

Your comments and collaboration are welcome.

Peter G. Raeth
Senior Research Engineer
https://www.researchgate.net/profile/Peter-Raeth-2
