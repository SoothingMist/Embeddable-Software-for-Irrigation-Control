
// IrrigationSystem.cpp : This file contains the 'main' function.
// Program execution begins and ends there.

#include <iostream>
#include <string>
using namespace std;

#include "IrrigationSystemSpecific.h"

// Modified this baseline:
// https://www.delftstack.com/howto/cpp/how-to-determine-if-a-string-is-number-cpp
bool isNumber(const string& str)
{
  bool foundPeriod = false;
  bool goodNumber = true;

  for (char const& c : str)
  {
    if (c == '.')
    {
      if (foundPeriod == false) foundPeriod = true;
      else { goodNumber = false; break; }
    }
    else if (isdigit(c) == 0) { goodNumber = false; break; }
  }

  return goodNumber;
}

int main(int argc, char** argv)
{
  // Obtain the required moisture to be applied.
  double requiredMoisture = 0.0;
  if((argc == 2) && isNumber(argv[1])) requiredMoisture = stod(argv[1]);
  else
  {
    cout << "\nIncorrect specification of required moisture. Assuming 0.0." << endl;
    return -1;
  }

  // Connect to and operate the irrigation system.
  // Disconnect when finished.
  IrrigationSystemSpecific thisIrrigationSystem;
  bool connected = false;
  cout << "Required moisture: " << requiredMoisture << "mm\n";

  while (!connected)
  {
    connected = thisIrrigationSystem.connect();
    if (connected)
      connected =
      thisIrrigationSystem.OperateIrrigator(thisIrrigationSystem.MinutesToOperate(requiredMoisture));
    else
    {
      cout << "Check serial port connection with irrigation system." << endl;
      cout << "Press <enter>/<return> when ready to try again.... (waiting):";
      char thisChar;
      cin.getline(&thisChar, 1);
    }
  }

  return (int)(thisIrrigationSystem.MinutesToOperate(requiredMoisture) + 0.5);
}
