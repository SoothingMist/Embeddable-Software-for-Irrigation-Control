
#ifndef _IrrigationSystemSpecific
#define _IrrigationSystemSpecific

#include <iostream>
using namespace std;

/*
   To calculate the amount of time an irrigation system should run
   due to ETc, the estimation of soil-moisture lost duo to crop evapotranspiration,
   evaporation and crop use of moisture:

   Here is an explanation of that calculation:

   H = Hectares
   One hectare is equal to 10,000 square meters 
   One square meter is equal to 1,000 square millimeters

   ETc = evapotranspiration for the crop in millimeters

   W = (H * 10,000 * 1,000) * ETc =  Volume of water needed for to replace ETc water in field in cubic millimeters.

   F = Flowrate of water delivered to irrigation system in cubic millimeters per minute.

   W / F = M = Number of minutes that the irrigation system must be running to replenish ETc.
               An assumption here is that the field is evenly watered. We assume drip irrigation.

   For Example:
   Let H = 5; ETc = 0.5; F = 3785412 (about 1 gallon per minute);
   (5 * 10000 * 1000) * 0.5 = W = 25000000; 25000000 / 3785412 = M = 6.6 minutes.

   Another Example:
   See Dr. Isam Abdulhameed, Professor of Irrigation and Drainage Engineering, University of Anbar, Iraq
   https://www.researchgate.net/post/How-to-know-exactly-the-volume-of-water-needed-for-example-7-mm-irrigation-rate,
   ResearchGate Discussion Group in Irrigation Engineering, 6 December 2016.
*/

// Number of hectares planted with the specific crop.
const double H = 5.0;

// Flowrate of the irrigation system in millimeters per minute.
const double F = 3785412.0;

// Identify the serial port Arduino is using.
// For example: 4 refers to COM4.
const int comPort = 4;

// Baud rate to use when communicating with Arduino.
const int baudRate = 9600;

// Expected end of message
const char messageEnd = '\n';

// Indicates message timeout.
const string messageTimeout = "timeout";

class IrrigationSystemSpecific
{

public:

  // Destructor
  ~IrrigationSystemSpecific();

  // Connects the basestation to the irrigation system's microcontroller.
  // This approach assumes the microcontroller is plugged directly into the basestation.
  bool connect();

  // There are many reasons for not receiving an expected message.
  // This subroutine attempts to account for many of those.
  // (Timer Baseline: https://linuxhint.com/timer-function-cpp)
  string ReceiveMessage(double minutesToWait);

  // Causes the irrigation system to turn on for a certain length of time and then turn off.
  // Uses message confirmation to confirm connection.
  bool OperateIrrigator(double minutesToWait);

  // Minutes to operate irrigation system.
  double MinutesToOperate(double ETc) { return ((H * 10000.0 * 1000.0) * ETc) / F; }
};

#endif
