
#***
# Added this to eliminate "module not found" errors.
# AquaCrop-OSPy issues forum says this is adequate but indicates other approaches.
# This particular approach is good but causes the code to run slower.
# Although I have not tested it, my understanding is that this is not necessary in Linux,
# only in Windows.
import os
os.environ['DEVELOPMENT'] = 'DEVELOPMENT'

#***
# Import python module for working with dates and time.
import datetime
# These are necessary now in main.py.
import pandas as pd
import numpy as np

# These are standard required imports.
from aquacrop import AquaCropModel, Soil, Crop, InitialWaterContent, IrrigationManagement

#***
# An assumption is that the day this module starts is the day the crop is planted.
# Additional code is needed if another assumption is warranted.
# For datetime insights in python:
# https://www.w3schools.com/python/python_datetime.asp
# https://stackoverflow.com/questions/6871016/adding-days-to-a-date-in-python
seasonLength = 136 # maximum number of days until harvest, once crop is planted
today = datetime.datetime.now()
harvestDay = today + datetime.timedelta(days = seasonLength)

#***
# Have done away with the historical input file since a real-time weather query is used.
# This approach requires the least change to AquaCrop_OSPy's code.
# The use of an external data feed is designed to support only one planting season.
date_time_string = str(today.year) + "-" + str(today.month) + "-" + str(today.day) + " 00:00:00"
today_timestamp = pd.Timestamp(date_time_string)
date_time_string = str(harvestDay.year) + "-" + str(harvestDay.month) + "-" + str(harvestDay.day) + " 00:00:00"
harvestDay_timestamp = pd.Timestamp(date_time_string)
weather_df = pd.DataFrame(np.array([[0.0,0.0,0.0,0.0,today_timestamp],
                                    [0.0,0.0,0.0,0.0,harvestDay_timestamp]]),
      columns = ['MinTemp', 'MaxTemp', 'Precipitation', 'ReferenceET', 'Date'])

#***
# Added parameters to support testing.
today_year = today.year
harvestDay_year = harvestDay.year
model_os = AquaCropModel(
            sim_start_time = f"{today_year}" + "/" + str(today.month) + "/" + str(today.day),
            sim_end_time = f"{harvestDay_year}" + "/" + str(harvestDay.month) + "/" + str(harvestDay.day),
            irrigation_management = IrrigationManagement(irrigation_method = 4),
            weather_df = weather_df,
            soil = Soil(soil_type='SandyLoam'),
            crop = Crop('Maize',
                        planting_date = str(today.month) + "/" + str(today.day),
                        harvest_date = str(harvestDay.month) + "/" + str(harvestDay.day)),
                        initial_water_content = InitialWaterContent(value=['FC'])
        )

model_os.run_model(till_termination=True)
model_results = model_os.get_simulation_results().head()
print(model_results)
