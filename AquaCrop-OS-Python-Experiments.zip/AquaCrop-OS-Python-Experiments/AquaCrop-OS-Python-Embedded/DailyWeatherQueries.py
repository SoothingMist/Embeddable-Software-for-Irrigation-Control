
#***
# Facilitates real-time weather queries.

import pandas as pd
import numpy as np
import time
import os

# Number of seconds in 24 hours
secondsIn24hours = 24.0 * 60.0 * 60.0

# A reading is taken every 24 hours, in the evening, to minimize evaporation.
# Delay is modified by the amount of time spent operating the irrigation system.
secondsBeforeNextQuery = 0.0

# Call an executable that makes the actual query.
# That query is stored in a file.
# An option would be to translate the query code (C++) to python.
# There are also ways to call C++ from python.
# Could also set the C++ code up as an independent process queryable
# via network connection. Could even use a REST query. Lots of options.
# An option can be selected and implemented when there is time and interest.
def PerformNextQuery():
  time.sleep(secondsBeforeNextQuery) # https://www.programiz.com/python-programming/time/sleep
  AquaCrop_os = None
  QueryExecutable = 'WeatherQuery-ETo.exe'
  if os.path.exists(QueryExecutable):
    errorCode = os.system('WeatherQuery-ETo.exe')
    if errorCode == 0:
      QueryResultsFileName = "QueryResults.txt"
      if os.path.exists(QueryResultsFileName):
        QueryResultsFilePointer = open(QueryResultsFileName, "rt")
        theseQueryResults = QueryResultsFilePointer.readline()
        QueryResultsFilePointer.close()
        values = theseQueryResults.split('\t')
        AquaCrop_os = \
          np.array([float(values[3]), float(values[4]), float(values[5]),
                    float(values[6]),
                    pd.Timestamp(values[2] + '-' + values[1] + '-' + values[0] + ' 00:00:00')])
      else:
        print("Query file does not exist: " + QueryResultsFileName)
    else:
      print("Weather query was unsuccessful.")
  else:
    print("Unable to find weather-query executable: ", QueryExecutable)

  return AquaCrop_os
