
// Disables security warnings
// https://stackoverflow.com/questions/16883037/remove-secure-warnings-crt-secure-no-warnings-from-projects-by-default-in-vis
// Also had to set "SDL Checks" to NO (/sdl-)
#define _CRT_SECURE_NO_WARNINGS

#include "WeatherObservations.h"
#include "TrimString.h"
#include "AccessWebpages.h"

// https://www.boost.org
#include <boost/date_time.hpp>
using namespace boost::gregorian;

bool WeatherObservations::SummarizeLast24Hours(time_t now)
{
  currentTime = now;
  AccessWebpages thisWebpage;
  string webLink = FormQueryFromLocalUTC();

  // Get webpage from the archive of past retrievals.
  // Allows for off-line testing.
  string json = thisWebpage.RetrieveFromFile("archive.txt");

  // Get webpage from the internet.
  // Store result in archive.
  //string json = thisWebpage.RetrieveFromInternet(webLink);
  //ofstream archive("archive.txt");
  //archive << json;
  //archive.close();

  bool correct = ExtractObservations(json.c_str());
  return correct;
}

string WeatherObservations::FormQueryFromLocalUTC()
{
  // Creates a REST weblink to the US National Weather Service.
  // That link queries the last 24 hours of observations.

  // convert current date/time to tm struct for UTC
  tm* utcTime = gmtime(&currentTime);

  // Convert UTC time/date to US National Weather Service format
  // https://www.tutorialspoint.com/cplusplus/cpp_date_time.htm

  // Convert the time.

  string UTC_NWS_Time = "T";

  if (utcTime->tm_hour < 10)  UTC_NWS_Time += "0";
  UTC_NWS_Time += to_string(utcTime->tm_hour) + ":";

  if (utcTime->tm_min < 10)  UTC_NWS_Time += "0";
  UTC_NWS_Time += to_string(utcTime->tm_min) + ":";

  if (utcTime->tm_sec < 10)  UTC_NWS_Time += "0";
  UTC_NWS_Time += to_string(utcTime->tm_sec);

  UTC_NWS_Time += "Z";

  // Find yesterday's date.

  date yesterday(utcTime->tm_year + 1900, utcTime->tm_mon + 1, utcTime->tm_mday);
  yesterday -= days(1);
  string UTC_NWS_Date = to_string(yesterday.year()) + "-";

  if (yesterday.month() < 10) UTC_NWS_Date += "0";
  UTC_NWS_Date += to_string(yesterday.month()) + "-";

  if (yesterday.day() < 10) UTC_NWS_Date += "0";
  UTC_NWS_Date += to_string(yesterday.day());

  // Form the first part of the query.
  string webLink = "https://api.weather.gov/stations/" + StationCode + "/observations?start=";
  webLink += UTC_NWS_Date + UTC_NWS_Time + "&end=";

  // Add today's date/time.

  UTC_NWS_Date = to_string(utcTime->tm_year + 1900) + "-";

  if (utcTime->tm_mon < 9) UTC_NWS_Date += "0";
  UTC_NWS_Date += to_string(utcTime->tm_mon + 1) + "-";

  if (utcTime->tm_mday < 10) UTC_NWS_Date += "0";
  UTC_NWS_Date += to_string(utcTime->tm_mday);

  webLink += UTC_NWS_Date + UTC_NWS_Time;

  // Return the created REST query
  cout << "REST Query: " << webLink << endl;
  return webLink;
}

bool WeatherObservations::ExtractObservations(const char* json)
{
  // Parse the input file into a searchable data structure
  jsonDocument.Parse(json);
  if (jsonDocument.HasParseError())
  {
    cout << "Document has parse error\n" << endl;
    cout << GetParseError_En(jsonDocument.GetParseError()) << endl;
    cout << "Unable to continue" << endl;
    return false;
  }

  // Document should have an array of "features".
  // Each "feature" contains observations made at a particular date/time.
  if (jsonDocument.HasMember("features"))
  {
    const Value& features = jsonDocument["features"];
    if (features.IsArray())
    {
      int numFeatures = features.Size();

      if (numFeatures <= 0)
      {
        cout << "features array exists but it is empty" << endl;
        cout << "Unable to continue" << endl;
        return false;
      }
      else
      {
        // Initialize vector for accumulating observations.
        // json retrieval is for all readings during last 24 hours.
        for (unsigned int thisElement = 0; thisElement < totalNumElements; thisElement++)
        {
          dailyObservation[thisElement] = NAN;
          readingsCount[thisElement] = NAN;
        }

        // Accumulate all retrieved observations.
        // The json "features" array contains all observations taken over last 24 hours.
        for(int thisFeature = 0; thisFeature < numFeatures; thisFeature++)
          AddObservations(thisFeature);

        // Create the summary.
        bool correct = true;
        for (int i = MeanTempC; (i <= MeanWindSpeedKmPH) && correct; i++)
        {
          if (!isnan(readingsCount[i]))
          {
            dailyObservation[i] /= readingsCount[i];
          }
          else
          {
            correct = false;
          }
        }
        if (isnan(dailyObservation[PrecipitationMM]))
          dailyObservation[PrecipitationMM] = 0.0; // valid since non-report can mean nothing to report
        if (!correct) return false;
      }
    }
    else
    {
      cout << "features member is not an array" << endl;
      cout << "Unable to continue" << endl;
      return false;
    }
  }
  else
  {
    cout << "features member does not exist" << endl;
    cout << "Unable to continue" << endl;
    return false;
  }

  // Everything went well
  return true;
}

void WeatherObservations::AddObservations(int thisFeature)
{
  string tempString;
  double tempDouble;
  char tempCharBuffer[1024];
  size_t index2;

  const Value& geometry = jsonDocument["features"][thisFeature]["geometry"];
  const Value& properties = jsonDocument["features"][thisFeature]["properties"];

  // Extract station ID and (latitude, longitude, altitude)
  stationID = properties["rawMessage"].GetString();
  index2 = stationID.find(' ');
  stationID = stationID.substr(0, index2);

  // Extract longitude, latitude, altitude
  tempDouble = geometry["coordinates"][0].GetDouble();
  dailyObservation[LongitudeD] = tempDouble;
  sprintf(tempCharBuffer, "%.2lf", tempDouble);
  stationID += "("; stationID += tempCharBuffer;
  tempDouble = geometry["coordinates"][1].GetDouble();
  dailyObservation[LatitutdeD] = tempDouble;
  sprintf(tempCharBuffer, "%.2lf", tempDouble);
  stationID += ";"; stationID += tempCharBuffer;
  tempDouble = properties["elevation"]["value"].GetInt();
  dailyObservation[ElevationM] = tempDouble;
  sprintf(tempCharBuffer, "%d", (int)tempDouble);
  stationID += ";"; stationID += tempCharBuffer; stationID += ")";

  // Extract the temperature.
  if (!properties["temperature"]["value"].IsNull())
  {
    tempString = properties["temperature"]["qualityControl"].GetString();
    if ((tempString != "Z") && (tempString != "X") && (tempString != "Q") && (tempString != "B"))
    {
      tempDouble = properties["temperature"]["value"].GetDouble();
      if (!isnan(dailyObservation[MeanTempC]))
      {
        dailyObservation[MeanTempC] += tempDouble;
        readingsCount[MeanTempC] += 1.0;
        if (tempDouble > dailyObservation[MaxTempC]) dailyObservation[MaxTempC] = tempDouble;
        if (tempDouble < dailyObservation[MinTempC]) dailyObservation[MinTempC] = tempDouble;
      }
      else
      {
        dailyObservation[MeanTempC] = tempDouble;
        readingsCount[MeanTempC] = 1.0;
        dailyObservation[MaxTempC] = tempDouble;
        dailyObservation[MinTempC] = tempDouble;
      }
    }
  }

  // Extract the dew point.
  if (!properties["dewpoint"]["value"].IsNull())
  {
    tempString = properties["dewpoint"]["qualityControl"].GetString();
    if ((tempString != "Z") && (tempString != "X") && (tempString != "Q") && (tempString != "B"))
    {
      tempDouble = properties["dewpoint"]["value"].GetDouble();
      if (!isnan(dailyObservation[MeanDewPointC]))
      {
        dailyObservation[MeanDewPointC] += tempDouble;
        readingsCount[MeanDewPointC] += 1.0;
      }
      else
      {
        dailyObservation[MeanDewPointC] = tempDouble;
        readingsCount[MeanDewPointC] = 1.0;
      }
    }
  }

  // Extract sealevel pressure.
  if (!properties["seaLevelPressure"]["value"].IsNull())
  {
    tempString = properties["seaLevelPressure"]["qualityControl"].GetString();
    if ((tempString != "Z") && (tempString != "X") && (tempString != "Q") && (tempString != "B"))
    {
      tempDouble = properties["seaLevelPressure"]["value"].GetDouble();
      if (!isnan(dailyObservation[MeanSeaLevelP]))
      {
        dailyObservation[MeanSeaLevelP] += tempDouble;
        readingsCount[MeanSeaLevelP] += 1.0;
      }
      else
      {
        dailyObservation[MeanSeaLevelP] = tempDouble;
        readingsCount[MeanSeaLevelP] = 1.0;
      }
    }
  }

  // Extract station pressure
  if (!properties["barometricPressure"]["value"].IsNull())
  {
    tempString = properties["barometricPressure"]["qualityControl"].GetString();
    if ((tempString != "Z") && (tempString != "X") && (tempString != "Q") && (tempString != "B"))
    {
      tempDouble = properties["barometricPressure"]["value"].GetDouble();
      if (!isnan(dailyObservation[MeanStationPressureP]))
      {
        dailyObservation[MeanStationPressureP] += tempDouble;
        readingsCount[MeanStationPressureP] += 1.0;
      }
      else
      {
        dailyObservation[MeanStationPressureP] = tempDouble;
        readingsCount[MeanStationPressureP] = 1.0;
      }
    }
  }

  // Extract visibility
  if (!properties["visibility"]["value"].IsNull())
  {
    tempString = properties["visibility"]["qualityControl"].GetString();
    if ((tempString != "Z") && (tempString != "X") && (tempString != "Q") && (tempString != "B"))
    {
      tempDouble = properties["visibility"]["value"].GetDouble();
      if (!isnan(dailyObservation[MeanVisibilityM]))
      {
        dailyObservation[MeanVisibilityM] += tempDouble;
        readingsCount[MeanVisibilityM] += 1.0;
      }
      else
      {
        dailyObservation[MeanVisibilityM] = tempDouble;
        readingsCount[MeanVisibilityM] = 1.0;
      }
    }
  }

  // Extract wind speed
  if (!properties["windSpeed"]["value"].IsNull())
  {
    tempString = properties["windSpeed"]["qualityControl"].GetString();
    if ((tempString != "Z") && (tempString != "X") && (tempString != "Q") && (tempString != "B"))
    {
      tempDouble = properties["windSpeed"]["value"].GetDouble();
      if (!isnan(dailyObservation[MeanWindSpeedKmPH]))
      {
        dailyObservation[MeanWindSpeedKmPH] += tempDouble;
        readingsCount[MeanWindSpeedKmPH] += 1.0;
      }
      else
      {
        dailyObservation[MeanWindSpeedKmPH] = tempDouble;
        readingsCount[MeanWindSpeedKmPH] = 1.0;
      }
    }
  }

  // Extract precipitation over last hour
  if (!properties["precipitationLastHour"]["value"].IsNull())
  {
    tempString = properties["precipitationLastHour"]["qualityControl"].GetString();
    if ((tempString != "Z") && (tempString != "X") && (tempString != "Q") && (tempString != "B"))
    {
      tempDouble = properties["precipitationLastHour"]["value"].GetDouble();
      if (!isnan(dailyObservation[PrecipitationMM]))
      {
        dailyObservation[PrecipitationMM] += properties["precipitationLastHour"]["value"].GetDouble();
      }
      else
      {
        dailyObservation[PrecipitationMM] = properties["precipitationLastHour"]["value"].GetDouble();
      }
    }
  }
}
