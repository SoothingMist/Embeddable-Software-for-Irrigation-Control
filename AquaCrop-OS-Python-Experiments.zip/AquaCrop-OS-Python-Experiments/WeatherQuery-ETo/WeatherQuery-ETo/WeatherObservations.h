
#pragma once

#include <ctime>
#include <vector>
#include <iostream>

// https://rapidjson.org
#include "rapidjson/document.h"
#include "rapidjson/error/en.h"
using namespace rapidjson;

#include "WeatherStationSpecificData.h"

// ============================== NOTES =============================================

// To decode the special charachters in web links: https://www.w3schools.com/tags/ref_urlencode.ASP
// For testing queries, see the specifications tab at https://www.weather.gov/documentation/services-web-api#/default/get_stations__stationId__observations
// For a list of weather stations, see  ftp://ftp.ncdc.noaa.gov/pub/data/noaa/isd-history.txt 

// Per https://www.w3.org/TR/NOTE-datetime:
// Times are expressed in UTC (Coordinated Universal Time)
// Format for Complete date plus hours, minutes, and seconds:
// YYYY-MM-DDThh:mm:ssTZD (eg 1997-07-16T19:20:30+01:00) (TZD: timezone designator)

// Look here for UTC time
// https://www.timeanddate.com/worldclock

// ==================================================================================

// Vector location of specific record elements
enum
{
  LongitudeD, LatitutdeD, ElevationM, MeanTempC, MeanDewPointC, MeanSeaLevelP, MeanStationPressureP,
  MeanVisibilityM, MeanWindSpeedKmPH, MaxTempC, MinTempC, PrecipitationMM, totalNumElements
};

class WeatherObservations
{

public:

  // Guides the querying/extraction process.
  bool SummarizeLast24Hours(time_t now);

  // Extracts observations from a json record.
  bool ExtractObservations(const char* json); // parses the json record

  // Returns the vector containing the summary of the observations received.
  const double* GetDailyObservation() { return  (const double*)dailyObservation; }

private:

  double dailyObservation[totalNumElements]; // numerical version of the accumulated daily record
  double readingsCount[totalNumElements]; // counts the number of readings in each element

  // Creates a REST query of the US National Weather service
  // for the last 24 hours of daily observations.
  string FormQueryFromLocalUTC();

  // Used to parse the input file into a searchable data structure
  Document jsonDocument;

  // Accumulates the daily record
  void AddObservations(int);

  // Read from query results.
  string stationID = "";

  // Current time as passed into object.
  time_t currentTime = time(0);
};
