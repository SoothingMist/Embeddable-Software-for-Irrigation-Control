
// Disables security warnings.
#define _CRT_SECURE_NO_WARNINGS

#include "CropSpecificData.h"
using namespace std;

CropSpecificData::CropSpecificData()
{
  // If the full interpolated Kc Table is needed in a csv file, open that file here.
  consoleOutput = NULL; // fopen("KcTable.csv", "w"); // for testing

  // Calculate slopes for the Kc table.
  // The table itself is initialized in CropSpecificData.h.
  DetermineInterpolationLines();

  // Starts to fill the Kc Table file if that is wanted.
  if (consoleOutput != NULL)
  {
    fprintf(consoleOutput, "DAP,Kc\n");
  }
}

CropSpecificData::~CropSpecificData()
{
  if (consoleOutput != NULL)
  {
    fclose(consoleOutput);
    consoleOutput = NULL;
  }
}

// Calculate slopes for Kc and crop-height tables.
// The table themselves are initialized in CropSpecificData.h.
// This approach takes advantage of pointer arithmetic to directly modify matrix cell locations.
// Source: https://stackoverflow.com/questions/14015556/how-to-map-the-indexes-of-a-matrix-to-a-1-dimensional-array-c/14015582
void CropSpecificData::DetermineInterpolationLines()
{
  for (int growthPhase = 1; growthPhase < numGrowthPhases; growthPhase++)
  {
      KcTable[growthPhase][slope] =
        (KcTable[growthPhase - 1][Kc] - KcTable[growthPhase][Kc]) /
        (KcTable[growthPhase - 1][DAP] - KcTable[growthPhase][DAP]);

      KcTable[growthPhase][intersect] =
        KcTable[growthPhase - 1][Kc] -
        (KcTable[growthPhase][slope] * KcTable[growthPhase - 1][DAP]);
  }
}

// Performs interpolation on the input table.
// There is no modification of the table itself.
// The returned result is the appropriate Kc value relative to the number of days after planting.
double CropSpecificData::Interpolate(double daysAfterPlanting)
{
  // Interpolate between datapoints in the Kc table
  double interpolationResult = NAN; // "unable to calculate" if this value returned
  int growthPhase;
  for (growthPhase = 0; growthPhase < numGrowthPhases; growthPhase++)
  {
    if (daysAfterPlanting == KcTable[growthPhase][DAP])
    {
      interpolationResult = KcTable[growthPhase][Kc];
      break;
    }
    else if (daysAfterPlanting < KcTable[growthPhase][DAP])
    {
      interpolationResult =
        (KcTable[growthPhase][slope] * daysAfterPlanting) +
        KcTable[growthPhase][intersect];
      break;
    }
  }

  return interpolationResult;
}

double CropSpecificData::DetermineKc(double daysAfterPlanting)
{
  // Error Checks
  if (daysAfterPlanting < 0.0)
  {
    cout << "\nDetermineKc: days after planting cannot be less than zero." << endl;
    return -1.0;
  }
  if (daysAfterPlanting > KcTable[numGrowthPhasesMinusOne][DAP])
  {
    cout << "\nDetermineKc: days after planting cannot be greater than " <<
      KcTable[numGrowthPhasesMinusOne][DAP] << '.' << endl;
    return -1.0;
  }

  // Interpolate between datapoints in the Kc table
  double Kc = Interpolate(daysAfterPlanting);
  
  // Add data to the csv file holding the Kc Table.
  if (consoleOutput != NULL)
  {
    fprintf(consoleOutput, "%3.0lf,%.2lf\n", daysAfterPlanting, Kc);
  }
  
  return Kc;
}
