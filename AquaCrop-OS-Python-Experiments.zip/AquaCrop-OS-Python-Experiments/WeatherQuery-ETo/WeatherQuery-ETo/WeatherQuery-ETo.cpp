
// WeatherQuery-ETo.cpp : This file contains the 'main' function.
// Program execution begins and ends there.
//
// Forms a REST query of the US National Weather Service.
// Present use is to query for observations over the last 24 hours.
// These are summarized for calculating ETo.
// The result is formatted and written to a file for use by AquaCrop-OS-Python-Embedded.

// Ignoring security warnings.
#define _CRT_SECURE_NO_WARNINGS

// Enables the OS sleep function for this thread.
// https://www.softwaretestinghelp.com/cpp-sleep
#include <chrono>
#include <thread>

#include <fstream>
#include "WeatherObservations.h"
#include "CropSpecificData.h"

extern double CalculateETo(time_t currentTime, const double* dailyObservation);

int main()
{
  // Everything having to do with querying and summarizing weather data.
  WeatherObservations theseWeatherObservations;

  // Flag indicating correct run of certain subroutines.
  bool correct = false;

  // When ETo cannot be calculated, the most recent ETo is used.
  // Average ETo over previous seasons is used to initialize.
  double previousETo = 3.0; // used only if there is no previous good calculation

  // Evapotranspiration for the reference crop.
  double ETo;

  // Produces a vector summarizing the last 24 hours of observations.
  // Retrieves current date/time from host system
  // https://www.tutorialspoint.com/cplusplus/cpp_date_time.htm
  time_t currentTime = time(0);
  //cout << "Current date/time: " << ctime(&currentTime);
  correct = theseWeatherObservations.SummarizeLast24Hours(currentTime);

  // Calculate ETo.
  if (correct)
  {
    const double* dailyObserbation = theseWeatherObservations.GetDailyObservation();
    ETo = CalculateETo(currentTime, dailyObserbation);

    if (!isnan(ETo)) previousETo = ETo;
    else
    {
      //cout << "Process of summarizing observations encountered errors or NAN values." << endl;
      //cout << "Using ETo previously calculated.\n";
      ETo = previousETo;
    }
    //cout << "ETo: " << ETo << "mm\n";

    // Display query results
    tm* localTime = localtime(&currentTime);
    cout << to_string(localTime->tm_mday) << '\t';
    cout << to_string(localTime->tm_mon + 1) << '\t';
    cout << to_string(localTime->tm_year + 1900) << '\t';
    cout << to_string(dailyObserbation[MinTempC]) << '\t';
    cout << to_string(dailyObserbation[MaxTempC]) << '\t';
    cout << to_string(dailyObserbation[PrecipitationMM]) << '\t';
    cout << to_string(ETo) << '\n';

    // Store query results
    ofstream record("QueryResults.txt");
    record << to_string(localTime->tm_mday) << '\t';
    record << to_string(localTime->tm_mon + 1) << '\t';
    record << to_string(localTime->tm_year + 1900) << '\t';
    record << to_string(dailyObserbation[MinTempC]) << '\t';
    record << to_string(dailyObserbation[MaxTempC]) << '\t';
    record << to_string(dailyObserbation[PrecipitationMM]) << '\t';
    record << to_string(ETo) << '\n';
    record.close();

    return(0);
  }
  else return(1);
}
