#pragma once

// This file contains data specific to the particular weather station.
// As the code is used for different stations, this is the only
// file that should be changed.
// 
// The weather station is the US Weather Station closest to the farm.
// Although the weather data queries are targeted at a specific
// station in the US National Weather Service. If an on-farm station
// is to be substitutedm, that would require quite some work since
// different private stations use different query standards and units.

#include <string>
using namespace std;

// US National Weather Service station for which weather observations are quiered.
// In this case, we are using the station at the San Antonio Airport, Texas, USA.
// To get station codes, see ftp://ftp.ncdc.noaa.gov/pub/data/noaa/isd-history.txt
// or https://raw.githubusercontent.com/vbguyny/ws4kp/master/isd-history.txt.
// It is important to choose the station closest to the farm in question.
const string StationCode = "KSAT";

// The average hours of sunshine per day in a given month for the station in question.
// Vector gives data for Months 1..12. Index 0 is unused.
// Source: https://www.weather-atlas.com/en/texas-usa/san-antonio-climate#daylight_sunshine
// Note that we are using hours of sunshine, not hours of daylight.
// Hours of Daylight refers to the lenght of time between sunrise and sunset.
// Hours of Sunshine refers to how long the sun actually shines, relative to cloud 
// cover, fog, and other such obstructions.
const double hoursSunshinePerDay[13] =
{ 0.0, 6.4, 6.7, 6.5, 7.4, 8.0, 9.3, 10.3, 9.9, 8.4, 7.3, 5.4, 5.3 };
