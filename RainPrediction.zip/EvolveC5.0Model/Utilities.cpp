
#include <set>
using namespace std;

#include "WeatherDataIO.h"

void RunSystemCommand(string callingFunction, string SystemCommand)
{
  int exitCode = system(SystemCommand.c_str());
  if (exitCode)
  {
    cout << callingFunction <<
      ": System Command not successful. Program Terminating.\n";
    cout << "(" << SystemCommand << ")" << endl;
    exit(exitCode);
  }
}

NumericWeatherRecordType ReadNextWeatherRecord(WeatherDataIO* source)
{
  NumericWeatherRecordType weatherRecord;
  int element;

  if (!source->ParseNextWeatherRecord())
  {
    cout << "ReadNextWeatherRecord: There are no more data records\n";
    weatherRecord.clear();
  }
  else weatherRecord = source->RetrieveCurrentWeatherRecord();

  return weatherRecord;
}
