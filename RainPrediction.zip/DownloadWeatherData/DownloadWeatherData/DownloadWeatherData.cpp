// DownloadWeatherData.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
using namespace std;

// -------------------------
// Forming the Download Link
// -------------------------
//
//  https://www.ncei.noaa.gov/data/global-summary-of-the-day/access/<YYYY/<USAF+WBAN codes>.csv
//
// USAF = Air Force station ID.May contain a letter in the first position.
// WBAN = NCDC WBAN number
//
// These are given in ftp://ftp.ncdc.noaa.gov/pub/data/gsod/ish-history.txt

// Address of the data repository
string weblinkPrefix = "https://www.ncei.noaa.gov/data/global-summary-of-the-day/access";

// For: J.M.COX DAYTON INTERNATIONAL (this is the main airport for Dayton Ohio USA)
string USAFcode = "724290";
string WBANcode = "93815";

// Directory for all data storage
string dataDirectory = "../../WeatherData/";

// Year range to download
int beginYear = 1987;
int endYear = 1997;

// -------------------------

extern string AccessInternet(string internetAddress);

int main()
{
  // Check begin and end year
  beginYear = (int)fabs(beginYear);
  endYear = (int)fabs(endYear);
  if (endYear < beginYear)
  {
    cout << "endYear must be greater than beginYear. Program ending.\n";
    return 1;
  }

  // Arrange for the local consolidated archive
  char buffer[1024];
  sprintf(buffer, "%s%s%s_%d-%d.csv",
    dataDirectory.c_str(), USAFcode.c_str(), WBANcode.c_str(), beginYear, endYear);
  string localArchive = buffer;
  FILE* outputFile = fopen(localArchive.c_str(), "w"); // erases the existing archive
  if (outputFile == NULL)
  {
    cout << "Unable to open local consolidated archive. (" << localArchive << ") Program ending.\n";
    return 1;
  }
  else
  {
    fprintf(outputFile, "%s\n", "STATION,DATE,LATITUDE,LONGITUDE,ELEVATION,NAME,TEMP,TEMP_ATTRIBUTES,DEWP,DEWP_ATTRIBUTES,SLP,SLP_ATTRIBUTES,STP,STP_ATTRIBUTES,VISIB,VISIB_ATTRIBUTES,WDSP,WDSP_ATTRIBUTES,MXSPD,GUST,MAX,MAX_ATTRIBUTES,MIN,MIN_ATTRIBUTES,PRCP,PRCP_ATTRIBUTES,SNDP,FRSHTT");
    fclose(outputFile);
  }

  // Form the address and access the internet for retrieval
  for (int year = beginYear; year <= endYear; year++)
  {
    sprintf(buffer, "%4d", year);
    string weblink = weblinkPrefix + "/";
    weblink += buffer;
    weblink += "/";
    string filename = USAFcode + WBANcode + ".csv";
    weblink += filename;
    string contents = AccessInternet(weblink.c_str());

    // Put this accessed data into its own file
    sprintf(buffer, "%s_%4d.csv", (dataDirectory + USAFcode + WBANcode).c_str(), year);
    outputFile = fopen(buffer, "w");
    if (outputFile == NULL)
    {
      cout << "Unable to open storage file for this data block. (" << buffer << ") Program ending.\n";
      return 1;
    }
    else
    {
      fprintf(outputFile, "%s", contents.c_str());
      fclose(outputFile); outputFile = NULL;
    }

    // Add the accessed data to the consolidated local archive
    int index = contents.find('\n'); // removes header line
    contents = contents.substr(index + 1, contents.size());
    outputFile = fopen(localArchive.c_str(), "a");
    if (outputFile == NULL)
    {
      cout << "Unable to open archive file: (" << localArchive << ") Program ending.\n";
      return 1;
    }
    else
    {
      fprintf(outputFile, "%s", contents.c_str());
      fclose(outputFile); outputFile = NULL;
    }

    cout << "Archived Year " << year << endl;
  }

  // Finished
  cout << "Finished\n";
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
