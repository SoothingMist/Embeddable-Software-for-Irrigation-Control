// GenerateC5Records.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <set>
using namespace std;

#include "WeatherDataIO.h"

//-------------------------------
// User configuration variables
//-------------------------------

// Prefix for the input file containing daily weather data.
// Source: https://www.ncei.noaa.gov/access/search/data-search/global-summary-of-the-day
// Documentation: https://www.ncei.noaa.gov/data/global-summary-of-the-day/doc/readme.txt
string weatherDataFilePrefix = "../../WeatherData/72429093815_1987-1997";

//-------------------------------

NumericWeatherRecordType FindNextGoodWeatherRecord(WeatherDataIO *source, set<int> ignoreElements)
{
  NumericWeatherRecordType weatherRecord;
  int element;

  while (source->ParseNextWeatherRecord())
  {
    weatherRecord = source->RetrieveCurrentWeatherRecord();
    for (element = NumericElementVector::TEMP; element < NumericElementVector::PRCP; element++)
    {
      if (ignoreElements.find(element) == ignoreElements.end())
      {
        if (isnan(weatherRecord[element])) break;
      }
    }
    if (element == NumericElementVector::PRCP)
    {
      break; // good record
    }
    else
    {
      int a = 1; // bad record
    }
  }

  return weatherRecord;
}

int main()
{
  int element;
  NumericWeatherRecordType firstRecord, secondRecord, thirdRecord;

  // Arrange for elements to be ignored
  set<int> ignoreElements;
  ignoreElements.insert(NumericElementVector::GUST);

  // Gain access to source of historic weather data
  WeatherDataIO* WeatherDataSource = new WeatherDataIO(weatherDataFilePrefix);
  if (WeatherDataSource == NULL)
  {
    cout << "Unable to create link to historic weather data\n";
    return 1;
  }

  // Open file containing historic weather data.
  // Filename is given in WeatherDataIO.h
  if (!WeatherDataSource->OpenWeatherDataFile()) return 1;

  // Open the output file for the derived records to be generated.
  // Notice that the existing file is deleted.
  FILE* outputFile = fopen((weatherDataFilePrefix + "_DerivedRecords.csv").c_str(), "w");
  if (outputFile == NULL)
  {
    cout << "Unable to open output file\n";
    return 1;
  }

  // Find the first good record (record containing no NAN element values)
  firstRecord = FindNextGoodWeatherRecord(WeatherDataSource, ignoreElements);
  if (firstRecord.size() == 0)
  {
    cout << "Unable to find any good records\n";
    return 1;
  }

  // Find the second good record (record containing no NAN element values)
  secondRecord = FindNextGoodWeatherRecord(WeatherDataSource, ignoreElements);
  if (secondRecord.size() == 0)
  {
    cout << "Unable to find two good records\n";
    return 1;
  }

  // Process subsequent good records
  while (true)
  {
    // Ensure first and second records are contiguous
    while ((secondRecord[NumericElementVector::DATE] - firstRecord[NumericElementVector::DATE]) != 1)
    {
      firstRecord = secondRecord;
      secondRecord = FindNextGoodWeatherRecord(WeatherDataSource, ignoreElements);
      if (secondRecord.size() == 0)
      {
        cout << "Unable to find two contiguous first and second good records. Is likely end-of-file\n";
        return 1;
      }
    }

    // Gather the third good record.
    thirdRecord = FindNextGoodWeatherRecord(WeatherDataSource, ignoreElements);
    if (thirdRecord.size() == 0)
    {
      cout << "Unable to find a third record. Is likely end-of-file\n";
      return 1;
    }
    
    // If contiguous with the second record, create the derived vector
    if ((thirdRecord[NumericElementVector::DATE] - secondRecord[NumericElementVector::DATE]) == 1)
    {
      for (element = NumericElementVector::TEMP; element < NumericElementVector::PRCP; element++)
      {
        if (ignoreElements.find(element) == ignoreElements.end())
        {
          cout << secondRecord[element] << ',' << (secondRecord[element] - firstRecord[element]) << ',';
          fprintf(outputFile, "%8.2lf,%8.2lf,", secondRecord[element], (secondRecord[element] - firstRecord[element]));
        }
      }
      if (thirdRecord[NumericElementVector::PRCP] > 0.0)
      {
        cout << "yes";
        fprintf(outputFile, "%s", "yes");
      }
      else
      {
        cout << "no";
        fprintf(outputFile, "%s", "no");
      }
      cout << endl;
      fprintf(outputFile, "\n");
    }
    
    firstRecord = secondRecord;
    secondRecord = thirdRecord;
  }

  // Finished
  fclose(outputFile); outputFile = NULL;
  delete WeatherDataSource; WeatherDataSource = NULL;
  cout << "Finished\n";
  return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
