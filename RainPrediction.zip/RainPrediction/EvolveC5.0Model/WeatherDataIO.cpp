
// Source: https://github.com/HowardHinnant/date
// Discussion: https://howardhinnant.github.io/date/date.html
// Other Discussion: https://stackoverflow.com/questions/14218894/number-of-days-between-two-dates-c
//                   under the response, "Using this C++11/C++14 header-only date library, you can now write:..."
#include "date/date.h"
using namespace date;

#include "WeatherDataIO.h"
#include "TrimString.h"

// Call-Back Function that results from an element being extracted by libcsv.
StringWeatherRecordType stringWeatherRecord;
void extractElement(void* s, size_t length, void* data) { stringWeatherRecord.push_back((char*)s); }

NumericWeatherRecordType WeatherDataIO::RetrieveCurrentWeatherRecord() { return numericWeatherRecord; }

WeatherDataIO::~WeatherDataIO()
{
  if(weatherDataFilePointer != NULL) fclose(weatherDataFilePointer);
  csv_fini(&libcsvParser, extractElement, NULL, NULL);
  csv_free(&libcsvParser);
}

WeatherDataIO::WeatherDataIO(string prefix)
{
  weatherDataFilePointer = NULL;
  bytes_read = 0;
  stringBuffer[0] = '\0';
  weatherDataFilePrefix = prefix;

  // Initialize libcsv
  if (csv_init(&libcsvParser, CSV_APPEND_NULL) != 0)
  {
    cout << "Unable to initialize libcsvParser. Program exiting.\n";
    exit(1);
  }
}
  
bool WeatherDataIO::OpenWeatherDataFile()
{
  // Open the input datafile
  if (weatherDataFilePointer != NULL) fclose(weatherDataFilePointer);
  weatherDataFilePointer = fopen((weatherDataFilePrefix + ".csv").c_str(), "r");

  // Check if input file was opened
  if (weatherDataFilePointer == NULL)
  {
    cout << "Error opening csv input file: " << endl << weatherDataFilePrefix << endl;
    return false;
  }

  // Get header line
  if(fgets(stringBuffer, buffer_size, weatherDataFilePointer) != NULL)
  {
    bytes_read = strlen(stringBuffer);
    stringWeatherRecord.clear();

    // Parse header line
    if (csv_parse(&libcsvParser, stringBuffer, bytes_read, extractElement, NULL, NULL) != bytes_read)
    {
      fprintf(stderr, "Error while parsing file: %s\n", csv_strerror(csv_error(&libcsvParser)));
      return false;
    }

    // Briefly check header
    header = stringWeatherRecord;
    if (header.size() <= 0)
    {
      cout << "Header contains no elements\n";
      return false;
    }
    else if (header[0].compare("STATION") != 0)
    {
      cout << "Incorrect header in first line of input file: " << endl;
      cout << header[0] << " is not the correct first element in the header" << endl;
      cout << "Expecting: STATION" << endl;
      return false;
    }
  }

  // Success
  cout << "Successfully opened and read header line from csv input file:\n" << weatherDataFilePrefix << endl;
  return true;
}

bool WeatherDataIO::ParseNextWeatherRecord()
{
  // Historical weather data is archived in annual groups.
  // If several years' archives are read and made condiguous in one file,
  // there will be several headers embedded in the file,
  // one header line per year. 
  // If a header is encountered, it must be rejected.
  bool readNext = true;
  while (readNext)
  {
    stringWeatherRecord.clear();
    if (fgets(stringBuffer, buffer_size, weatherDataFilePointer) != NULL)
    {
      //cout << endl << stringBuffer << endl;
      bytes_read = strlen(stringBuffer);
      stringWeatherRecord.clear();

      // Parse this record
      if (csv_parse(&libcsvParser, stringBuffer, bytes_read, extractElement, NULL, NULL) != bytes_read)
      {
        fprintf(stderr, "Error while parsing file: %s\n", csv_strerror(csv_error(&libcsvParser)));
        return false;
      }
    }
    else
    {
      cout << "ParseNextWeatherRecord: End of File found\n";
      return false;
    }

    // Check the number of elements
    if (header.size() != stringWeatherRecord.size())
    {
      cout << "For this record, the number of elements is less than the number of elements in the header\n";
      cout << stringBuffer << endl;
      return false;
    }

    if (stringWeatherRecord[0].compare("STATION") != 0) readNext = false;
  }

  // Extract the elements needed. Convert to numeric equivalents.
  double doubleNAN = nan(""); // http://www.cplusplus.com/reference/cmath/nan-function
  numericWeatherRecord.clear();

  // Extract Year, Month, Day.
  // What gets pushed back is the number of days since 1 Jan 1900.

  auto date = year{ atoi(stringWeatherRecord[TextElementVector::DATE].substr(0, 4).c_str()) } /
    atoi(stringWeatherRecord[TextElementVector::DATE].substr(5, 2).c_str()) /
    atoi(stringWeatherRecord[TextElementVector::DATE].substr(8, 2).c_str());

  auto dateDays = sys_days(date) - sys_days(year{ 1900 } / 1 / 1);
  numericWeatherRecord.push_back((double)dateDays.count());

  /*
  // Kept this since it shows how to push_back individual year, month, day
  numericWeatherRecord.push_back(atof(stringWeatherRecord[TextElementVector::DATE].substr(0, 4).c_str()));
  numericWeatherRecord.push_back(atof(stringWeatherRecord[TextElementVector::DATE].substr(5, 2).c_str()));
  numericWeatherRecord.push_back(atof(stringWeatherRecord[TextElementVector::DATE].substr(8, 2).c_str()));
  */

  // Extract Latitude, Longitude, Elevation
  numericWeatherRecord.push_back(atof(stringWeatherRecord[TextElementVector::LATITUDE].c_str()));
  numericWeatherRecord.push_back(atof(stringWeatherRecord[TextElementVector::LONGITUDE].c_str()));
  numericWeatherRecord.push_back(atof(stringWeatherRecord[TextElementVector::ELEVATION].c_str()));

  // Mean Temperature
  if (stringWeatherRecord[TextElementVector::TEMP].compare("9999.9") == 0)
    numericWeatherRecord.push_back(doubleNAN);
  else numericWeatherRecord.push_back(atof(stringWeatherRecord[TextElementVector::TEMP].c_str()));

  // Mean Dewpoint
  if (stringWeatherRecord[TextElementVector::DEWP].compare("9999.9") == 0)
    numericWeatherRecord.push_back(doubleNAN);
  else numericWeatherRecord.push_back(atof(stringWeatherRecord[TextElementVector::DEWP].c_str()));

  // Mean Sealevel Pressure
  if (stringWeatherRecord[TextElementVector::SLP].compare("9999.9") == 0)
    numericWeatherRecord.push_back(doubleNAN);
  else numericWeatherRecord.push_back(atof(stringWeatherRecord[TextElementVector::SLP].c_str()));

  // Mean Station Pressure
  if (stringWeatherRecord[TextElementVector::STP].compare("9999.9") == 0)
    numericWeatherRecord.push_back(doubleNAN);
  else numericWeatherRecord.push_back(atof(stringWeatherRecord[TextElementVector::STP].c_str()));

  // Mean Visibility
  if (stringWeatherRecord[TextElementVector::VISIB].compare("999.9") == 0)
    numericWeatherRecord.push_back(doubleNAN);
  else numericWeatherRecord.push_back(atof(stringWeatherRecord[TextElementVector::VISIB].c_str()));

  // Mean Windspeed
  if (stringWeatherRecord[TextElementVector::WDSP].compare("999.9") == 0)
    numericWeatherRecord.push_back(doubleNAN);
  else numericWeatherRecord.push_back(atof(stringWeatherRecord[TextElementVector::WDSP].c_str()));

  // Max Sustained Wind Speed
  if (stringWeatherRecord[TextElementVector::MXSPD].compare("999.9") == 0)
    numericWeatherRecord.push_back(doubleNAN);
  else numericWeatherRecord.push_back(atof(stringWeatherRecord[TextElementVector::MXSPD].c_str()));

  // Max Wind Gust
  if (stringWeatherRecord[TextElementVector::GUST].compare("999.9") == 0)
    numericWeatherRecord.push_back(doubleNAN);
  else numericWeatherRecord.push_back(atof(stringWeatherRecord[TextElementVector::GUST].c_str()));

  // Max Temperature
  if (stringWeatherRecord[TextElementVector::MAX].compare("9999.9") == 0)
    numericWeatherRecord.push_back(doubleNAN);
  else numericWeatherRecord.push_back(atof(stringWeatherRecord[TextElementVector::MAX].c_str()));

  // Min Temperature
  if (stringWeatherRecord[TextElementVector::MIN].compare("9999.9") == 0)
    numericWeatherRecord.push_back(doubleNAN);
  else numericWeatherRecord.push_back(atof(stringWeatherRecord[TextElementVector::MIN].c_str()));

  // Precipitation
  if (stringWeatherRecord[TextElementVector::PRCP].compare("99.99") == 0)
    numericWeatherRecord.push_back(0.0);
  else numericWeatherRecord.push_back(atof(stringWeatherRecord[TextElementVector::PRCP].c_str()));

  // Successfully extracted this record's data elements
  return true;
}
