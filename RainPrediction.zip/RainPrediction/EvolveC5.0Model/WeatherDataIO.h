
#ifndef Class_WeatherDataIO
#define Class_WeatherDataIO 

#include <math.h>

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

//-------------------------------
// User configuration variables

// The input file containing daily weather data.
// Source: https://www.ncei.noaa.gov/access/search/data-search/global-summary-of-the-day
// Documentation: https://www.ncei.noaa.gov/data/global-summary-of-the-day/doc/readme.txt
//#define weatherDataFilePrefix "./72429093815_1998-2018"

//-------------------------------
// Notes

// Reading text data from file
// https://stackoverflow.com/questions/8365013/reading-line-from-text-file-and-putting-the-strings-into-a-vector

// STL string manipulation
// http://www.cplusplus.com/reference/string/string

// STL two-dimensional arrays
// https://stackoverflow.com/questions/12844475/why-cant-simple-initialize-with-braces-2d-stdarray
// http://cpptruths.blogspot.com/2011/10/multi-dimensional-arrays-in-c11.html

// STL interator example
// http://www.cplusplus.com/reference/list/list/list

// Source of original data
// https://data.noaa.gov/dataset/dataset/global-surface-summary-of-the-day-gsod

//-------------------------------

// Source: https://github.com/rgamble/libcsv
// This particular project simply adds the libcsv source files.
#include "csv.h"

// Type of record holding daily weather readings
typedef vector<double> NumericWeatherRecordType;
typedef vector<string> StringWeatherRecordType;

// Weather record element names.
// These come directly from the header.
struct TextElementVector
{
  enum {
    STATION, DATE, LATITUDE, LONGITUDE, ELEVATION, NAME, TEMP, TEMP_ATTRIBUTES, DEWP, DEWP_ATTRIBUTES, SLP,
    SLP_ATTRIBUTES, STP, STP_ATTRIBUTES, VISIB, VISIB_ATTRIBUTES, WDSP, WDSP_ATTRIBUTES, MXSPD, GUST,
    MAX, MAX_ATTRIBUTES, MIN, MIN_ATTRIBUTES, PRCP, PRCP_ATTRIBUTES, SNDP, FRSHTT, numElements
  };
};

// Not all elements in the record are needed.
// This is a numeric representation of those that are needed.
// Note: DATE, in this case, is the number of days since 1 Jan 1900.
struct NumericElementVector
{
  enum
  {
    DATE, LATITUDE, LONGITUDE, ELEVATION, TEMP, DEWP, SLP, STP, VISIB, WDSP, MXSPD, GUST,
    MAX, MIN, PRCP, numElements
  };
};

class WeatherDataIO
{

private:

  FILE *weatherDataFilePointer;
  StringWeatherRecordType header;
  NumericWeatherRecordType numericWeatherRecord;
  struct csv_parser libcsvParser;
  static const int buffer_size = 2048;
  char stringBuffer[buffer_size + 1];
  size_t bytes_read;
  string weatherDataFilePrefix;

public:

  NumericWeatherRecordType RetrieveCurrentWeatherRecord();
  bool OpenWeatherDataFile();
  bool ParseNextWeatherRecord();
  WeatherDataIO(string prefix);
  ~WeatherDataIO();
};

#endif
