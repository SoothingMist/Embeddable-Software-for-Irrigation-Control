
#include <iostream>
using namespace std;

// Calculating Kc at different crop stages based on generalized tables from the baseline document.
// Tables 11 and 12 are employed.
// There is the implied assumption that days-after-planting relates to crop stage.
// That may or may not be the case in a specific circumstance.
// That is where human-supervision comes in. The farmer should adjust for crop stage.
// This version of the code does not allow for that but that would not be impossible
// to implement if a human-oriented data interface were provided. We are not there yet.

// We use Maize Field Grain since that also is also an important crop in Ethiopia.
// Tables 11 and 12 do not have values for Teff.

// How many mm water should be available to the crop on each day.
// This is different for each crop. Table 11 says the growing period of Maize Grain is 180 days.
// Table 2 in http://www.fao.org/3/u3160e/u3160e04.htm#2.1%20water%20requirements%20of%20crops
// says the water need for Maize is 500 - 800 mm. This example uses the 800mm value.
// Thus, the daily water need for irrigation planning purposes is 800 / 180 = 4.44 (rounded).
double GetCropDailyWaterNeed() { return 4.44; }

// Average ETo for the growing season for the particular weather station location.
// This value is used in lieu of a value for previous ETo when the first weather data record
// does not yield a valid ETo calculation.
// This particular value is an average of the ETo reported by Araya in their paper, Table 1.
double GetAverageReportedETo() { return 25.17; }

double DetermineKc(double daysAfterPlanting, double meanWindSpeedMS, double minRH)
{
  // Adjustment value for partial wetting. p 119, eq 60, see also the paragraph just above the equation
  const static double Fw = 0.4; // since we assume a trickle or drip irrigation system

  // Kc Table Format: days after planting, Kc.
  // Crop: Maize (Field) (grain) (field corn)
  // Source: Table 12, p 111 in the baseline document.
  // Length of period comes from Table 11, p 106.
  // Table values for Kc are modified by this module based on the situation at hand.
  // ETo is multiplied by Kc to get ETc.
  
  // Note: https://stackoverflow.com/questions/3554205/c-multi-dimensional-array-initialization

  // Growth Phases
  enum { initial, middle, end, numGrowthPhases};

  const static int KcTeffTableLength = numGrowthPhases;
  const static int KcTeffTableLengthMinusOne = KcTeffTableLength - 1;
  const static double KcTeffTable[KcTeffTableLength][2] =
  {
     30.0, 0.30,
    140.0, 1.20,
    180.0, 0.60 // used this value assuming harvest for human consumption. see footnote 11, p 111
  };

  // Typical plant height at various growth stages.
  // Derived from Figure 1,
  // https://www.researchgate.net/publication/258104207_Influence_of_Plant_Population_and_Nitrogen-Fertilizer_at_Various_Levels_on_Growth_and_Growth_Efficiency_of_Maize/figures?lo=1
  // Their graph is for 260cm max crop height but Table 11 is for 200cm max crop height.
  // Format: DAP, Estimated Crop Height, Slope
  const static double plantHeightTable[KcTeffTableLength + 1][3] =
  {
     0.0,   0.00,  0.00,
     30.0, 115.38, 3.85,
    140.0, 188.46, 0.66,
    180.0, 200.00, 0.29
  };

  // Error Checks
  if (daysAfterPlanting < 0.0)
  {
    cout << "DetermineKc: days after planting cannot be less than zero." << endl;
    return -1.0;
  }
  else if (daysAfterPlanting >= KcTeffTable[KcTeffTableLengthMinusOne][0])
  {
    cout << "DetermineKc: days after planting cannot be greater than" <<
      KcTeffTable[KcTeffTableLengthMinusOne][0] << '.' << endl;
    return -1.0;
  }

  // Kc is initialized here to avoid an "uninitialized variable" compiler warning
  double Kc = KcTeffTable[0][1];

  int growthPhase;
  double estimatedPlantHeight;
  for (growthPhase = 0; growthPhase < numGrowthPhases; growthPhase++)
  {
    if (daysAfterPlanting <= KcTeffTable[growthPhase][0])
    {
      Kc = KcTeffTable[growthPhase][1];
      switch (growthPhase)
      {

      case initial :
        Kc = Kc * Fw;
        break;

      case middle :

        // Based on the slope of the plant-height estimating curve.
        // Background: https://cls.syr.edu/mathtuneup/grapha/Unit4/Unit4a.html
        estimatedPlantHeight =
          (plantHeightTable[growthPhase + 1][2] * (daysAfterPlanting - plantHeightTable[growthPhase][0])) +
          plantHeightTable[growthPhase][1];

        // eq 62, p 121
        // Requires minimum relative humidity but the data only gives mean dewpoint temperature.
        // Have had to settle for RH calculated from that.
        // ex 27, p 125 shows that RH is expressed as a percentage.
        // We only irrigate when the mosisture estimate shows low moisture.
        // Thus, there is no adjustment for frequency of wetting. See the discussion on p 124.
        Kc = Kc +
          (((0.04 * (meanWindSpeedMS - 2.0)) - (0.004 * (minRH - 45.0))) * pow(estimatedPlantHeight / 3.0, 0.3));

        break;

      case end :

        // Based on the slope of the plant-height estimating curve.
        // Background: https://cls.syr.edu/mathtuneup/grapha/Unit4/Unit4a.html
        estimatedPlantHeight =
          (plantHeightTable[growthPhase + 1][2] * (daysAfterPlanting - plantHeightTable[growthPhase][0])) +
          plantHeightTable[growthPhase][1];

        // eq 65, p 125
        // Requires minimum relative humidity but the data only gives mean dewpoint temperature.
        // Have had to settle for RH calculated from that.
        // The discussion on p 153 says that Kc-end is not adjusted when the table value is <= 0.45.
        if(Kc > 0.45)
          Kc = Kc +
            (((0.04 * (meanWindSpeedMS - 2.0)) - (0.004 * (minRH - 45.0))) * pow(estimatedPlantHeight / 3.0, 0.3));

        break;

      default :
        cout << "DetermineKc: Growth phase not recognized." << endl;
        Kc = -1.0;
        break;
      }
      break;
    }
  }

  return Kc;
}
