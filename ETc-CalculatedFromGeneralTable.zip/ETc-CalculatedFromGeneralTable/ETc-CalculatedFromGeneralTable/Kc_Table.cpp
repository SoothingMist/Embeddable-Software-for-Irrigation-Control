#include "Kc_Table.h"

// Disables security warnings
// https://stackoverflow.com/questions/16883037/remove-secure-warnings-crt-secure-no-warnings-from-projects-by-default-in-vis
// Set these options also: SDL Checks to NO (/sdl-) and Warning Level to Level2 (/W2)
#define _CRT_SECURE_NO_WARNINGS

Kc_Table::Kc_Table()
{
  // ============== Begin Configuration Variables ====================

  // These values are for Maize (grain) grown in East Africa.

  // How many mm water should be available to the crop on each day.
  // This is different for each crop. Table 11 says the growing period of Maize Grain is 180 days.
  // Table 2 in http://www.fao.org/3/u3160e/u3160e04.htm#2.1%20water%20requirements%20of%20crops
  // says the water need for Maize is 500 - 800 mm. This example uses the 800mm value.
  // Thus, the daily water need for irrigation planning purposes is 800 / 180 = 4.44 (rounded).
  cropDailyWaterNeed = 4.44;

  // Average ETo for the growing season for the particular weather station location.
  // This value is used in lieu of a value for previous ETo when the first weather data record
  // does not yield a valid ETo calculation.
  // This particular value is an average of the ETo experienced with this crop under these weather conditions.
  averageReportedETo = 5.41;

  // Adjustment value for partial wetting. p 119, eq 60, see also the paragraph just above the equation
  Fw = 0.4; // since we assume a trickle or drip irrigation system

  // If instrumentation output is not desired, set to NULL
  consoleOutput = fopen("ConsoleOutput.csv", "w");

  // ============== End Configuration Variables ====================

  // Calculate slopes for Kc table.
  // The table itself is initialized in Kc_Table.h.
  CalculateSlopes(KcTableValues[0], numGrowthPhases);

  // Calculate slopes for crop-height table.
  // The table itself is initialized in Kc_Table.h.
  CalculateSlopes(cropHeightTableValues[0], numGrowthPhases);

  // Check table values
  if (KcTableValues[numGrowthPhases][DAP] !=
    cropHeightTableValues[numGrowthPhases][DAP])
  {
    cout << "Be careful. The Kc and Height tables do not end on the same number of days after planting." << endl;
  }

  // Instrumentation
  if (consoleOutput != NULL)
  {
    fprintf(consoleOutput, "Kc Crop Phase,DAP,Kc\n");
  }
}

Kc_Table::~Kc_Table()
{
  if (consoleOutput != NULL)
  {
    fclose(consoleOutput);
    consoleOutput = NULL;
  }
}

double Kc_Table::GetCropDailyWaterNeed() { return cropDailyWaterNeed; }
double Kc_Table::GetAverageReportedETo() { return averageReportedETo; }

// Calculate slopes for Kc and crop-height tables.
// The table themselves are initialized in Kc_Table.h.
// This approach takes advantage of pointer arithmetic to directly modify matrix cell locations.
// Source: https://stackoverflow.com/questions/14015556/how-to-map-the-indexes-of-a-matrix-to-a-1-dimensional-array-c/14015582
void Kc_Table::CalculateSlopes(double *table, int numGrowthPhases)
{
  for (int growthPhase = 1; growthPhase <= numGrowthPhases; growthPhase++)
  {
    table[(growthPhase * tableWidth) + slope] =
      (table[(growthPhase * tableWidth) + y] - table[((growthPhase - 1) * tableWidth) + y]) /
      (table[(growthPhase * tableWidth) + DAP] - table[((growthPhase - 1) * tableWidth) + DAP]);
  }
}

// Performs interpolation on the input table.
// There is no modification of the table itself.
// The returned result is the appropriate y value relative to the number of days after planting.
double Kc_Table::Interpolate(double* table, int numGrowthPhases, double daysAfterPlanting)
{
  // Interpolate between datapoints in the Kc table
  double interpolationResult = -1.0;
  int growthPhase;
  for (growthPhase = 1; growthPhase <= numGrowthPhases; growthPhase++)
  {
    if (daysAfterPlanting <= table[(growthPhase * tableWidth) + DAP])
    {
      interpolationResult =
        (table[(growthPhase * tableWidth) + slope] *
          (daysAfterPlanting - table[((growthPhase - 1) * tableWidth) + DAP])) +
        table[((growthPhase - 1) * tableWidth) + y];
      break;
    }
  }

  return interpolationResult;
}

double Kc_Table::DetermineKc(double daysAfterPlanting, double meanWindSpeedMS, double minRH)
{
  // Error Checks
  if (daysAfterPlanting < 0.0)
  {
    cout << "\nDetermineKc: days after planting cannot be less than zero." << endl;
    return -1.0;
  }
  if (daysAfterPlanting > KcTableValues[numGrowthPhases][DAP])
  {
    cout << "\nDetermineKc: days after planting cannot be greater than " <<
      KcTableValues[numGrowthPhases][DAP] << '.' << endl;
    return -1.0;
  }

  // Interpolate between datapoints in the crop-height table.
  double estimatedCropHeight =
    Interpolate(cropHeightTableValues[0], numGrowthPhases, daysAfterPlanting);

  // Interpolate between datapoints in the Kc table
  double Kc = Interpolate(KcTableValues[0], numGrowthPhases, daysAfterPlanting);
  
  // There are three growth phases for Kc (Table 12). That will never change.
  // Thus, I am comfortable with this approach for deciding how to modify Kc.
  if (daysAfterPlanting <= KcTableValues[developmental][DAP]) // Kc initial phase
  {
    // Instrumentation
    if (consoleOutput != NULL)
    {
      fprintf(consoleOutput, "Kc Initial Phase,%3.0lf,%.2lf\n", daysAfterPlanting, Kc);
    }

    // eq 60, p 119
    Kc = Kc * Fw;
  }
  else if (daysAfterPlanting <= KcTableValues[late][DAP]) // Kc middle phase
  {
    // Instrumentation
    if (consoleOutput != NULL)
    {
      fprintf(consoleOutput, "Kc Middle Phase,%3.0lf,%.2lf\n", daysAfterPlanting, Kc);
    }

    // eq 62, p 121
    // Requires minimum relative humidity but the data only gives mean dewpoint temperature.
    // Have had to settle for RH calculated from that.
    // ex 27, p 125 shows that RH is expressed as a percentage.
    // We only irrigate when the mosisture estimate shows low moisture.
    // Thus, there is no adjustment for frequency of wetting. See the discussion on p 124.
    Kc = Kc +
      (((0.04 * (meanWindSpeedMS - 2.0)) - (0.004 * (minRH - 45.0))) * pow(estimatedCropHeight / 3.0, 0.3));
  }
  else if (daysAfterPlanting <= KcTableValues[numGrowthPhases][DAP]) // Kx end phase
  {
    // Instrumentation
    if (consoleOutput != NULL)
    {
      fprintf(consoleOutput, "Kc End Phase,%3.0lf,%.2lf\n", daysAfterPlanting, Kc);
    }

    // eq 65, p 125
    // Requires minimum relative humidity but the data only gives mean dewpoint temperature.
    // Have had to settle for RH calculated from that.
    // The discussion on p 153 says that Kc-end is not adjusted when the table value is <= 0.45.
    if (Kc > 0.45)
      Kc = Kc +
      (((0.04 * (meanWindSpeedMS - 2.0)) - (0.004 * (minRH - 45.0))) * pow(estimatedCropHeight / 3.0, 0.3));
  }
  else
  {
    cout << "\nDetermineKc: Value of daysAfterPlanting not in Kc table." << endl;
    Kc = -1.0;
  }
  
  return Kc;
}
