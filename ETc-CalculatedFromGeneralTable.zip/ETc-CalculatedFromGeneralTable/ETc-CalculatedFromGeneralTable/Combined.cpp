// Combined.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Combines ETo and Kc to obtain KTc.

#include <iostream>
#include "WeatherDataIO.h"
#include "Kc_Table.h"

extern double CalculateETo(int presentYear, int presentMonth, int presentDay, double hoursDaylight, WeatherDataRecordType thisRecord);
extern double Knots_to_MPS(double Knots);
extern double Fahrenheit_to_Celsius(double Fahrenheit);
extern double DetermineRelativeHumidity(double meanAirTempC, double meanDewPointC);

int main()
{
  Kc_Table MaizeKcTable;
  double ETo, Kc, ETc; // ETc = ETo * Kc
  double daysAfterPlanting = -1.0;
  double cropDailyWaterNeed = MaizeKcTable.GetCropDailyWaterNeed();
  double moistureAvailable = MaizeKcTable.GetCropDailyWaterNeed();

  // Identify the source of weather data.
  WeatherDataIO WeatherDataSource;
  if (!WeatherDataSource.OpenWeatherDataFile()) return -1;

  // Holds the current weather record.
  WeatherDataRecordType thisRecord;

  // Variables for the date
  int presentYear;
  int presentMonth;
  int presentDay;

  // Initialize an assumed average ETo in case the first data record is bad
  double previousETo = MaizeKcTable.GetAverageReportedETo();

  // Heading for console output
  cout << endl << "Where * appears, that indicates a NAN, invalid, value.\n";
  cout << "In such cases, ETo cannot be calculated. The previous ETo is used instead.\n";
  cout << endl  << "Year Mon Day" << '\t' << "MinTemp" << '\t' <<
    "MaxTemp" << '\t' << "VaporPressure" << '\t' << "WindSpeed" << '\t' <<
    "ActualDurationSunshine" << '\t' << "IncomingSolarRadiation" << '\t' <<
    "ETo_mm/day" << '\t' << "DAP" << '\t' << "ETc_mm/day" << endl;

  while (WeatherDataSource.GetLineWeatherData())
  {
    daysAfterPlanting += 1.0;
    thisRecord = WeatherDataSource.GetWeatherRecord();

    // Determine the present month.
    presentYear = WeatherDataSource.GetYear();
    presentMonth = WeatherDataSource.GetMonth();
    presentDay = WeatherDataSource.GetDay();

    ETo = CalculateETo
    (
      presentYear,
      presentMonth,
      presentDay,
      WeatherDataSource.GetHoursOfDaylight(presentMonth),
      thisRecord
    );

    if (ETo < 0.0) // bad data record
    {
      ETo = previousETo;
    }
    else // good data record
    {
      previousETo = ETo;
    }

    // Determine the specific Kc value for this point in the crop's growth
    double relativeHumidity =
      DetermineRelativeHumidity
      (
        Fahrenheit_to_Celsius(thisRecord[MeanTempF]), 
        Fahrenheit_to_Celsius(thisRecord[MeanDewPointF])
      );
    Kc = MaizeKcTable.DetermineKc(daysAfterPlanting, Knots_to_MPS(thisRecord[MeanWindSpeedKt]), relativeHumidity);

    // Calculate ETc
    ETc = ETo * Kc;
    printf("%3.0lf\t%.2lf\n", daysAfterPlanting, ETc);

    // Calculate need for irrigation
    // https://www.rapidtables.com/convert/length/inch-to-mm.html
    // Rain data unit is inches, need millimeters
    moistureAvailable = moistureAvailable - ETc + (thisRecord[PrecipitationIn] * 25.4);
    if (moistureAvailable < cropDailyWaterNeed)
    {
      // Say how much water is needed.
      printf("%.2lf mm water needed\n", cropDailyWaterNeed - moistureAvailable);
      moistureAvailable = cropDailyWaterNeed;
    }
  }

  // Finished
  cout << "Program Finished" << endl;
  cout << "Press <enter> to end program: ";
  string endProgram;
  getline(cin, endProgram); cout << endl; // http://www.cplusplus.com/doc/tutorial/basic_io/
  return 0;
}
