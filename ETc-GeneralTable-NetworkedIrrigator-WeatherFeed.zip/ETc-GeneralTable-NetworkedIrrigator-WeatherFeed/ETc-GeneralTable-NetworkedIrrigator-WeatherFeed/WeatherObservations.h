
#pragma once

// https://rapidjson.org
#include "rapidjson/document.h"
#include "rapidjson/error/en.h"
using namespace rapidjson;

#include <string>
using namespace std;

// Vector location of specific record elements.
// Elements SNDP and FRSHTT are not used by the target program.
enum
{
  MeanTempC, MeanTempC_count, MeanDewPointC, MeanDewPointC_count, MeanSeaLevelPa, MeanSeaLevelPa_count,
  MeanStationPressurePa, MeanStationPressurePa_count, MeanVisibilityM, MeanVisibilityM_count,
  MeanWindSpeedKmh, MeanWindSpeedKmh_count,
  MaxSustainedWindSpeedKmh, MaxWindGustKmh, MaxTempC, MinTempC, PrecipitationM, LastObservation
};

class WeatherObservations
{
public:
  bool ExtractObservations(const char* json); // parses the json record

  // Returns a copy of the string version of a record compatible with historical records
  string GetCompatibleRecord() { return compatibleRecord; } 

private:
  Document document; // retrieved json record
  double dailyObservation[LastObservation]; // numerical version of the accumulated daily record
  bool AddObservations(int thisFeature); // accumulates the daily record
  void ConvertUnits(); // convert metric to British units, historical data is in British units
  string stationID = ""; // assumes the station location is static
  string dateTime = "";  // from the most recent "feature" member, indicates data over previous 24 hours
  string compatibleRecord = ""; // the version of the accumulated record that is compatible with historical records
};
