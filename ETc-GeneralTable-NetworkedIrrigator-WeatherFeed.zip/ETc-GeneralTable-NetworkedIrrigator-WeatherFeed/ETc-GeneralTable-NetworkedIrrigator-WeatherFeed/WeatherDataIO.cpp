
#include "WeatherDataIO.h"
#include "TrimString.h"
#include "WeatherObservations.h"

extern string AccessInternet(string internetAddress);
extern string ReadJasonFromFile(string filename);
extern string FormQueryFromSpecifiedTimeRange(string stationCode, string beginDateTime, string endDateTime);
extern string FormQueryFromLocalUTC(string stationCode);

double WeatherDataIO::GetHoursOfDaylight(int month) { return hoursSunshinePerDay[month]; }
WeatherDataRecordType WeatherDataIO::GetWeatherRecord() { return thisRecord; }
int WeatherDataIO::GetYear() { return year; }
int WeatherDataIO::GetMonth() { return month; }
int WeatherDataIO::GetDay() { return day; }

WeatherDataIO::WeatherDataIO()
{
  year = -1;
  month = -1;
  day = -1;
  for(size_t i = 0; i < totalNumElements; i++) thisRecord.push_back(-999.0);
}

string WeatherDataIO::QueryForWeatherObservations()
{
  // For picking apart json data structures
  WeatherObservations theseWeatherObservations;

  // Read json-structured weather-data from a file.
  // This was originally for testing but is left here in case it is needed again.
  //string filename = "../WeatherData/response_1603725296592_20201019.json";
  //string contents = ReadJasonFromFile(filename);

  // ================================================================================
  // For creating a REST web query to retrieve json-structured weather-data
  //
  // To decode the special charachters in web links: https://www.w3schools.com/tags/ref_urlencode.ASP
  // For testing queries, see the specifications tab at https://www.weather.gov/documentation/services-web-api#/default/get_stations__stationId__observations
  // For a list of weather stations, see  ftp://ftp.ncdc.noaa.gov/pub/data/noaa/isd-history.txt 
  //
  // Per https://www.w3.org/TR/NOTE-datetime:
  // Times are expressed in UTC (Coordinated Universal Time)
  // Format for Complete date plus hours, minutes, and seconds:
  // YYYY-MM-DDThh:mm:ssTZD (eg 1997-07-16T19:20:30+01:00) (TZD: timezone designator)
  //
  // Per https://www.timeanddate.com/worldclock/usa/dayton:
  // Dayton Ohio USA is UTC/GMT -4 hours, so 1997-07-16T19:20:30-04:00, if using local rather than UTC time.
  //
  // To get station codes, see ftp://ftp.ncdc.noaa.gov/pub/data/noaa/isd-history.txt
  //
  // Retrieving by user-specified begin and end times
  // This was originally for testing but is left here in case it is needed again.
  //string webLink =
  //  FormQueryFromSpecifiedTimeRange("KDAY", "2020-10-19T09:00:00-04:00", "2020-10-20T09:00:00-04:00");
  //
  // Retrieving by local UTC time.
  // This is what is envisioned as the normal query.
  // The general idea is to decide, at sundown, if the irrigator should be activated.
  // In that way, irrigation takes place at a time when immediate evaporation is less likely.
  string webLink = FormQueryFromLocalUTC("KDAY");
  // 
  // Issue the query
  string contents = AccessInternet(webLink.c_str());
  // ================================================================================

  // Save retrieval to archive
  FILE* archive = NULL;
  archive = fopen("../WeatherData/archive.txt", "w");
  if (archive != NULL)
  {
    fprintf(archive, "%s\n", contents.c_str());
    fclose(archive);
    archive = NULL;
  }
  else printf("Unable to open archive storage file. Program continues.");

  // Parse the json document and extract the required data
  const char* json;
  json = contents.c_str();
  bool success = theseWeatherObservations.ExtractObservations(json);

  // Finished
  string compatibleRecord;
  if (success)
  {
    compatibleRecord = theseWeatherObservations.GetCompatibleRecord();
    //cout << "Finished Successfully\n";
  }
  else
  {
    compatibleRecord = "";
    cout << "Unable to extract compatible weather record\n";
  }

  return compatibleRecord;
}

bool WeatherDataIO::GetLineWeatherData()
{
  // Holds the line of weather data
  string line;

  // Process each line of data
  line = QueryForWeatherObservations();
  if (line.compare("") != 0) // http://www.cplusplus.com/reference/string/string/compare/
  {
    size_t index1, index2;
    string elementString;
    string lineID;
    size_t thisElement = 0;

    line = removeAllSpaces(line);

    // Extract the line's Station ID, WBAN code, and YearMonthDay
    index2 = line.find(',');
    index2 = line.find(',', index2 + 1);
    index2 = line.find(',', index2 + 1);
    lineID = line.substr(0, index2);
    lineID = replaceCharacters(lineID, ",", " ");

    // Extract Year, Month, Day as seperate numbers
    index1 = lineID.rfind(" ");
    index1++;
    year = atoi(lineID.substr(index1, 4).c_str());
    index1 += 4;
    month = atoi(lineID.substr(index1, 2).c_str());
    index1 += 2;
    day = atoi(lineID.substr(index1, 2).c_str());

    // Extract the mean temperature
    index1 = index2 + 1;
    index2 = line.find(',', index1);
    elementString = line.substr(index1, index2 - index1);
    if (elementString.find("999.9") != string::npos) thisRecord[thisElement] = NAN;
    else thisRecord[thisElement] = stof(elementString);
    index2 = line.find(',', index2 + 1); // skip the count

    // Extract the mean dew point
    thisElement++;
    index1 = index2 + 1;
    index2 = line.find(',', index1);
    elementString = line.substr(index1, index2 - index1);
    if (elementString.find("999.9") != string::npos) thisRecord[thisElement] = NAN;
    else thisRecord[thisElement] = stof(elementString);
    index2 = line.find(',', index2 + 1); // skip the count

    // Extract the mean sea level pressure
    thisElement++;
    index1 = index2 + 1;
    index2 = line.find(',', index1);
    elementString = line.substr(index1, index2 - index1);
    if (elementString.find("999.9") != string::npos) thisRecord[thisElement] = NAN;
    else thisRecord[thisElement] = stof(elementString);
    index2 = line.find(',', index2 + 1); // skip the count

    // Extract the mean station pressure
    thisElement++;
    index1 = index2 + 1;
    index2 = line.find(',', index1);
    elementString = line.substr(index1, index2 - index1);
    if (elementString.find("999.9") != string::npos) thisRecord[thisElement] = NAN;
    else thisRecord[thisElement] = stof(elementString);
    index2 = line.find(',', index2 + 1); // skip the count

    // Extract the mean visibility
    thisElement++;
    index1 = index2 + 1;
    index2 = line.find(',', index1);
    elementString = line.substr(index1, index2 - index1);
    if (elementString.find("999.9") != string::npos) thisRecord[thisElement] = NAN;
    else thisRecord[thisElement] = stof(elementString);
    index2 = line.find(',', index2 + 1); // skip the count

    // Extract the mean wind speed
    thisElement++;
    index1 = index2 + 1;
    index2 = line.find(',', index1);
    elementString = line.substr(index1, index2 - index1);
    if (elementString.find("999.9") != string::npos) thisRecord[thisElement] = NAN;
    else thisRecord[thisElement] = stof(elementString);
    index2 = line.find(',', index2 + 1); // skip the count

    // Extract max sustained wind speed
    thisElement++;
    index1 = index2 + 1;
    index2 = line.find(',', index1);
    elementString = line.substr(index1, index2 - index1);
    if (elementString.find("999.9") != string::npos) thisRecord[thisElement] = NAN;
    else thisRecord[thisElement] = stof(elementString);

    // Extract max wind gust
    thisElement++;
    index1 = index2 + 1;
    index2 = line.find(',', index1);
    elementString = line.substr(index1, index2 - index1);
    if (elementString.find("999.9") != string::npos) thisRecord[thisElement] = NAN;
    else thisRecord[thisElement] = stof(elementString);

    // Extract max temperature
    // Note the removal of the possible flag
    thisElement++;
    index1 = index2 + 1;
    index2 = line.find(',', index1);
    elementString = line.substr(index1, index2 - index1);
    if (!isdigit((elementString.substr(elementString.size() - 1, 1).c_str())[0]))
      elementString = elementString.substr(0, elementString.size() - 1);
    if (elementString.find("999.9") != string::npos) thisRecord[thisElement] = NAN;
    else thisRecord[thisElement] = stof(elementString);

    // Extract min temperature
    // Note the removal of the possible flag
    thisElement++;
    index1 = index2 + 1;
    index2 = line.find(',', index1);
    elementString = line.substr(index1, index2 - index1);
    if (!isdigit((elementString.substr(elementString.size() - 1, 1).c_str())[0]))
      elementString = elementString.substr(0, elementString.size() - 1);
    if (elementString.find("999.9") != string::npos) thisRecord[thisElement] = NAN;
    else thisRecord[thisElement] = stof(elementString);

    // Extract precipitation
    thisElement++;
    index1 = index2 + 1;
    index2 = line.find(',', index1);
    elementString = line.substr(index1, index2 - index1);
    if ((elementString.find("999.9") != string::npos) || (elementString.find("99.99") != string::npos))
    {
      thisRecord[thisElement] = 0.0; // in this case, non-reporting often means nothing to report, thus 0.0
    }
    else thisRecord[thisElement] = stof(elementString.substr(0, elementString.length() - 1)); // remove flag

    // Have successfully extracted this record's data elements
    return true;
  }
  else
  {
    cout << "Did not find any weather observations" << endl;
    return false;
  }
}
