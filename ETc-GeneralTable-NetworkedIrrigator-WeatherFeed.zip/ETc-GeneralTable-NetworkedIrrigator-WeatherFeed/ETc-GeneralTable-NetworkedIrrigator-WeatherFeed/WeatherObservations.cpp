
#include "WeatherObservations.h"
#include "TrimString.h"

#include <iostream>
using namespace std;

// Disables security warnings
// https://stackoverflow.com/questions/16883037/remove-secure-warnings-crt-secure-no-warnings-from-projects-by-default-in-vis
// Also had to set "SDL Checks" to NO (/sdl-)
// Also had to set "Warning Level" to 2 (/W2)
#define _CRT_SECURE_NO_WARNINGS

// ============================ Conversion Formulae =================================
//
// The real-time feed is in metric, whereas the historical data is in British units.
// The analysis software is designed to work with historical data.
// Thus, it is necessary to convert metric units to British units.

// https://www.rapidtables.com/convert/temperature/celsius-to-fahrenheit.html
#define CelsiusToFahrenheit(C) ((C * 9.0) / 5.0) + 32.0

// https://www.metric-conversions.org/pressure/millibar-conversion.htm
#define MillibarsToPascal(MB) MB / 100.0

// https://www.metric-conversions.org/length/meters-to-miles.htm
#define MetersToMiles(M) M * 0.00062137

// https://www.ginifab.com/feeds/miles_to_km/kph_to_mph.html
#define KmhToKnots(KMH) 1.852 * KMH

// https://www.metric-conversions.org/length/meters-to-inches.htm
#define MetersToInches(M) M * 39.370

// ===================================================================================

void WeatherObservations::ConvertUnits()
{
  if (dailyObservation[MeanTempC_count] > 0)
  {
    dailyObservation[MeanTempC] = CelsiusToFahrenheit(dailyObservation[MeanTempC]);
    dailyObservation[MaxTempC] = CelsiusToFahrenheit(dailyObservation[MaxTempC]);
    dailyObservation[MinTempC] = CelsiusToFahrenheit(dailyObservation[MinTempC]);
  }

  if (dailyObservation[MeanDewPointC_count] > 0)
    dailyObservation[MeanDewPointC] = CelsiusToFahrenheit(dailyObservation[MeanDewPointC]);

  if (dailyObservation[MeanSeaLevelPa_count] > 0)
    dailyObservation[MeanSeaLevelPa] = MillibarsToPascal(dailyObservation[MeanSeaLevelPa]);

  if (dailyObservation[MeanStationPressurePa_count] > 0)
    dailyObservation[MeanStationPressurePa] = MillibarsToPascal(dailyObservation[MeanStationPressurePa]);

  if (dailyObservation[MeanVisibilityM_count] > 0)
    dailyObservation[MeanVisibilityM] = MetersToMiles(dailyObservation[MeanVisibilityM]);

  if (dailyObservation[MeanWindSpeedKmh_count] > 0)
    dailyObservation[MeanWindSpeedKmh] = KmhToKnots(dailyObservation[MeanWindSpeedKmh]);

  dailyObservation[PrecipitationM] = MetersToInches(dailyObservation[PrecipitationM]);
}

bool WeatherObservations::ExtractObservations(const char* json)
{
  char tempCharBuffer[1024];
  compatibleRecord = "";

  // Parse the input file into a searchable data structure
  document.Parse(json);
  if (document.HasParseError())
  {
    cout << "Document has parse error\n" << endl;
    cout << GetParseError_En(document.GetParseError()) << endl;
    cout << "Unable to continue" << endl;
    return false;
  }

  // Document should have an array of "features".
  // Each "feature" contains observations made at a particular date/time.
  if (document.HasMember("features"))
  {
    const Value& features = document["features"];
    if (features.IsArray())
    {
      int numFeatures = features.Size();

      if (numFeatures <= 0)
      {
        cout << "features array exists but it is empty" << endl;
        cout << "Unable to continue" << endl;
        return false;
      }
      else
      {
        bool success;
        int thisObservation, thisFeature;

        // Initialize vector for accumulating observations.
        // json retrieval is for all readings during last 24 hours.
        for (thisObservation = 0; thisObservation < LastObservation; thisObservation++)
          dailyObservation[thisObservation] = 0.0;
        dailyObservation[MaxSustainedWindSpeedKmh] = -1.0;
        dailyObservation[MaxWindGustKmh] = -1.0;
        dailyObservation[MaxTempC] = -1.0;
        dailyObservation[MinTempC] = 99999.9;

        // Accumulate all retrieved observations.
        // The json "features" array contains all observations taken over last 24 hours.
        for (thisFeature = numFeatures - 1; thisFeature >= 0; thisFeature--)
          bool success = AddObservations(thisFeature);

        // Create a vector that is compatible with historical-record vectors

        if (dailyObservation[MeanTempC_count] <= 0.0)
          dailyObservation[MeanTempC] = 9999.9;
        else
          dailyObservation[MeanTempC] = dailyObservation[MeanTempC] / dailyObservation[MeanTempC_count];

        if (dailyObservation[MeanDewPointC_count] <= 0.0)
          dailyObservation[MeanDewPointC] = 9999.9;
        else
          dailyObservation[MeanDewPointC] = dailyObservation[MeanDewPointC] / dailyObservation[MeanDewPointC_count];

        if (dailyObservation[MeanSeaLevelPa_count] <= 0.0)
          dailyObservation[MeanSeaLevelPa] = 9999.9;
        else
          dailyObservation[MeanSeaLevelPa] = dailyObservation[MeanSeaLevelPa] / dailyObservation[MeanSeaLevelPa_count];

        if (dailyObservation[MeanStationPressurePa_count] <= 0.0)
          dailyObservation[MeanStationPressurePa] = 9999.9;
        else
          dailyObservation[MeanStationPressurePa] = dailyObservation[MeanStationPressurePa] / dailyObservation[MeanStationPressurePa_count];

        if (dailyObservation[MeanVisibilityM_count] <= 0.0)
          dailyObservation[MeanVisibilityM] = 999.9;
        else
          dailyObservation[MeanVisibilityM] = dailyObservation[MeanVisibilityM] / dailyObservation[MeanVisibilityM_count];

        if (dailyObservation[MeanWindSpeedKmh_count] <= 0.0)
          dailyObservation[MeanWindSpeedKmh] = 999.9;
        else
          dailyObservation[MeanWindSpeedKmh] = dailyObservation[MeanWindSpeedKmh] / dailyObservation[MeanWindSpeedKmh_count];

        if (dailyObservation[MaxSustainedWindSpeedKmh] <= 0.0) dailyObservation[MaxSustainedWindSpeedKmh] = 999.9;
        if (dailyObservation[MaxWindGustKmh] <= 0.0) dailyObservation[MaxWindGustKmh] = 999.9;
        if (dailyObservation[MeanTempC_count] == 0.0)
        {
          dailyObservation[MaxTempC] = 999.9;
          dailyObservation[MinTempC] = 999.9;
        }

        // Write out the complete record
        sprintf(tempCharBuffer, "%s,99999,%s", stationID.c_str(), dateTime.c_str());
        for (int i = 0; i < PrecipitationM; i++)
          sprintf(tempCharBuffer + strlen(tempCharBuffer), ",%.1lf", dailyObservation[i]);
        sprintf(tempCharBuffer + strlen(tempCharBuffer), ",%.1lf*", dailyObservation[PrecipitationM]);

        // Units are metric, whereas the processing software expects British units.
        // We therefore convert the units prior to output.
        ConvertUnits();

        // Write out the complete record
        sprintf(tempCharBuffer, "%s,99999,%s", stationID.c_str(), dateTime.c_str());
        for (int i = 0; i < PrecipitationM; i++)
          sprintf(tempCharBuffer + strlen(tempCharBuffer), ",%.1lf", dailyObservation[i]);
        sprintf(tempCharBuffer + strlen(tempCharBuffer), ",%.1lf*", dailyObservation[PrecipitationM]);

        compatibleRecord = tempCharBuffer;
      }
    }
    else
    {
      cout << "features member is not an array" << endl;
      cout << "Unable to continue" << endl;
      return false;
    }
  }
  else
  {
    cout << "features member does not exist" << endl;
    cout << "Unable to continue" << endl;
    return false;
  }

  // Success
  return true;
}

bool WeatherObservations::AddObservations(int thisFeature)
{
  string tempString;
  double tempDouble;
  char tempCharBuffer[1024];
  int index1, index2;

  const Value& geometry = document["features"][thisFeature]["geometry"];
  const Value& properties = document["features"][thisFeature]["properties"];

  // Extract the station ID and (latitude, longitude, altitude)
  stationID = properties["rawMessage"].GetString();
  index2 = stationID.find(' ');
  stationID = stationID.substr(0, index2);
  tempDouble = geometry["coordinates"][0].GetDouble();
  sprintf(tempCharBuffer, "%.2lf", tempDouble);
  stationID += "("; stationID += tempCharBuffer;
  tempDouble = geometry["coordinates"][1].GetDouble();
  sprintf(tempCharBuffer, "%.2lf", tempDouble);
  stationID += ";"; stationID += tempCharBuffer;
  tempDouble = properties["elevation"]["value"].GetInt();
  sprintf(tempCharBuffer, "%d", (int)tempDouble);
  stationID += ";"; stationID += tempCharBuffer; stationID += ")";

  // Extract date and time. Note that time is in GMT.
  // Historical data does not have the time because that data is daily averages, minimum, and maximum.
  // However, the date format produced here is the same so extraction by other programs is no problem.
  dateTime = properties["timestamp"].GetString();
  dateTime = replaceCharacters(dateTime, "-", "");

  // Extract the temperature.
  if (!properties["temperature"]["value"].IsNull())
  {
    double tempC = properties["temperature"]["value"].GetDouble();
    dailyObservation[MeanTempC] += tempC;
    dailyObservation[MeanTempC_count] += 1.0;
    if (tempC > dailyObservation[MaxTempC]) dailyObservation[MaxTempC] = tempC;
    if (tempC < dailyObservation[MinTempC]) dailyObservation[MinTempC] = tempC;
  }

  // Extract the dew point.
  if (!properties["dewpoint"]["value"].IsNull())
  {
    dailyObservation[MeanDewPointC] += properties["dewpoint"]["value"].GetDouble();
    dailyObservation[MeanDewPointC_count] += 1.0;
  }

  // Extract sealevel pressure.
  if (!properties["seaLevelPressure"]["value"].IsNull())
  {
    dailyObservation[MeanSeaLevelPa] += properties["seaLevelPressure"]["value"].GetDouble();
    dailyObservation[MeanSeaLevelPa_count] += 1.0;
  }

  // Extract station pressure
  if (!properties["barometricPressure"]["value"].IsNull())
  {
    dailyObservation[MeanStationPressurePa] += properties["barometricPressure"]["value"].GetDouble();
    dailyObservation[MeanStationPressurePa_count] += 1.0;
  }

  // Extract visibility
  if (!properties["visibility"]["value"].IsNull())
  {
    dailyObservation[MeanVisibilityM] += properties["visibility"]["value"].GetDouble();
    dailyObservation[MeanVisibilityM_count] += 1.0;
  }

  // Extract wind speed
  if (!properties["windSpeed"]["value"].IsNull())
  {
    dailyObservation[MeanWindSpeedKmh] += properties["windSpeed"]["value"].GetDouble();
    dailyObservation[MeanWindSpeedKmh_count] += 1.0;
  }

  // Extract max sustained wind speed (not given in this dataset)
  dailyObservation[MaxSustainedWindSpeedKmh] = 9999.9;

  // Extract wind gust
  if (!properties["windGust"]["value"].IsNull())
  {
    tempDouble = properties["windGust"]["value"].GetDouble();
    if(tempDouble > dailyObservation[MaxWindGustKmh]) dailyObservation[MaxWindGustKmh] = tempDouble;
  }

  /*
  * Have found these values are often all null even though there are individual temperature readings.
  * So, am ignoring these values but retaining the code.
  * Comparison with historical data has gone well.
  // Extract max temp over last 24 hours
  if (!properties["maxTemperatureLast24Hours"]["value"].IsNull())
  {
    tempDouble = properties["maxTemperatureLast24Hours"]["value"].GetDouble();
    if(tempDouble > dailyObservation[MaxTempC]) dailyObservation[MaxTempC] = tempDouble;
  }

  // Extract min temp over last 24 hours
  if (!properties["minTemperatureLast24Hours"]["value"].IsNull())
  {
    tempDouble = properties["minTemperatureLast24Hours"]["value"].GetDouble();
    if(tempDouble < dailyObservation[MinTempC]) dailyObservation[MinTempC] = tempDouble;
  }
  */

  // Extract precipitation over last hour
  if (!properties["precipitationLastHour"]["value"].IsNull())
    dailyObservation[PrecipitationM] += properties["precipitationLastHour"]["value"].GetDouble();

  return true;
}
