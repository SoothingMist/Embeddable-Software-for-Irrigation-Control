//
// Caculate latitude in decimal degrees from minutes, seconds, and hemisphere
//
#include <math.h>

// p 46, ex 7
// If the latitude is North, minutes and seconds are calculated with positive numbers.
// If the latitude is South, minutes and seconds are calculated with negative numbers.
double LatitudeDecimalDegrees(double minutes, double seconds, char hemisphere)
{
  minutes = fabs(minutes);
  seconds = fabs(seconds);
  if ((hemisphere == 's') || (hemisphere == 'S'))
  {
    minutes = -minutes;
    seconds = -seconds;
  }
  return minutes + (seconds / 60.0);
}
