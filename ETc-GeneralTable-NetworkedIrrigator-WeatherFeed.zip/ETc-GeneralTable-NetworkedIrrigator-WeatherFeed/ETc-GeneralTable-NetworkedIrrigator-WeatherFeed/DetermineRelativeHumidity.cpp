
# include <math.h>

double DetermineRelativeHumidity(double meanAirTempC, double meanDewPointC)
{
  // eq 11, p 36
  double saturationVaporPressure =
    0.6108 * exp((17.27 * meanAirTempC) / (meanAirTempC + 237.3));

  // eq 14, p 37
  double actualVaporPressure =
    0.6108 * exp((17.27 * meanDewPointC) / (meanDewPointC + 237.3));

  // eq 10, p 35
  double relativeHumidity;
  if (actualVaporPressure > saturationVaporPressure) relativeHumidity = 1.0;
  else relativeHumidity = actualVaporPressure / saturationVaporPressure;

  return 100.0 * relativeHumidity;
}