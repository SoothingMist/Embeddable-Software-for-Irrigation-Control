
#pragma once

#include <iostream>
using namespace std;

class Kc_Table
{
public:
  Kc_Table();
  ~Kc_Table();
  double GetCropDailyWaterNeed();
  double GetAverageReportedETo();
  double DetermineKc(double daysAfterPlanting, double meanWindSpeedMS, double minRH);

private:

  // Originally used for testing purposes.
  FILE* consoleOutput;

  // Specification for interpolation tables.
  // tableWidth is the number of columns.
  // DAP: days after planting.
  // y is either a given Kc or crop-height, depending on Table 11 or 12.
  enum { DAP, y, slope, tableWidth };

  // Growth Phases.
  // Nomenclature comes from Table 11.
  enum { initial, developmental, middle, late, numGrowthPhases };

  double cropDailyWaterNeed;
  double averageReportedETo;
  double Fw; // partial field wetting value

  void CalculateSlopes(double *table, int numGrowthPhases);
  double Interpolate(double* table, int numGrowthPhases, double daysAfterPlanting);

  // ============== Begin Configuration Variables ====================

  // These tables are for Sweet Corn. There are numerous varieties.
  // See https://en.wikipedia.org/wiki/List_of_sweetcorn_varieties.
  // FAO Table 11 and 12 for Maize (sweet) in Idaho was used in liu of data for Ohio.
  // Crop height data came from Table 1 in
  // https://www.researchgate.net/publication/338465172_Application_Legume_Compost_with_Bio-Activator_Trichoderma_sp_as_Inorganic_Fertilizer_Substitution_in_Sweet_Corn_Zea_mays_L_Saccharata_Cultivation

  // Look-up table for Kc relative to the number of days after planting.
  // There is the implied assumption that days-after-planting relates to crop stage.
  // That may or may not be the case in a specific circumstance.
  // That is where human-supervision comes in. The farmer should adjust for crop stage.
  // This version of the code does not allow for that but that would not be impossible
  // to implement if a human-oriented data interface were provided. We are not there yet.
  //
  // Calculating Kc at different crop stages based on generalized tables from the baseline document.
  // Tables 11 and 12 are employed.
  // There is the implied assumption that days-after-planting relates to crop stage.
  // That may or may not be the case in a specific circumstance.
  // That is where human-supervision comes in. The farmer should adjust for crop stage.
  // This version of the code does not allow for that but that would not be impossible
  // to implement if a human-oriented data interface were provided. We are not there yet.
  //
  // The Kc table's basic format is fixed:
  // days after planting (DAP), Kc, slope
  // (slope entered as 0.0 since it is calculated by the class constructor)
  // See FAO Fig 34, p 126 for how to get Kc values by combining Table 12, Page 110, and Table 11, Page 104.
  // An implied assumption is that the crop is harvested after the total growth period.
  double KcTableValues[numGrowthPhases + 1][tableWidth] =
  {
      0.0,0.300,0.0, // init
     30.0,0.300,0.0, // init
     60.0,0.725,0.0, // developmental
     90.0,1.150,0.0, // middle
    100.0,1.050,0.0  // late
  };

  // Typical crop height in meters at various growth stages.
  // Derived from Table 1,
  // https://www.researchgate.net/publication/338465172_Application_Legume_Compost_with_Bio-Activator_Trichoderma_sp_as_Inorganic_Fertilizer_Substitution_in_Sweet_Corn_Zea_mays_L_Saccharata_Cultivation
  // Their table does not cover the entire crop growth period, just the initial stage.
  // Clearly, better information on the crop is needed, including relating to the variety at hand.
  // Since there is no height data in the baseline document, we use the chart in the link as best we can.
  // The software will adapt to whatever table values are used.
  // Format: DAP, Estimated Crop Height (meters), Slope
  // (slope entered as 0.0 since it is calculated by the class constructor)
  double cropHeightTableValues[numGrowthPhases + 1][tableWidth] =
  {
      0.0,0.0000,0.0, // always zeros
     21.0,0.3064,0.0, // init
     28.0,0.3716,0.0, // init
     35.0,0.7004,0.0, // init
    100.0,1.5000,0.0  // developmental, middle, late
  };
};
