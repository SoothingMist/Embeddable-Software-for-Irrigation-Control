
#ifndef Class_WeatherDataIO
#define Class_WeatherDataIO 

// ============== Begin Configuration Variables ====================

// Physical location of the weather station.
// Longitude is not required for these calculations.
// Station location and elevation are given in:
// ftp://ftp.ncdc.noaa.gov/pub/data/noaa/isd-history.txt
// Latitude units are degrees. Elevation units are meters above sealevel.
// Positive latitude refers to north. Negative refers to south.
// Positive longitude refers to east. Negative refers to west.
//
// This particular station is the National Weather Station at the Dayton Ohio USA airport.
// These coordinates are used since they are those of the station.
// ETo is calculated based on the location of the data gathering, not the farm,
// which may be some distance from the station.
#define stationLatitude  +39.906
#define stationElevation -84.219

// The average hours of sunshine per day in a given month at the station's location.
// Vector gives data for Months 1..12. Index 0 is unused.
//
// Per https://wikidiff.com/sunlight/daylight#:~:text=As%20nouns%20the%20difference%20between,that%20from%20any%20other%20source.
// A succinct explanation of the difference between sunlight and daylight:
// As nouns the difference between sunlight and daylight is that sunlight is all the electromagnetic
// radiation given off by the sun, especially that in the visible spectrum that bathes the earth,
// while daylight is the light from the sun, as opposed to that from any other source.
//
// A good example comparison chart is given at the bottom of
// https://www.weather-us.com/en/ohio-usa/dayton-weather-may.
// Notice that daylight is always greater than sunshine.
//
// Had started to use this website but its data in other cases is suspect.
// Wrote to them about my concerns and recieved no reply.
// https://www.worlddata.info/africa/ethiopia/climate-amhara.php
//
// This website's data does not seem realistic but might be useful if something is needed.
// https://www.weather-atlas.com/en/ethiopia/mekele-climate
//
// Used the sunlight/daylight comparison chart given at the bottom of
// https://www.weather-us.com/en/ohio-usa/dayton-weather-may.
// This site appears to be only for the USA but we are dealing with a sweet-corn crop in Dayton Ohio USA.
// Month:                                            Jan  Feb  Mar  Apr  May  Jun  Jul  Aug  Sep  Oct  Nov  Dec
static const double hoursSunshinePerDay[13] = { 0.0, 4.3, 4.9, 5.8, 7.1, 8.5, 9.8, 9.6, 8.9, 7.9, 6.2, 3.9, 3.2 };

//-------------------------------
// Notes

// STL string manipulation
// http://www.cplusplus.com/reference/string/string

// STL two-dimensional arrays
// https://stackoverflow.com/questions/12844475/why-cant-simple-initialize-with-braces-2d-stdarray
// http://cpptruths.blogspot.com/2011/10/multi-dimensional-arrays-in-c11.html

// STL interator example
// http://www.cplusplus.com/reference/list/list/list

//-------------------------------

#include <math.h>

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

// Vector location of specific record elements
enum
{
  MeanTempF, MeanDewPointF, MeanSeaLevelMb, MeanStationPressureMb, MeanVisibilityMi, MeanWindSpeedKt,
  MaxSustainedWindSpeedKt, MaxWindGustKt, MaxTempF, MinTempF, PrecipitationIn, totalNumElements
};

// Type of record holding daily weather readings
//#define WeatherDataRecordType array<double, totalNumElements>
#define WeatherDataRecordType vector<double>

class WeatherDataIO
{

private:

  WeatherDataRecordType thisRecord;
  int year, month, day;
  string QueryForWeatherObservations();

public:

  WeatherDataRecordType GetWeatherRecord();
  bool GetLineWeatherData();
  int GetYear();
  int GetMonth();
  int GetDay();
  double GetHoursOfDaylight(int month);
  WeatherDataIO();
};

#endif
