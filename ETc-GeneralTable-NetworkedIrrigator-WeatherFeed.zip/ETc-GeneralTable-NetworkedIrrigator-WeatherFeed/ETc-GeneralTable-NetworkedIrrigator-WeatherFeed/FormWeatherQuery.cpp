
// In the USA, weather feeds come as json data structures.
// Other nations have their own approach.
// There are two approaches to using this code:
// One approach reads from a file that contains a given json structure.
// The other creats a REST web query to retrieve the appropriate json structure.

#include <iostream>
#include <fstream>
#include <ctime>
using namespace std;

string ReadJasonFromFile(string filename)
{
  ifstream in(filename);
  string contents((istreambuf_iterator<char>(in)), istreambuf_iterator<char>());
  return contents;
}

string FormQueryFromSpecifiedTimeRange(string stationCode, string startDateTime, string endDateTime)
{
  string webLink = "https://api.weather.gov/stations/" + stationCode + "/observations?start=";
  webLink += startDateTime + "&end="; webLink += endDateTime;
  return webLink;
}

string FormQueryFromLocalUTC(string stationCode)
{
  // https://www.tutorialspoint.com/cplusplus/cpp_date_time.htm
  // http://www.cplusplus.com/reference/cstdio/printf/
  char timeBuffer[1024];
  time_t thisTime = time(0);
  char* timeString = ctime(&thisTime);
  tm* timeUTC = gmtime(&thisTime);
  int century = ((timeUTC->tm_year / 100) * 100) + 1900;
  sprintf(timeBuffer, "%d", timeUTC->tm_year);
  int year = century + atoi(timeBuffer + (strlen(timeBuffer) - 2));
  sprintf(timeBuffer, "%4d-%02d-%02dT%02d:%02d:%02d-00:00",
    year, timeUTC->tm_mon + 1, timeUTC->tm_mday - 1, timeUTC->tm_hour, timeUTC->tm_min, timeUTC->tm_sec);
  string startDateTime = timeBuffer;
  sprintf(timeBuffer, "%4d-%02d-%02dT%02d:%02d:%02d-00:00",
    year, timeUTC->tm_mon + 1, timeUTC->tm_mday, timeUTC->tm_hour, timeUTC->tm_min, timeUTC->tm_sec);
  string endDateTime = timeBuffer;
  string webLink = FormQueryFromSpecifiedTimeRange(stationCode, startDateTime, endDateTime);
  return webLink;
}
