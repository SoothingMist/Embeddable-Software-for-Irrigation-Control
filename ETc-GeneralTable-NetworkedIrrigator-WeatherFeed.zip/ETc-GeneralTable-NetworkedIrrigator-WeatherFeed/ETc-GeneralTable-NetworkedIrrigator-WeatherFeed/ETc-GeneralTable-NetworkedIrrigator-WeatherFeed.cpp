// ETc-GeneralTable-NetworkedIrrigator.cpp : This file contains the 'main' function.
// Program execution begins and ends there.
//
// Combines ETo and Kc to obtain KTc.

#include <iostream>
using namespace std;

#include "WeatherDataIO.h"
#include "Kc_Table.h"
#include "Client.h" // brings in the ability to act as a network client

extern double CalculateETo(int presentYear, int presentMonth, int presentDay, double hoursDaylight, WeatherDataRecordType thisRecord);
extern double Knots_to_MPS(double Knots);
extern double Fahrenheit_to_Celsius(double Fahrenheit);
extern double DetermineRelativeHumidity(double meanAirTempC, double meanDewPointC);

int main()
{
  // Buffer to hold messages
  char message[DEFAULT_BUFLEN];
  message[0] = '\0';

  // Connect to irrigation server
  Client *irrigatorNetworkConnection = new Client("127.0.0.1", "27015");
  if (irrigatorNetworkConnection->checkConnection())
  {
    // Send ready signal
    strcpy(message, "Ready");
    irrigatorNetworkConnection->sendMessage(message);

    // Receive confirmation signal
    irrigatorNetworkConnection->receiveMessage(message);
    printf("Received Message: %s\n", message);
  }
  else return -1;

  // Data on this specific crop
  Kc_Table MaizeKcTable;
  double ETo, Kc, ETc; // ETc = ETo * Kc
  double daysAfterPlanting = -1.0;
  double cropDailyWaterNeed = MaizeKcTable.GetCropDailyWaterNeed();
  double moistureAvailable = MaizeKcTable.GetCropDailyWaterNeed();

  // Identify the source of weather data.
  WeatherDataIO WeatherDataSource;

  // Holds the current weather record.
  WeatherDataRecordType thisRecord;

  // Variables for the date
  int presentYear;
  int presentMonth;
  int presentDay;

  // Initialize an assumed average ETo in case the first data record is bad
  double previousETo = MaizeKcTable.GetAverageReportedETo();

  // Heading for console output
  cout << endl << "Where * appears, that indicates a NAN, invalid, value.\n";
  cout << "When ETo cannot be calculated, the previous ETo is used instead.\n";
  cout << "When Kc cannot be calculated, the table Kc is used instead.\n";
  cout << endl << "Year Mon Day" << '\t' << "MinTemp" << '\t' <<
    "MaxTemp" << '\t' << "VaporPressure" << '\t' << "WindSpeed" << '\t' <<
    "ActualDurationSunshine" << '\t' << "IncomingSolarRadiation" << '\t' <<
    "ETo_mm/day" << '\t' << "ETc_mm/day" << '\t' << "Rain_in" << '\t' << "cropMoisture" << endl;

  while (true)
  {
    // An assumption is that this program is started 24 hours after planting
    daysAfterPlanting += 1.0;
    WeatherDataSource.GetLineWeatherData();
    thisRecord = WeatherDataSource.GetWeatherRecord();

    // Determine the present month.
    presentYear = WeatherDataSource.GetYear();
    presentMonth = WeatherDataSource.GetMonth();
    presentDay = WeatherDataSource.GetDay();

    ETo = CalculateETo
    (
      presentYear,
      presentMonth,
      presentDay,
      WeatherDataSource.GetHoursOfDaylight(presentMonth),
      thisRecord
    );

    if (ETo < 0.0) // bad data record
    {
      ETo = previousETo;
    }
    else // good data record
    {
      previousETo = ETo;
    }

    // Determine the specific Kc value for this point in the crop's growth
    double relativeHumidity =
      DetermineRelativeHumidity
      (
        Fahrenheit_to_Celsius(thisRecord[MeanTempF]),
        Fahrenheit_to_Celsius(thisRecord[MeanDewPointF])
      );
    Kc = MaizeKcTable.DetermineKc(daysAfterPlanting, Knots_to_MPS(thisRecord[MeanWindSpeedKt]), relativeHumidity);

    // Calculate ETc
    ETc = ETo * Kc;
    printf("%.2lf\t\t%.2lf", ETc, thisRecord[PrecipitationIn]);

    // Calculate need for irrigation
    // https://www.rapidtables.com/convert/length/inch-to-mm.html
    // Rain data unit is inches, need millimeters
    moistureAvailable = moistureAvailable - ETc + (thisRecord[PrecipitationIn] * 25.4);
    printf("       %.2f\n", moistureAvailable);

    // Tell the irrigator how much water is needed
    if (moistureAvailable < cropDailyWaterNeed)
    {
      sprintf(message, "%lf", cropDailyWaterNeed - moistureAvailable);
      printf("%s mm water needed\n", message);
      irrigatorNetworkConnection->sendMessage(message);
      irrigatorNetworkConnection->receiveMessage(message);
      printf("%s mm water added\n", message);
      moistureAvailable += atof(message);
      // Windows' Sleep is in milliseconds.
      // We wait here to give the LED a chance to turn off before the next signal.
      // Note that the application operates the irrigator at most once per day.
      // Ref: https://docs.microsoft.com/en-us/windows/win32/api/synchapi/nf-synchapi-sleep
      Sleep(1000);
    }
    // Wait 24 hours, 86400000 milliseconds.
    // Then query for the latest weather observations.
    Sleep(86400000);
  }

  // Finished
  delete irrigatorNetworkConnection;
  irrigatorNetworkConnection = NULL;
  cout << "Program Finished" << endl;
  cout << "Press <enter> to end program: ";
  string endProgram;
  getline(cin, endProgram); cout << endl; // http://www.cplusplus.com/doc/tutorial/basic_io/

  return 0;
}
