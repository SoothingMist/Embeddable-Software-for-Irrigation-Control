
#include "WinHttpClient.h"

#include <iostream>
using namespace std;

string AccessInternet(string internetAddress)
{
  // Set URL.
  //wstring address = L"http://www.codeproject.com";
  //wstring address = L"https://api.weather.gov/stations/KHZY/observations?start=2020-09-01T20%3A53%3A00%2B00%3A00&end=2020-09-02T20%3A53%3A00%2B00%3A00";
  wstring address = L"";
  int length = internetAddress.length();
  const char* tempString = internetAddress.c_str();
  for (int i = 0; i < length; i++) address += (wchar_t)((int)tempString[i]);
  WinHttpClient client(address);

  // Send HTTP request, a GET request by default.
  client.SendHttpRequest();

  // The response header.
  wstring httpResponseHeader = client.GetResponseHeader();

  // The response content.
  wstring httpResponseContent = client.GetResponseContent();
  //cout << httpResponseContent.c_str() << endl;
  const wchar_t* thisString = httpResponseContent.c_str();
  length = httpResponseContent.length();
  int thisChar;
  string jsonString = "";
  for (int i = 0; i < length; i++)
  {
    thisChar = (int)thisString[i];
    if (thisChar <= 255) jsonString += (char)thisChar;
  }

  // Finished
  cout << jsonString << endl;
  return jsonString;
}
