// Combined.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Combines ETo and Kc to obtain KTc.

#include <iostream>
#include "WeatherDataIO.h"

extern double GetCropDailyWaterNeed();
extern double CalculateETo(int presentYear, int presentMonth, int presentDay, double hoursDaylight, WeatherDataRecordType thisRecord);
extern double DetermineKc(double daysSincePlanting);

int main()
{
  double ETo, Kc, ETc; // ETc = ETo * Kc
  double daysAfterPlanting = -1.0;
  double cropDailyWaterNeed = GetCropDailyWaterNeed();
  double moistureAvailable = GetCropDailyWaterNeed();

  // Identify the source of weather data.
  WeatherDataIO WeatherDataSource;
  if (!WeatherDataSource.OpenWeatherDataFile()) return -1;

  // Holds the current weather record.
  WeatherDataRecordType thisRecord;
  int presentYear;
  int presentMonth;
  int presentDay;
  double previousETo = 21.0; // early-stage ETo from Araya's paper

  // Heading for console output
  cout << endl << "Where * appears, that indicates a NAN, invalid, value.\n";
  cout << "In such cases, ETo cannot be calculated. The previous ETo is used instead.\n";
  cout << endl  << "Year Month Day" << '\t' << "MinTemp" << '\t' <<
    "MaxTemp" << '\t' << "VaporPressure" << '\t' << "WindSpeed" << '\t' <<
    "ActualDurationSunshine" << '\t' << "IncomingSolarRadiation" << '\t' <<
    "ETo_mm/day" << '\t' << "ETc_mm/day" << endl;

  while (WeatherDataSource.GetLineWeatherData())
  {
    daysAfterPlanting += 1.0;
    thisRecord = WeatherDataSource.GetWeatherRecord();

    // Determine the present month.
    presentYear = WeatherDataSource.GetYear();
    presentMonth = WeatherDataSource.GetMonth();
    presentDay = WeatherDataSource.GetDay();

    ETo = CalculateETo
    (
      presentYear,
      presentMonth,
      presentDay,
      WeatherDataSource.GetHoursOfDaylight(presentMonth),
      thisRecord
    );

    if (ETo < 0.0) // bad data record
    {
      ETo = previousETo;
    }
    else // good data record
    {
      previousETo = ETo;
    }

    // Determine the specific Kc value for this point in the crop's growth
    Kc = DetermineKc(daysAfterPlanting);

    // Calculate ETc
    ETc = ETo * Kc;
    printf("%.2lf\n", ETc);

    // Calculate need for irrigation
    // https://www.rapidtables.com/convert/length/inch-to-mm.html
    // Rain data unit is inches, need millimeters
    moistureAvailable = moistureAvailable - ETc + (thisRecord[PrecipitationIn] * 25.4);
    if (moistureAvailable < cropDailyWaterNeed)
    {
      // Say how much water is needed.
      printf("%.2lf mm water needed\n", cropDailyWaterNeed - moistureAvailable);
      moistureAvailable = cropDailyWaterNeed;
    }
  }

  // Finished
  cout << "Program Finished" << endl;
  cout << "Press <enter> to end program: ";
  string endProgram;
  getline(cin, endProgram); cout << endl; // http://www.cplusplus.com/doc/tutorial/basic_io/
  return 0;
}
