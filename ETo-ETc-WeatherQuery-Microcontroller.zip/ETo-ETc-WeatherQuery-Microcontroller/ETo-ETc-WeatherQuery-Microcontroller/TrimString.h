
#pragma once

// Trim STL Strings
// https://stackoverflow.com/questions/216823/whats-the-best-way-to-trim-stdstring

#include <algorithm> 
#include <cctype>
#include <locale>
#include <regex>
#include <string>

// trim from start (in place)
static inline void ltrim(std::string &s) {
  s.erase(s.begin(), std::find_if(s.begin(), s.end(), [](int ch) {
    return !std::isspace(ch);
  }));
}

// trim from end (in place)
static inline void rtrim(std::string &s) {
  s.erase(std::find_if(s.rbegin(), s.rend(), [](int ch) {
    return !std::isspace(ch);
  }).base(), s.end());
}

// trim from both ends (in place)
static inline void trim(std::string &s) {
  ltrim(s);
  rtrim(s);
}

// trim from start (copying)
static inline std::string ltrim_copy(std::string s) {
  ltrim(s);
  return s;
}

// trim from end (copying)
static inline std::string rtrim_copy(std::string s) {
  rtrim(s);
  return s;
}

// Remove consecutive spaces from string
// http://en.cppreference.com/w/cpp/algorithm/unique 
static inline std::string removeConsecutiveSpaces(std::string s)
{
  auto end = std::unique(s.begin(), s.end(), [](char l, char r)
  {
    return std::isspace(l) && std::isspace(r) && l == r;
  });

  return s;
}

// Remove all spaces from string
static inline std::string removeAllSpaces(std::string s) {
  return std::regex_replace(s, std::regex("\\s+"), ""); // http://www.cplusplus.com/forum/beginner/191482
}

// Replace one string with another within a string
// https://stackoverflow.com/questions/2896600/how-to-replace-all-occurrences-of-a-character-in-string
static inline std::string replaceCharacters(std::string s, std::string existing, std::string replacement) {
  size_t index;
  size_t stringSize = existing.length();
  while ((index = s.find(existing)) != std::string::npos) {
    s.replace(index, stringSize, replacement);
  }
  return s;
}
