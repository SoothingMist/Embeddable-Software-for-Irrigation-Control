
#include "IrrigationSystemSpecific.h"
#include "ArduSerial.h"

// Arduino serial port object.
// Truely, this is an odd way of doing things but it was
// necessary because of library incompatibilities.
// Usually, this would be a private member of IrrigationSystemSpecific.
WindowsSerial* thisSerialPort = NULL;

// Connects the basestation to the irrigation system's microcontroller.
// This approach assumes the microcontroller is plugged directly into the basestation.
bool IrrigationSystemSpecific::connect()
{
	cout << "Trying to connect to COM" << comPort << endl;
	if (thisSerialPort != NULL)
	{
		thisSerialPort->end();
		delete thisSerialPort;
		thisSerialPort = NULL;
	}
	thisSerialPort = new WindowsSerial(comPort);

	// Set communications baud rate
	thisSerialPort->begin(baudRate);
	if (!thisSerialPort->connected())
	{
		cout << "Unable to establish serial port." << endl;
		return false;
	}

	// Wait for microcontroller to confirm it is available.
	string message = ReceiveMessage(1.0);
	if (message.compare(messageTimeout) != 0)
		cout << "Connected: " << message << endl;
	else
	{
		cout << "Did not receive message confirming connection." << endl;
		return false;
	}

	return true;
}

// There are many reasons for not receiving an expected message.
// This subroutine attempts to account for many of those.
// (Timer Baseline: https://linuxhint.com/timer-function-cpp)
string IrrigationSystemSpecific::ReceiveMessage(double minutesToWait)
{
	int waitTime = (int)round(60.0 * minutesToWait * (double)CLOCKS_PER_SEC);
	int startTime = clock();
	string message = "";
	char thisChar = ' ';

	do
	{
		if (thisSerialPort->available() > 0)
		{
			thisChar = thisSerialPort->read();
			if (thisChar == messageEnd) return message;
			else if (thisChar != '\r') message += thisChar;
		}
	} while ((clock() - startTime) <= waitTime);

	return messageTimeout;
}

// Causes the irrigation system to turn on for a certain length of time and then turn off.
// Uses message confirmation to confirm connection.
bool IrrigationSystemSpecific::OperateIrrigator(double minutesToWait)
{
	// Send a message to turn the irrigator ON
	string message = to_string(minutesToWait);
	cout << "Sending ON message: " << message << " minutes of operation\n";
	thisSerialPort->print(message + "\n");

	// Wait for acknowledgement of ON message
	message = ReceiveMessage(1.0 + minutesToWait);
	if (message.compare(messageTimeout) != 0)
		cout << "ON confirmation: " << message << " milliseconds of operation\n";
	else
	{
		cout << "Did not receive ON confirmation." << endl;
		return false;
	}

	// Wait for OFF message
	cout << "Waiting for OFF message" << endl;
	message = ReceiveMessage(1.0 + minutesToWait);
	if (message.compare(messageTimeout) != 0)
		cout << "OFF confirmation: " << message << endl;
	else
	{
		cout << "Did not receive OFF confirmation." << endl;
		return false;
	}

	return true;
}

// Destructor
IrrigationSystemSpecific::~IrrigationSystemSpecific()
{
	if (thisSerialPort != NULL)
	{
		thisSerialPort->end();
		delete thisSerialPort;
		thisSerialPort = NULL;
	}
}
