
#include "AccessWebpages.h"

// https://www.codeproject.com/Articles/66625/A-Fully-Featured-Windows-HTTP-Wrapper-in-C
#include "WinHttpClient.h"

// Access from file is used for testing the json parsing process.
// This mitigates issues associated with too-often making real-time queries.
string AccessWebpages::RetrieveFromFile(string filename)
{
  string webpage = "";
  ifstream in(filename);
  if(in.is_open())
  {
    string contents((istreambuf_iterator<char>(in)), istreambuf_iterator<char>());
    in.close();
    webpage = contents;
  }
  return webpage;
}

// Makes real-time queries of the USA National Weather Service.
string AccessWebpages::RetrieveFromInternet(string internetAddress)
{
  // For testing, as needed.
  //internetAddress = "https://api.weather.gov/stations/KDAY/observations?start=2023-01-01T23:00:00Z&end=2023-02-02T23:00:00Z";

  // Set URL. This approach is required by WinHttpClient.
  wstring address = L"";
  int length = internetAddress.length();
  const char* tempString = internetAddress.c_str();
  for (int i = 0; i < length; i++) address += (wchar_t)((int)tempString[i]);
  WinHttpClient client(address);

  // Send HTTP request, a GET request by default.
  client.SendHttpRequest();

  // The response header.
  wstring httpResponseHeader = client.GetResponseHeader();

  // The response content.
  wstring httpResponseContent = client.GetResponseContent();
  const wchar_t* thisString = httpResponseContent.c_str();
  length = httpResponseContent.length();
  int thisChar;
  string webpage = "";
  for (int i = 0; i < length; i++)
  {
    thisChar = (int)thisString[i];
    if (thisChar <= 255) webpage += (char)thisChar;
  }

  // Finished
  //cout << jsonString << endl;
  return webpage;
}
