
// ETo-ETc-WeatherQuery-Microcontroller.cpp : This file contains the 'main' function.
// Program execution begins and ends there.
//
// Forms a REST query of the US National Weather Service.
// Present use is to query for observations over the last 24 hours.
// These are summarized for calculating ETo.
// ETc is then calculated and the amount of irrigation estimated.
// Then the microcontroller is signaled for operation.

// Ignoring security warnings.
#define _CRT_SECURE_NO_WARNINGS

// Enables the OS sleep function for this thread.
// https://www.softwaretestinghelp.com/cpp-sleep
#include <chrono>
#include <thread>

#include "WeatherObservations.h"
#include "CropSpecificData.h"
#include "IrrigationSystemSpecific.h"

extern double CalculateETo(time_t currentTime, const double* dailyObservation);

int main()
{
  // Everything having to do with querying and summarizing weather data.
  WeatherObservations theseWeatherObservations;

  // What we know about the crop.
  CropSpecificData thisCrop;
  int seasonLength = (int)thisCrop.GetSeasonLength();

  // Flag indicating correct run of certain subroutines.
  bool correct = false;

  // When ETo cannot be calculated, the most recent ETo is used.
  // Average ETo over previous seasons is used to initialize.
  double previousETo = thisCrop.averageReportedETo;

  // Evapotranspiration for the reference crop.
  double ETo;

  // Evapotranspiration for the specific crop.
  double ETc;

  // Excess watering occurs when precipitation is greater than ETc.
  // We begin with the assumption that the field is well-watered at the start.
  // Then we replace the moisture lost via ETc, crop-specific evapotranspiration.
  double previousExcess = 0.0;

  // Perform required operations for each day after planting.
  for (int DAP = 1; DAP <= seasonLength; DAP++)
  {
    cout << "=== Begin Day after Planting " << DAP << " ===\n\n";

    // Produces a vector summarizing the last 24 hours of observations.
    // Retrieves current date/time from host system
    // https://www.tutorialspoint.com/cplusplus/cpp_date_time.htm
    time_t currentTime = time(0);
    cout << "Current date/time: " << ctime(&currentTime);
    correct = theseWeatherObservations.SummarizeLast24Hours(currentTime);

    // Calculate ETo.
    if (correct)
    {
      ETo = CalculateETo(currentTime, theseWeatherObservations.GetDailyObservation());
    }
    else
    {
      ETo = NAN;
      cout << "Process of summarizing observations encountered errors or NAN values." << endl;
      cout << "Using ETo previously calculated.\n";
    }

    if (!isnan(ETo)) previousETo = ETo;
    else ETo = previousETo;
    cout << "ETo: " << ETo << "mm\n";

    // Calculate ETc.
    ETc = ETo * thisCrop.DetermineKc(DAP);
    cout << "ETc: " << ETc << "mm\n";
    
    // Obtain total precipitation.
    double totalPrecipitation =
      theseWeatherObservations.GetDailyObservation()[PrecipitationMM];
    cout << "Precipitation last 24 hours: " << totalPrecipitation << "mm\n";

    // Determine required moisture.
    cout << "Excess moisture: " << previousExcess << "mm\n";
    double requiredMoisture = ETc - totalPrecipitation - previousExcess;
    if (requiredMoisture < 0.0)
    {
      previousExcess = fabs(requiredMoisture);
      cout << "Required moisture: " << 0 << "mm\n";
    }
    else
    // Connect to and operate the irrigation system.
    // Disconnect when finished.
    {
      IrrigationSystemSpecific thisIrrigationSystem;
      bool connected = false;
      previousExcess = 0.0;
      cout << "Required moisture: " << requiredMoisture << "mm\n";

      while (!connected)
      {
        connected = thisIrrigationSystem.connect();
        if (connected)
          connected =
            thisIrrigationSystem.OperateIrrigator(thisIrrigationSystem.MinutesToOperate(requiredMoisture));
        else
        {
          cout << "Check serial port connection with irrigation system." << endl;
          cout << "Press <enter>/<return> when ready to try again.... (waiting):";
          char thisChar;
          cin.getline(&thisChar, 1);
        }
      }
    }
    cout << "\n=== End Day after Planting " << DAP << " ===\n\n";
    
    // Wait 24 hours. Then go on to the next day after planting.
    this_thread::sleep_for(chrono::hours(24));
  }

  // Finished.
  cout << endl;
  return(0);
}
