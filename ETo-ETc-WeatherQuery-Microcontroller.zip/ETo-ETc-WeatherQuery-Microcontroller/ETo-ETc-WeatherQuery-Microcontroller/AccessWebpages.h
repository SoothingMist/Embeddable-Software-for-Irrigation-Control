
#ifndef _AccessWebpages
#define _AccessWebpages

#include <iostream>
#include <fstream>
#include <string>
using namespace std;

class AccessWebpages
{

public:

  string RetrieveFromInternet(string internetAddress);
  string RetrieveFromFile(string filename);
};

#endif
