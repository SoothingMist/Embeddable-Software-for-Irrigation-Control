// WaterUseTesting.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include <cstring>
#include <set>
using namespace std;

// Define crop-specific tables
#include "CropSpecificTableReferences.h"

// Access to historical weather data file retrieved from US National Weather Service.
#include "WeatherDataIO.h"

// Access to the Kc table
#include SpecificKcTable_include

// Access to the crop-height table
#include SpecificCropHeightTable_include

// Utilities
extern double Fahrenheit_to_Celsius(double Fahrenheit);
extern double DetermineRelativeHumidity(double meanAirTempC, double meanDewPointC);
extern double Knots_to_MPS(double Knots);
extern NumericWeatherRecordType ReadNextWeatherRecord(WeatherDataIO* source);
extern double CalculateETo(double actualDurationSunshine, NumericWeatherRecordType thisRecord);
extern double DetermineKc
(
  SpecificKcTable_type *KcTable,
  SpecificCropHeightTable_type *CropHeightTable,
  double daysAfterPlanting,
  double meanWindSpeedMS, double minRH
);

// Kc table
SpecificKcTable_type *KcTable = NULL;

// Crop-height table
SpecificCropHeightTable_type *CropHeightTable = NULL;

// Source of weather data
WeatherDataIO *WeatherDataSource = NULL;

double CalculateEtc(double daysAfterPlanting, NumericWeatherRecordType thisRecord)
{
  double ETo = CalculateETo(WeatherDataSource->GetHoursOfDaylight(), thisRecord);
  double relativeHumidity = DetermineRelativeHumidity
  (
    Fahrenheit_to_Celsius(thisRecord[NumericElementVector::TEMP]),
    Fahrenheit_to_Celsius(thisRecord[NumericElementVector::DEWP])
  );

  double Kc = DetermineKc
  (
    KcTable,
    CropHeightTable,
    daysAfterPlanting,
    Knots_to_MPS(thisRecord[NumericElementVector::WDSP]),
    relativeHumidity
  );
  double ETc = ETo * Kc;

  // As with ETo, we decide what to do if data elements are invalid.
  if (isnan(ETc))
  {
    // http://www.fao.org/3/s2022e/s2022e02.htm, Table 3, specific to corn
    ETc = ETo * 1.1;
  }

  return ETc;
}

int main()
{
  // Storage location for all files
  string storageLocation = "D:/Paper - Precision Irrigation/WaterUse/WeatherData/IdahoFallsRegionalAirport/";
  // Prefix for historic weather data, a csv file
  string historicDataPrefix = "72578524145_2019_Extracted";

  // Gain access to the Kc table
  KcTable = new SpecificKcTable_type;
  if (KcTable == NULL)
  {
    cout << "Main: Unable to create link to the Kc table\n";
    return 1;
  }

  // Gain access to the crop-height table
  CropHeightTable = new SpecificCropHeightTable_type;
  if (CropHeightTable == NULL)
  {
    cout << "Main: Unable to create link to the crop-height table\n";
    return 1;
  }

  // Gain access to source of historic weather data
  WeatherDataSource = new WeatherDataIO(storageLocation + historicDataPrefix);
  if (WeatherDataSource == NULL)
  {
    cout << "Main: Unable to create link to historic weather data\n";
    return 1;
  }

  // Open file containing historic weather data.
  if (!WeatherDataSource->OpenWeatherDataFile())
  {
    cout << "Main: Unable to open historic weather data file\n";
    return 1;
  }

  // It is necessary to deduce the amount of water available to the crop at the start.
  // One could use a soil-moisture sensor to get an idea by taking readings throughout the field.
  // ETc is the amount of moisture lost over the last 24 hours, the crop's "water use".
  // That amount of water overall must be available to the crop as part of sowing preparation.
  // Here we assume that a soil-moisture sensor indicates there is zero moisture available.
  // Thus we have to add the amount of water given by ETc at the beginning,
  // minus the amount of precipitation.
  double daysAfterPlanting = 0.0;
  double totalIrrigation = 0.0;
  double totalPrecipitation = 0.0;
  double ETc, waterAdded;
  double waterAvailable = 0.0;
  double precipitation;
  NumericWeatherRecordType thisRecord;
  if ((thisRecord = ReadNextWeatherRecord(WeatherDataSource)).size() > 0)
  {
    double moisture_sensor_reading = 0.0;
    ETc = CalculateEtc(daysAfterPlanting, thisRecord);

    // ETc is in millimeters. Precipitation from US sources is in inches.
    // https://www.rapidtables.com/convert/length/inch-to-mm.html
    precipitation = thisRecord[NumericElementVector::PRCP] * 25.4;

    waterAvailable = (moisture_sensor_reading + precipitation) - ETc;
    if (waterAvailable < 0.0) waterAvailable = 0.0;
    if (ETc > waterAvailable)
    {
      waterAdded = ETc - waterAvailable;
      waterAvailable = ETc;
      totalIrrigation += waterAdded;
    }
  }
  else
  {
    cout << "Main: There does not appear to be any weather data available.\n";
    return 1;
  }

  // Read and process each record in the realtime data feed
  double cropGrowthPeriod = CropHeightTable->getMaxTableX();
  while ((thisRecord = ReadNextWeatherRecord(WeatherDataSource)).size() > 0)
  {
    daysAfterPlanting += 1.0;
    if (daysAfterPlanting > cropGrowthPeriod) break;
    // ETc is in millimeters. Precipitation from US sources is in inches.
    // https://www.rapidtables.com/convert/length/inch-to-mm.html
    precipitation = thisRecord[NumericElementVector::PRCP] * 25.4;
    totalPrecipitation += precipitation;

    // ETc is the amount of moisture lost over the last 24 hours, the crop's "water use".
    // That amount of water has to be added via irrigation or precipitation.
    // Thus we have to add the amount of water given by ETc
    // minus the amount of water already available and minus precipitation.
    ETc = CalculateEtc(daysAfterPlanting, thisRecord);
    waterAvailable = (waterAvailable + precipitation) - ETc;
    if (waterAvailable < 0.0) waterAvailable = 0.0;
    if (ETc > waterAvailable)
    {
      waterAdded = ETc - waterAvailable;
      waterAvailable = ETc;
      totalIrrigation += waterAdded;
      printf("Day: %g   ETc: %g   Irrigation: %g  Rain: %g\n", daysAfterPlanting, ETc, waterAdded, precipitation);
    }
  }

  cout << endl << "Main: Total Irrigation Water Added: " << totalIrrigation <<" mm" << endl;
  cout << "Main: Total Precipitation: " << totalPrecipitation << " mm" << endl;

  // Finished
  delete WeatherDataSource; WeatherDataSource = NULL;
  delete KcTable; KcTable = NULL;
  delete CropHeightTable; CropHeightTable = NULL;
  cout << "Main: Finished\n";
  return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
