#pragma once

#include <iostream>
#include "AbstractLinearInterpolationTable.h"
#include "CropSpecificTableReferences.h"
#include SpecificCropHeightTable_include

class SpecificCropHeightTable_type : public AbstractLinearInterpolationTable
{

  // ============== Begin Configuration Variables ====================

public:

  // tableHeight is the number of rows in the interpolation table.
  // This variable name must appear at the end of the enum.
  // Each table row represents a phase of crop growth.
  // These are the known x,y values used by the interpolation function.
  // You can use any phase-names you want here but phase names must appear.
  enum {initial, developmental, middle, late, tableHeight };

  // These tables are for Maize, Sweet (sweet corn) grown in Idaho, USA.

  // Look-up table for Kc relative to the number of days after planting.
  // There is the implied assumption that days-after-planting relates to crop stage.
  // That may or may not be the case in a specific circumstance.
  // That is where human-supervision comes in. The farmer should adjust for crop stage.
  // This version of the code does not allow for that but that would not be impossible
  // to implement if a human-oriented data interface were provided. We are not there yet.
  //
  // Calculating Kc at different crop stages based on generalized tables from the baseline document.
  // Tables 11 and 12 are employed.
  // There is the implied assumption that days-after-planting relates to crop stage.
  // That may or may not be the case in a specific circumstance.
  // That is where human-supervision comes in. The farmer should adjust for crop stage.
  // This version of the code does not allow for that but that would not be impossible
  // to implement if a human-oriented data interface were provided. We are not there yet.
  //
  // We use Maize Field Grain since that also is also an important crop in Ethiopia.
  // Tables 11 and 12 do not have values for Teff.
  //
  // The Kc table's basic format is fixed:
  // days after planting, Kc, slope
  // (slope entered as 0.0 since it is calculated by the class constructor)
  // See Fig 34, p 126 for how to get Kc values by combining Table 12, Page 110, and Table 11, Page 104.
  // An implied assumption is that the crop is harvested after the total growth period.
  
  // table is the table of x,y,slope values for each phase.
  // slope is calculated by the class constructor.
  // It is entered here as a 0-value placeholder.
  // The number of rows is (tableHeight + 1) because the lowest
  // expected x value is given as the first row.
  // The last row gives the highest expected x value.
  // Here is an example table. With judicious use of tableHeight,
  // any set of x,y values can be used. But, it is necessary that
  // the x values be constantly increasing.
  //
  // Typical crop height in meters at various growth stages.
  // Derived from Figure 1,
  // https://www.researchgate.net/publication/258104207_Influence_of_Plant_Population_and_Nitrogen-Fertilizer_at_Various_Levels_on_Growth_and_Growth_Efficiency_of_Maize/figures?lo=1
  // Their graph is for 260cm max crop height.
  // A disparity here is that the growth table, Table 11, uses four growth periods over 180 days.
  // The link above uses five growth periods over 120 days. Clearly, local information on the crop is needed.
  // Since there is no height data in the baseline document, we use the chart in the link as best we can.
  // The software will adapt to whatever table values are used.
  // Format: DAP, Estimated Crop Height, Slope
  // (slope entered as 0.0 since it is calculated by the class constructor)

  double interpolationTable[tableHeight + 1][tableWidth] =
  {
      0.0, 0.00, 0.0, // always zero
     30.0, 0.89, 0.0, // initial
     60.0, 1.44, 0.0, // developmental
     90.0, 1.47, 0.0, // middle
    100.0, 1.50, 0.0  // late; max crop height; DAP here should be the same as DAP in the last row of the Kc table
  };

  // =================================================================

  // Placeholder to account for inheriting an abstract class.
  void abstractFunction() { int i = 0; }

public:

  // Constructor Override
  SpecificCropHeightTable_type()
  {
    // Populate the class' table
    table.clear();
    vector<double> rowVector;
    for (int row = 0; row <= tableHeight; row++)
    {
      rowVector.clear();
      for (int col = 0; col < tableWidth; col++)
      {
        rowVector.push_back(interpolationTable[row][col]);
      }
      table.push_back(rowVector);
    }
    // Check table contents.
    // Performs various checks on the table's contents.
    bool tableOK = CheckTableContents();
    if (tableOK == false)
    {
      cout << "InterpolationTable: Error found in table.\n";
      cout << "                    Recommend repair before continuing.\n\n";
      return;
    }
    // Calculate table slopes.
    // The table itself is initialized in InterpolationTable.h.
    CalculateSlopes();
    // Set the maximum tableX cell value
    maxTableX = table[tableHeight][tableX];
  }
};
