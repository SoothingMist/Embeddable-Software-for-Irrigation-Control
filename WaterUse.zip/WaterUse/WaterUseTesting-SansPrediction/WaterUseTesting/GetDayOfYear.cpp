
extern bool LeapYear(int);

// Adapted from Table 2.5, p 217, bottom of page

int GetDayOfYear(int Y, int M, int D)
{
  int J;

  J = (int)((275 * M) / 9) - 30 + D - 2;
  if (M < 3) J = J + 2;
  if (LeapYear(Y) && (M > 2)) J = J + 1;
  return J;
}
