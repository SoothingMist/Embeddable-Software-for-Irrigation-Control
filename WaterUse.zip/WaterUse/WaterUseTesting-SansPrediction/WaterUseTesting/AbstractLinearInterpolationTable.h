#pragma once

// This abstract class specifies a linear interpolation table.
// y = f(x)

#include <vector>
using namespace std;

class AbstractLinearInterpolationTable
{

protected:

  // tableWidth is the number of columns in the interpolation table.
  // This is a fixed value. This enum should not be changed
  // The interpolation yields a linear function y = f(x).
  //
  // slope is calculated by the class constructor.
  // So, it is entered here as a 0-value placeholder.
  // These names are fixed and should not be changed.
  // But, their values still have to be accessible to
  // inheriting classes.
  enum { tableX, tableY, slope, tableWidth };

  // Specification for interpolation table.

  // table is the interpolation table.
  // The table gives x,y,slope values for each phase.
  // slope is calculated by the class constructor.
  // It is entered here as a 0-value placeholder.
  // The number of rows is (tableHeight + 1) because the lowest
  // expected x value is given as the first row.
  // The last row gives the highest expected x value.
  // Here is an example table. With judicious use of tableHeight,
  // any set of x,y values can be used. But, it is necessary that
  // the x values be constantly increasing.
  vector<vector<double>> table;

  // This is the value of the tableX cell of the last row in table.
  // The deriving class' constructor has to set this value.
  double maxTableX = 0.0;

  // Placeholder to create abstract class.
  // Instances of such classes cannot be instantiated.
  virtual void abstractFunction() = 0;

  bool CheckTableContents();
  void CalculateSlopes();

public:

  // Call this function with the x value to get y = f(x)
  // via linear interpolation.
  vector<double> Interpolate(double x);

  // Writes a table to disk that shows the curve from interpolation
  // across the table's x values.
  void ExerciseTable();

  // Retrieve the maximum value of the tableX cell.
  // This is the value of the tableX cell of the last row in table.
  double getMaxTableX();
};
