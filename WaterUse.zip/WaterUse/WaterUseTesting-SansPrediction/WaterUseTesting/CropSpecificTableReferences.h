#pragma once

// There must be a better way to do generic classes via inheritance
// but I have to think about that.

// Note that the same name is used in different ways.

// Access to crop-specific Kc table.
#define SpecificKcTable_include "KcInterpolationTable_Maize.h"
#define SpecificKcTable_type KcInterpolationTable_Maize

// Access to specific crop-height table.
#define SpecificCropHeightTable_include "CropHeightInterpolationTable_Maize.h"
#define SpecificCropHeightTable_type CropHeightInterpolationTable_Maize
