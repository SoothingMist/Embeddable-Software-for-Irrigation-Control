
#include <iostream>
#include <math.h>
#include "AbstractLinearInterpolationTable.h"

vector<double> AbstractLinearInterpolationTable::Interpolate(double x)
{
  // Interpolate between datapoints in the table.
  // A return of nan means that the input value x is outside the table's range.
  double interpolationResult = nan(""); // http://www.cplusplus.com/reference/cmath/nan-function;
  double phase = nan("");
  vector<double> returnVector;
  for (int row = 1; row < table.size(); row++)
  {
    if (x <= table[row][tableX])
    {
      phase = (double)row;
      interpolationResult =
        (table[row][slope] * (x - table[row - 1][tableX])) + table[row - 1][tableY];
      break;
    }
  }

  returnVector.push_back(phase);
  returnVector.push_back(interpolationResult);
  return returnVector;
}

// Calculate slopes for each row in the table.
// The table itself is initialized in InterpolationTable.h.
void AbstractLinearInterpolationTable::CalculateSlopes()
{
  for (int row = 1; row < table.size(); row++)
  {
    table[row][slope] =
      (table[row][tableY] - table[row - 1][tableY]) /
      (table[row][tableX] - table[row - 1][tableX]);
  }
}

bool AbstractLinearInterpolationTable::CheckTableContents()
{
  if (tableWidth != 3)
  {
    cout << "InterpolationTable: tableWidth must be equal to 3.\n";
    cout << "                    Recommend repair before continuing.\n";
    return false;
  }

  if(table.size() < 1)
  {
    cout << "InterpolationTable: tableHeight must be >= 1.\n";
    cout << "                    Recommend repair before continuing.\n";
    return false;
  }

  for (int row = 1; row < table.size(); row++)
  {
    if (table[row - 1][tableX] > table[row][tableX])
    {
      cout << "InterpolationTable: table[" << row - 1 << "][xValue] is greater than ";
      cout <<                      "that in the following row.";
      cout << "                    Recommend repair before continuing.\n";
      return false;
    }
  }

  return true;
}

void AbstractLinearInterpolationTable::ExerciseTable()
{
  FILE* fileStorage = fopen("LinearInterpolationTest.csv", "w");
  double x = table[0][tableX];
  while (x <= table[table.size() - 1][tableX])
  {
    fprintf(fileStorage, "%lf, %lf\n", x, Interpolate(x)[1]);
    x += 1.0;
  }
  fclose(fileStorage); fileStorage = NULL;
}

double AbstractLinearInterpolationTable::getMaxTableX() { return maxTableX; }
