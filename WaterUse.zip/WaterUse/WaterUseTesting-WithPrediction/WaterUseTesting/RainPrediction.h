#pragma once

#include <iostream>
#include <string>
#include <set>
using namespace std;

#include "WeatherDataIO.h"

class RainPrediction
{

public:

  RainPrediction(string C5_Prefix, bool* ok);
  char MakePrediction(NumericWeatherRecordType currentWeatherRecord);

private:

  // Filenames and Filepointers
  FILE* filePointer = NULL;
  FILE* filePointerAux = NULL;
  string filename_Temp;
  string C5_ModelPrefix;
  string filename_C5ModelData;
  string filename_Cases;
  string filename_Results;

  // System Commands
  string SystemCommand_C5;
  string SystemCommand_Move;
  string SystemCommand_Classify;

  // Records used to create derived records.
  // These are used for making predictions.
  NumericWeatherRecordType firstRecord, secondRecord, thirdRecord;

  // Elements to be ignored.
  // These are set in the constructor.
  set<int> ignoreElements;
};

