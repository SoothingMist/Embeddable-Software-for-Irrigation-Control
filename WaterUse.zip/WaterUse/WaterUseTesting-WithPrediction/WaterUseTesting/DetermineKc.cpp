
#include <math.h>
#include <iostream>
using namespace std;

// Adjustment value for partial wetting. p 119, eq 60, see also the paragraph just above the equation
const double Fw = 0.4; // since we assume a trickle or drip irrigation system

// Define crop-specific tables
#include "CropSpecificTableReferences.h"

// Access to the Kc table
#include SpecificKcTable_include

// Access to the crop-height table
#include SpecificCropHeightTable_include

double DetermineKc
(
  SpecificKcTable_type *KcTable,
  SpecificCropHeightTable_type *CropHeightTable,
  double daysAfterPlanting,
  double meanWindSpeedMS, double relativeHumidity
)
{
  // Interpolate between datapoints in the crop-height table.
  double estimatedCropHeight = CropHeightTable->Interpolate(daysAfterPlanting)[1];

  // Interpolate between datapoints in the Kc table
  vector<double> Kc = KcTable->Interpolate(daysAfterPlanting);

  // There are three growth phases for Kc (Table 12). That will never change.
  // Thus, I am comfortable with this approach for deciding how to modify Kc.
  if (Kc[0] <= KcTable->developmental) // Kc initial phase
  {
    // eq 60, p 119
    Kc[1] *= Fw;
  }
  else if (Kc[0] <= KcTable->late) // Kc middle phase
  {
    // eq 62, p 121
    // Requires minimum relative humidity but the data only gives mean dewpoint temperature.
    // Have had to settle for RH calculated from that.
    // ex 27, p 125 shows that RH is expressed as a percentage.
    // We only irrigate when the mosisture estimate shows low moisture.
    // Thus, there is no adjustment for frequency of wetting. See the discussion on p 124.
    Kc[1] +=
      (((0.04 * (meanWindSpeedMS - 2.0)) - (0.004 * (relativeHumidity - 45.0))) * pow(estimatedCropHeight / 3.0, 0.3));
  }
  else if (Kc[0] <= KcTable->tableHeight) // Kx end phase
  {
    // eq 65, p 125
    // Requires minimum relative humidity but the data only gives mean dewpoint temperature.
    // Have had to settle for RH calculated from that.
    // The discussion on p 153 says that Kc-end is not adjusted when the table value is <= 0.45.
    if (Kc[1] > 0.45)
      Kc[1] +=
      (((0.04 * (meanWindSpeedMS - 2.0)) - (0.004 * (relativeHumidity - 45.0))) * pow(estimatedCropHeight / 3.0, 0.3));
  }

  return Kc[1];
}
