#include "RainPrediction.h"
#include <cstring>

extern int RunSystemCommand(string callingFunction, string SystemCommand);

RainPrediction::RainPrediction(string C5_Prefix, bool *ok)
{
  // Flag to indicate that program is functional
  *ok = true;

  // Check for a system command processor
  // Ref: http://www.cplusplus.com/reference/cstdlib/system
  if (!system(NULL))
  {
    cout << "RainPrediction Constructor: A system command processor is not available. Program not fully functional.\n";
    *ok = false;
  }

  // Define various filenames
  C5_ModelPrefix = C5_Prefix;
  filename_Cases = C5_ModelPrefix + ".cases";
  filename_Results = C5_ModelPrefix + ".results";
  filename_C5ModelData = C5_ModelPrefix + ".data";
  filename_Temp = "tempfile.txt";

  // Define various system commands.
  // This code will ultimately run under Linux.

  SystemCommand_C5 = "./c5.0 -r -f ";
  SystemCommand_C5 += C5_ModelPrefix + " > Console_C5.txt";

  SystemCommand_Move = "mv " + filename_Temp + " ";
  SystemCommand_Move += filename_C5ModelData;

  SystemCommand_Classify = "./ClassifyIndividualCases.exe -r -f ";
  SystemCommand_Classify += C5_ModelPrefix + " > ";
  SystemCommand_Classify += "Console_classify.text";

  // Initialize various records
  firstRecord.clear();
  secondRecord.clear();
  thirdRecord.clear();

  // Arrange for elements to be ignored
  ignoreElements.insert(NumericElementVector::GUST);
}

char RainPrediction::MakePrediction(NumericWeatherRecordType currentWeatherRecord)
{
  if (firstRecord.size() == 0)
  {
    firstRecord = currentWeatherRecord;
    return 'U';
  }

  if (secondRecord.size() == 0)
  {
    secondRecord = currentWeatherRecord;
    return 'U';
  }

  if (thirdRecord.size() != 0)
  {
    firstRecord = secondRecord;
    secondRecord = thirdRecord;
  }
  thirdRecord = currentWeatherRecord;

  if ((secondRecord[NumericElementVector::NUMDAYS] - firstRecord[NumericElementVector::NUMDAYS]) != 1)
  {
    return 'U';
  }

  // Create the derived weather record

  // Various common variables
  const int bufferLength = 2048;
  char testRecord[bufferLength]; testRecord[0] = '\0';
  char charBuffer[bufferLength];
  bool goodRecord = true;

  // Holds classification result
  struct
  {
    char Classification[10];
    double Confidence;
  } ClassificationResult;

  for (int element = NumericElementVector::TEMP; element < NumericElementVector::PRCP; element++)
  {
    if (ignoreElements.find(element) == ignoreElements.end())
    {
      if (isnan(secondRecord[element]))
      {
        sprintf(testRecord + strlen(testRecord), "?, ?,");
        goodRecord = false;
      }
      else if (isnan(firstRecord[element]))
      {
        sprintf(testRecord + strlen(testRecord), "%8.2lf,?,", secondRecord[element]);
        goodRecord = false;
      }
      else
        sprintf(testRecord + strlen(testRecord), "%8.2lf,%8.2lf,",
          secondRecord[element], (secondRecord[element] - firstRecord[element]));
    }
  }

  // Put the new derived weather record into the cases file so it can be classified
  filePointer = fopen(filename_Cases.c_str(), "w");
  if (filePointer == NULL)
  {
    cout << "MakePrediction: Unable to open test case file.\n";
    cout << "(" << filename_Cases << ")\n";
    return 'U';
  }
  else
  {
    fprintf(filePointer, "%s ?", testRecord);
    fclose(filePointer); filePointer = NULL;

    // Build a classification model using the derived historical data
    if (RunSystemCommand("MakePrediction", SystemCommand_C5) != 0)
    {
      return 'U';
    }

    // Classify the derived record
    if (RunSystemCommand("MakePrediction", SystemCommand_Classify) != 0)
    {
      return 'U';
    }

    // Open the classification results file
    filePointer = fopen(filename_Results.c_str(), "r");
    if (filePointer == NULL)
    {
      cout << "MakePrediction: Unable to open results file.\n";
      cout << "(" << filename_Results << ")\n";
      return 'U';
    }

    // Read classification
    int i = 0; // https://stackoverflow.com/questions/3501338/c-read-file-line-by-line
    charBuffer[i] = getc(filePointer);
    while ((charBuffer[i] != '\n') && (charBuffer[i] != EOF))
    {
      i++;
      charBuffer[i] = getc(filePointer);
    }
    charBuffer[i] = '\0';
    strcpy(ClassificationResult.Classification, charBuffer);

    // Read confidence
    i = 0; // https://stackoverflow.com/questions/7537754/read-number-from-a-file-and-replace-it-with-another-number
    charBuffer[i] = getc(filePointer);
    while ((charBuffer[i] != '\n') && (charBuffer[i] != EOF))
    {
      i++;
      charBuffer[i] = getc(filePointer);
    }
    charBuffer[i] = '\0';
    ClassificationResult.Confidence = atof(charBuffer);

    // Close results file and report
    fclose(filePointer); filePointer = NULL;
    cout << "MakePrediction: Classification " << ClassificationResult.Classification <<
      "   Confidence " << ClassificationResult.Confidence << endl << endl;

    // Remove the top record from the derived historical data file.
    // Add the new realtime derived record to the bottom.
    // Has the affect of removing the oldest record and adding the latest record.
    // The resulting file becomes the new data for building an evolving classification model.
    filePointer = fopen(filename_Temp.c_str(), "w");
    if (filePointer == NULL)
    {
      cout << "MakePrediction: Unable to open temp file.\n";
      cout << "(" << filename_Temp << ")\n";
    }
    else
    {
      filePointerAux = fopen(filename_C5ModelData.c_str(), "r");
      if (filePointerAux == NULL)
      {
        cout << "MakePrediction: Unable to open historical data file.\n";
        cout << "(" << filename_C5ModelData << ")\n";
        return 'U';
      }
      else
      {
        fgets(charBuffer, bufferLength, filePointerAux);
        while (fgets(charBuffer, bufferLength, filePointerAux) > 0) fprintf(filePointer, "%s", charBuffer);
        fclose(filePointerAux); filePointerAux = NULL;
        if (thirdRecord[NumericElementVector::PRCP] > 0.0)
          fprintf(filePointer, "\n%s yes", testRecord);
        else fprintf(filePointer, "\n%s no", testRecord);
        fclose(filePointer); filePointer = NULL;
        if (RunSystemCommand("MakePrediction", SystemCommand_Move) != 0)
          cout << "MakePrediction: Unable to move the new model data to its proper filename.\n";
      }
    }

    // Deliver the classification result
    if (strcmp(ClassificationResult.Classification, "yes") == 0) return 'Y';
    else if (strcmp(ClassificationResult.Classification, "no") == 0) return 'N';
    else return 'U'; // this should never happen but put here for completeness
  }
}