
// Main.cpp
// This file contains the 'main' function.
// Program execution begins and ends there.

#include <iostream>
#include <string>
#include <cstring>
#include <set>
using namespace std;

// Access to historical weather data file retrieved from US National Weather Service.
#include "WeatherDataIO.h"

// Utilities
extern NumericWeatherRecordType ReadNextWeatherRecord(WeatherDataIO* source);
extern void RunSystemCommand(string callingFunction, string SystemCommand);

// Name of this function
#define callingFunction "Main"

// Holds classification results
struct
{
  char Classification[10];
  double Confidence;
} ClassificationResult;

// Indexes for statistics table.
// False negatives, false positives, True Positives, True Negatives
enum { NoYes, YesNo, YesYes, NoNo, numChoices };
int statisticsTable[] = { 0, 0, 0, 0 };

int main(int Argc, char* Argv[])
{
  // Check the program input variables
  if (Argc != 5)
  {
    cout << "There must be four program input variables.\n";
    cout << "The program command line is assumed to be:  ./Main -r -f <modelDataPrefix> <testDataPrefix>\n";
    cout << "For example:  ./Main -r -f 72429093815_1987-1997 72429093815_1998-2018\n";
    cout << "Program terminating.";
    return 1;
  }

  // Check for a system command processor
  // Ref: http://www.cplusplus.com/reference/cstdlib/system
  if (!system(NULL))
  {
    cout << "A system command processor is not available. Program terminating.\n";
    return 1;
  }

  // Filenames

  FILE* filePointer = NULL;
  FILE* filePointerAux = NULL;

  string C5_ModelPrefix = Argv[3];
  string historicDataPrefix = Argv[4]; // original weather data

  string filename_Temp = "tempfile.txt";
  string filename_C5ModelData = C5_ModelPrefix + ".data";
  string filename_Cases = C5_ModelPrefix + ".cases";
  string filename_Results = C5_ModelPrefix + ".results";

  // System Commands

  int exitCode = 1;

  string SystemCommand_C5 = "./c5.0 -r -f ";
  SystemCommand_C5 += C5_ModelPrefix + " > Console_C5.txt";

  string SystemCommand_Move = "mv "; SystemCommand_Move += filename_Temp;
  SystemCommand_Move += " "; SystemCommand_Move += filename_C5ModelData;

  string SystemCommand_Classify = "./ClassifyIndividualCases.exe -r -f ";
  SystemCommand_Classify += C5_ModelPrefix + " > Console_class.text";
  
  //------------------------------------
  // Access historical weather data
  
  int element;
  NumericWeatherRecordType firstRecord, secondRecord, thirdRecord;

  // Arrange for elements to be ignored
  set<int> ignoreElements;
  ignoreElements.insert(NumericElementVector::GUST);

  // Gain access to source of historic weather data
  WeatherDataIO* WeatherDataSource = new WeatherDataIO(historicDataPrefix);
  if (WeatherDataSource == NULL)
  {
    cout << "Main: Unable to create link to historic weather data\n";
    return 1;
  }

  // Open file containing historic weather data.
  // Filename is given in WeatherDataIO.h
  if (!WeatherDataSource->OpenWeatherDataFile())
  {
    cout << "Main: Unable to open historic weather data file\n";
    return 1;
  }

  // Find the first record
  firstRecord = ReadNextWeatherRecord(WeatherDataSource);
  if (firstRecord.size() == 0)
  {
    cout << "Main: Unable to find any records\n";
    return 1;
  }

  // Find the second record
  secondRecord = ReadNextWeatherRecord(WeatherDataSource);
  if (secondRecord.size() == 0)
  {
    cout << "Main: Unable to find the second record\n";
    return 1;
  }

  //------------------------------------

  // Commonly used variables
  const int bufferLength = 2048;
  char testRecord[bufferLength];
  char charBuffer[bufferLength];
  bool goodRecord;

  // Read and process each record in the realtime data feed
  while (true)
  {
    // Ensure first and second records are contiguous
    while ((secondRecord[NumericElementVector::DATE] - firstRecord[NumericElementVector::DATE]) != 1)
    {
      firstRecord = secondRecord;
      secondRecord = ReadNextWeatherRecord(WeatherDataSource);
      if (secondRecord.size() == 0)
      {
        cout << "Main: Unable to find two contiguous first and second records. Likely end-of-file\n";
        break;
      }
    }
    if (secondRecord.size() == 0) break;

    // Create the derived weather record
    goodRecord = true;
    testRecord[0] = '\0';
    for (element = NumericElementVector::TEMP; element < NumericElementVector::PRCP; element++)
    {
      if (ignoreElements.find(element) == ignoreElements.end())
      {
        if (isnan(secondRecord[element]))
        {
          sprintf(testRecord + strlen(testRecord), "?, ?,");
          goodRecord = false;
        }
        else if(isnan(firstRecord[element]))
          sprintf(testRecord + strlen(testRecord), "%8.2lf,?,", secondRecord[element]);
        else
          sprintf(testRecord + strlen(testRecord), "%8.2lf,%8.2lf,", secondRecord[element], (secondRecord[element] - firstRecord[element]));
      }
    }
    cout << testRecord << " ?" << endl;

    // Put the new derived weather record into the cases file so it can be classified
    filePointer = fopen(filename_Cases.c_str(), "w");
    if (filePointer == NULL)
    {
      cout << "Main: Unable to open test case file. Program terminating.\n";
      cout << "(" << filename_Cases << ")\n";
      return 1;
    }
    fprintf(filePointer, "%s ?", testRecord);
    fclose(filePointer); filePointer = NULL;

    // Build a classification model using the derived historical data
    RunSystemCommand(callingFunction, SystemCommand_C5);

    // Classify the derived record
    RunSystemCommand(callingFunction, SystemCommand_Classify);

    // Open the classification results file
    filePointer = fopen(filename_Results.c_str(), "r");
    if (filePointer == NULL)
    {
      cout << "Main: Unable to open results file. Program terminating.\n";
      cout << "(" << filename_Results << ")\n";
      return 1;
    }
    
    // Read classification
    int i = 0; // https://stackoverflow.com/questions/3501338/c-read-file-line-by-line
    charBuffer[i] = getc(filePointer);
    while ((charBuffer[i] != '\n') && (charBuffer[i] != EOF))
    {
      i++;
      charBuffer[i] = getc(filePointer);
    }
    charBuffer[i] = '\0';
    strcpy(ClassificationResult.Classification, charBuffer);

    // Read confidence
    i = 0; // https://stackoverflow.com/questions/7537754/read-number-from-a-file-and-replace-it-with-another-number
    charBuffer[i] = getc(filePointer);
    while ((charBuffer[i] != '\n') && (charBuffer[i] != EOF))
    {
      i++;
      charBuffer[i] = getc(filePointer);
    }
    charBuffer[i] = '\0';
    ClassificationResult.Confidence = atof(charBuffer);

    // Close results file and report
    fclose(filePointer); filePointer = NULL;
    cout << "   Main: Classification " << ClassificationResult.Classification <<
      "   Confidence " << ClassificationResult.Confidence << endl << endl;

    // Read the third record.
    // The third record contains the classification for the derived record.
    thirdRecord = ReadNextWeatherRecord(WeatherDataSource);
    if ((thirdRecord.size() > 0) && goodRecord && 
      ((thirdRecord[NumericElementVector::DATE] - secondRecord[NumericElementVector::DATE]) == 1))
    {
      // Add the third record's classification to the second record.
      // The second record is used to classify next-day precipitation.
      if (thirdRecord[NumericElementVector::PRCP] > 0.0)
      {
        sprintf(testRecord + strlen(testRecord), " yes");
        if(strcmp(ClassificationResult.Classification, "yes") == 0) statisticsTable[YesYes]++;
        else statisticsTable[YesNo]++;
      }
      else
      {
        sprintf(testRecord + strlen(testRecord), " no");
        if (strcmp(ClassificationResult.Classification, "no") == 0) statisticsTable[NoNo]++;
        else statisticsTable[NoYes]++;
      }

      // Remove the top record from the data file and add the new realtime record to the bottom.
      // This becaome the new data for building an evolving classification model.
      filePointer = fopen(filename_Temp.c_str(), "w");
      if (filePointer == NULL)
      {
        cout << "Main: Unable to open temp file. Program terminating.\n";
        cout << "(" << filename_Temp << ")\n";
        return 1;
      }
      filePointerAux = fopen(filename_C5ModelData.c_str(), "r");
      if (filePointerAux == NULL)
      {
        cout << "Main: Unable to open historical data file. Program terminating.\n";
        cout << "(" << filename_C5ModelData << ")\n";
        return 1;
      }
      fgets(charBuffer, bufferLength, filePointerAux);
      while (fgets(charBuffer, bufferLength, filePointerAux) > 0) fprintf(filePointer, "%s", charBuffer);
      fclose(filePointerAux); filePointerAux = NULL;
      fprintf(filePointer, "\n%s", testRecord);
      fclose(filePointer); filePointer = NULL;
      RunSystemCommand(callingFunction, SystemCommand_Move);
    }
    firstRecord = secondRecord;
    secondRecord = thirdRecord;
  }

  // Finished
  delete WeatherDataSource; WeatherDataSource = NULL;

  // Report classification statistics
  int totalClassifications = 0;
  for (int i = 0; i < numChoices; i++) totalClassifications += statisticsTable[i];
  cout << "Number of Classifications: " << totalClassifications << endl;
  cout << "Number Incorrect: " << (statisticsTable[NoYes] + statisticsTable[YesNo]) << endl;
  cout << "Number Correct: " << (statisticsTable[NoNo] + statisticsTable[YesYes]) << endl;
  cout << "Number of False Negatives: " << statisticsTable[NoYes] << endl;
  cout << "Number of True Negatives: " << statisticsTable[NoNo] << endl;
  cout << "Number of False Positives: " << statisticsTable[YesNo] << endl;
  cout << "Number of True Positives: " << statisticsTable[YesYes] << endl;

  // Exit system
  cout << "Main: Finished\n";
  return 0;
}
