#include "Kc_Table.h"
#include <iostream>
using namespace std;

Kc_Table::Kc_Table()
{
  // Configuration variables

  // How many mm water should be available to the crop on each day.
  // This is different for each crop. Various documents suggest this number for Teff.
  // Teff is the crop of choice for this software module.
  // Teff is a primary crop in Ethiopia.
  cropDailyWaterNeed = 8.0;

  // Average ETo for the growing season for the particular weather station location.
  // This value is used in lieu of a value for previous ETo when the first weather data record
  // does not yield a valid ETo calculation.
  // This particular value is an average of the ETo reported by Araya in their paper, Table 1.
  averageReportedETo = 25.17;

  // Calculate slopes for Kc table.
  // The table itself is initialized in Kc_Table.h.
  for (int row = 1; row < KcTableLength; row++)
  {
    KcTableValues[row][slope] =
      (KcTableValues[row][y] - KcTableValues[row - 1][y]) / 
      (KcTableValues[row][x] - KcTableValues[row - 1][x]);
  }
}

double Kc_Table::GetCropDailyWaterNeed() { return cropDailyWaterNeed; }
double Kc_Table::GetAverageReportedETo() { return averageReportedETo; }

double Kc_Table::DetermineKc(double daysAfterPlanting)
{
  // Interpolate between datapoints in the Kc table
  double interpolationResult;
  int row;
  for (row = 1; row < KcTableLength; row++)
  {
    if (daysAfterPlanting <= KcTableValues[row][x])
    {
      interpolationResult =
        (KcTableValues[row][slope] * 
          (daysAfterPlanting - KcTableValues[row - 1][x])) +
        KcTableValues[row - 1][y];
      break;
    }
  }

  if (row < KcTableLength) return interpolationResult;
  else
  {
    cout << "DetermineKc: Unable to match days-after-planting with values in Kc table" << endl;
    return -1.0;
  }
}