#include "Kc_Table.h"

Kc_Table::Kc_Table()
{
  // ============== Begin Configuration Variables ====================

  // These values are for Teff grown in Ethiopia.

  // How many mm water should be available to the crop on each day.
  // This is different for each crop. Various documents suggest this number for Teff.
  // Teff is the crop of choice for this software module.
  // Teff is a primary crop in Ethiopia.
  cropDailyWaterNeed = 8.0;

  // Average ETo for the growing season for the particular weather station location.
  // This value is used in lieu of a value for previous ETo when the first weather data record
  // does not yield a valid ETo calculation.
  // This particular value is an average of the ETo reported by Araya in their paper, Table 1.
  averageReportedETo = 25.17;

  // Adjustment value for partial wetting. p 119, eq 60, see also the paragraph just above the equation
  Fw = 0.4; // since we assume a trickle or drip irrigation system

  // If instrumentation output is not desired, set to NULL
  consoleOutput = fopen("ConsoleOutput.csv", "w");

  // ============== End Configuration Variables ====================

  // Calculate slopes for Kc table.
  // The table itself is initialized in Kc_Table.h.
  CalculateSlopes(KcTableValues[0], numGrowthPhases);

  // Instrumentation
  if (consoleOutput != NULL)
  {
    fprintf(consoleOutput, "DAP,Kc\n");
  }
}

Kc_Table::~Kc_Table()
{
  if (consoleOutput != NULL)
  {
    fclose(consoleOutput);
    consoleOutput = NULL;
  }
}

double Kc_Table::GetCropDailyWaterNeed() { return cropDailyWaterNeed; }
double Kc_Table::GetAverageReportedETo() { return averageReportedETo; }

// Calculate slopes for Kc and crop-height tables.
// The table themselves are initialized in Kc_Table.h.
// This approach takes advantage of pointer arithmetic to directly modify matrix cell locations.
// Source: https://stackoverflow.com/questions/14015556/how-to-map-the-indexes-of-a-matrix-to-a-1-dimensional-array-c/14015582
void Kc_Table::CalculateSlopes(double *table, int numGrowthPhases)
{
  for (int growthPhase = 1; growthPhase < numGrowthPhases; growthPhase++)
  {
    table[(growthPhase * tableWidth) + slope] =
      (table[(growthPhase * tableWidth) + y] - table[((growthPhase - 1) * tableWidth) + y]) /
      (table[(growthPhase * tableWidth) + DAP] - table[((growthPhase - 1) * tableWidth) + DAP]);
  }
}

// Performs interpolation on the input table.
// There is no modification of the table itself.
// The returned result is the appropriate y value relative to the number of days after planting.
double Kc_Table::Interpolate(double* table, int numGrowthPhases, double daysAfterPlanting)
{
  // Interpolate between datapoints in the Kc table
  double interpolationResult = -1.0;
  int growthPhase;
  for (growthPhase = 1; growthPhase < numGrowthPhases; growthPhase++)
  {
    if (daysAfterPlanting <= table[(growthPhase * tableWidth) + DAP])
    {
      interpolationResult =
        (table[(growthPhase * tableWidth) + slope] *
          (daysAfterPlanting - table[((growthPhase - 1) * tableWidth) + DAP])) +
        table[((growthPhase - 1) * tableWidth) + y];
      break;
    }
  }

  return interpolationResult;
}

double Kc_Table::DetermineKc(double daysAfterPlanting)
{
  // Error Checks
  if (daysAfterPlanting < 0.0)
  {
    cout << "\nDetermineKc: days after planting cannot be less than zero." << endl;
    return -1.0;
  }
  if (daysAfterPlanting > KcTableValues[numGrowthPhasesMinusOne][DAP])
  {
    cout << "\nDetermineKc: days after planting cannot be greater than " <<
      KcTableValues[numGrowthPhasesMinusOne][DAP] << '.' << endl;
    return -1.0;
  }

  // Interpolate between datapoints in the Kc table
  double Kc = Interpolate(KcTableValues[0], numGrowthPhases, daysAfterPlanting);
  
  // Instrumentation
  if (consoleOutput != NULL)
  {
    fprintf(consoleOutput, "%3.0lf,%.2lf\n", daysAfterPlanting, Kc);
  }
  
  return Kc;
}
