#pragma once

class Kc_Table
{
public:
  Kc_Table();
  double GetCropDailyWaterNeed();
  double GetAverageReportedETo();
  double DetermineKc(double daysAfterPlanting);

private:

  double cropDailyWaterNeed;
  double averageReportedETo;
  enum { x, y, slope, tableWidth }; // tableWidth is the number of columns

  // Look-up table for Kc relative to the number of days after planting.
  // There is the implied assumption that days-after-planting relates to crop stage.
  // That may or may not be the case in a specific circumstance.
  // That is where human-supervision comes in. The farmer should adjust for crop stage.
  // This version of the code does not allow for that but that would not be impossible
  // to implement if a human-oriented data interface were provided. We are not there yet.
  //
  // Source: Araya, A., Stroosnijderb, L., Girmayc, G., Keesstrab, S.D. (2010)
  // "Crop coefficient, yield response to water stress and water productivity of Teff".
  // Agricultural Water Management, Volume 98, Issue 5, March 2011, Pages 775-783,
  // https://www.sciencedirect.com/science/article/pii/S037837741000380X.
  // Kc developed from Table 1, p 5, in paper. They also relate Kc to plant growth stage.
  // Eto is multiplied by Kc to get Etc.
  //
  // Table 12, p 110 in the baseline document, was developed over a large range of plantings.
  // Thus the need for adjusting its values under certain circumstances.
  // As this project moves on, we will use values developed for Teff under specific planting and
  // climatic conditions.Table 12 has nothing on Teff.Therefore, Teff tabulated values will be
  // used directly, without adjustment. These were developed under specific circumstances over a crop year.
  //
  // The Kc table's basic format is fixed:
  // days after planting, Kc, slope
  // (slope entered as 0.0 since it is calculated by the class constructor)
  const static int KcTableLength = 14;
  const static int KcTableLengthMinusOne = KcTableLength - 1;
  double KcTableValues[KcTableLength][3] =
  {
     0.0, 0.89, 0.0, // author's interpretation is that Kc is the same during the initial growth phase
     7.0, 0.89, 0.0,
    14.0, 0.90, 0.0,
    21.0, 0.91, 0.0,
    28.0, 1.00, 0.0,
    35.0, 1.09, 0.0,
    42.0, 1.08, 0.0,
    49.0, 1.08, 0.0,
    56.0, 1.10, 0.0,
    63.0, 1.10, 0.0,
    70.0, 0.90, 0.0,
    77.0, 0.52, 0.0,
    84.0, 0.19, 0.0  // author assumes that crop was harvested at this point
  };
};

