#pragma once
#include <iostream>
using namespace std;

// Disables security warnings
// https://stackoverflow.com/questions/16883037/remove-secure-warnings-crt-secure-no-warnings-from-projects-by-default-in-vis
// Set these options also: SDL Checks to NO (/sdl-) and Warning Level to Level2 (/W2)
#define _CRT_SECURE_NO_WARNINGS

class Kc_Table
{
public:
  Kc_Table();
  ~Kc_Table();
  double GetCropDailyWaterNeed();
  double GetAverageReportedETo();
  double DetermineKc(double daysAfterPlanting);

private:

  // Originally used for testing purposes.
  FILE* consoleOutput;

  // Specification for interpolation tables.
  // tableWidth is the number of columns.
  // DAP: days after planting.
  // y is either a given Kc or crop-height, depending on the table.
  enum { DAP, y, slope, tableWidth };

  double cropDailyWaterNeed;
  double averageReportedETo;
  double Fw; // partial field wetting value

  void CalculateSlopes(double *table, int numGrowthPhases);
  double Interpolate(double* table, int numGrowthPhases, double daysAfterPlanting);

  // ============== Begin Configuration Variables ====================

  // These tables are for Teff grown in Ethiopia.
  // Source: Table 2
  // Araya A, Stroosnijderb L, Girmayc G, Keesstrab SD (2010)
  // Crop coefficient, yield response to water stress and water productivity of
  // Teff. Agricultural Water Management, Volume 98, Issue 5, March 2011, 
  // Pages 775-783, https://www.sciencedirect.com/science/article/pii/S037837741000380X.
  //
  // Look-up table for Kc relative to the number of days after planting.
  // There is the implied assumption that days-after-planting relates to crop stage.
  // That may or may not be the case in a specific circumstance.
  // That is where human-supervision comes in. The farmer should adjust for crop stage.
  // This version of the code does not allow for that but that would not be impossible
  // to implement if a human-oriented data interface were provided. We are not there yet.
  //
  // The Kc table's basic format is fixed:
  // days after planting, Kc, slope
  // (slope entered as 0.0 since it is calculated by the class constructor)
  // See Fig 34, p 126 for how to get Kc values by combining Table 12, Page 110, and Table 11, Page 104.
  // An implied assumption is that the crop is harvested after the total growth period.
  
  // The following table does seem incompatible with their Table 1 but we stuck
  // with Table 2 for time of harvesting.

  // Growth Phases.
  static const int numGrowthPhases = 8;
  static const int numGrowthPhasesMinusOne = numGrowthPhases - 1;

  double KcTableValues[numGrowthPhases][tableWidth] =
  {
      0.0, 0.80, 0.0, // Kc init
     16.0, 1.00, 0.0, // Kc init
     34.0, 0.95, 0.0, // Kc Veg
     37.0, 1.00, 0.0, // Kc Veg
     54.0, 0.95, 0.0, // Kc Mid
     56.0, 1.10, 0.0, // Kc Mid
     68.0, 0.40, 0.0, // Kc Late
     72.0, 0.50, 0.0  // Kc Late
  };
};
