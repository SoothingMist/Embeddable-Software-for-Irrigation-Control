
#pragma once
#include <iostream>
using namespace std;

// Disables security warnings
// https://stackoverflow.com/questions/16883037/remove-secure-warnings-crt-secure-no-warnings-from-projects-by-default-in-vis
// Set these options also: SDL Checks to NO (/sdl-)
#define _CRT_SECURE_NO_WARNINGS

class Kc_Table
{
public:
  Kc_Table();
  ~Kc_Table();
  double GetAverageReportedETo();
  double DetermineKc(double daysAfterPlanting);

private:

  // Originally used for testing purposes.
  FILE* consoleOutput;

  // Specification for interpolation tables.
  // tableWidth is the number of columns.
  // DAP:   days after planting.
  // Kc:    measured Kc value for that crop/soil/terrain at DAP.
  // Slope: Slope required to calculate specific Kc at a given DAP.
  // Intersect: Where the interpolation line intersects the y (Kc) axis.
  enum { DAP, Kc, slope, intersect, tableWidth };

  double cropDailyWaterNeed;
  double averageReportedETo;
  double Fw; // partial field wetting value

  void DetermineInterpolationLines();
  double Interpolate(double daysAfterPlanting);

  // ============== Begin Configuration Variables ====================

  // These tables are for corn (Varieties: 32H39, 30G54) grown in Uvalde, Texas, USA.
  // https://www.researchgate.net/publication/253758855_DETERMINATION_OF_CROP_COEFFICIENTS_KC_FOR_IRRIGATION_MANAGEMENT_OF_CROPS
  //
  // Look-up table for Kc relative to the number of days after planting.
  // There is the implied assumption that days-after-planting relates to crop phase (stage).
  // That may or may not be the case in a specific circumstance.
  // That is where human-supervision comes in. The farmer should adjust for crop stage.
  // This version of the code does not allow for that but that would not be impossible
  // to implement if a human-oriented data interface were provided. We are not there yet.

  static const int numGrowthPhases = 18;
  static const int numGrowthPhasesMinusOne = numGrowthPhases - 1;

  double KcTableValues[numGrowthPhases][tableWidth] =
  {
      0.0, 0.50, 0.0, 0.0, // Planting
      9.0, 0.35, 0.0, 0.0, // Emergence
     20.0, 0.35, 0.0, 0.0, // 2-leaf
     25.0, 0.40, 0.0, 0.0, // 4-leaf
     32.0, 0.45, 0.0, 0.0, // 6-leaf
     39.0, 0.55, 0.0, 0.0, // 8-leaf
     47.0, 0.70, 0.0, 0.0, // 10-leaf
     59.0, 0.80, 0.0, 0.0, // 12-leaf
     66.0, 0.90, 0.0, 0.0, // 14-leaf
     71.0, 1.00, 0.0, 0.0, // Tassel
     73.0, 1.00, 0.0, 0.0, // Silk
     82.0, 1.05, 0.0, 0.0, // Blister
     87.0, 1.15, 0.0, 0.0, // Milk
     92.0, 1.20, 0.0, 0.0, // Dough
     99.0, 1.20, 0.0, 0.0, // Dent
    106.0, 1.20, 0.0, 0.0, // 1/2 mature
    111.0, 1.15, 0.0, 0.0, // Black Layer
    136.0, 0.40, 0.0, 0.0  // Harvest
  };
};
