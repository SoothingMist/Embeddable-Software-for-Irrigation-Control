// Combined.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Combines ETo and Kc to obtain KTc.

#include <iostream>
#include "WeatherDataIO.h"
#include "Kc_Table.h"

extern double CalculateETo(WeatherDataRecordType thisRecord);
extern int GetDayOfYear(int Y, int M, int D);

int main()
{
  Kc_Table KcTable;
  double ETo, Kc, ETc; // ETc = ETo * Kc

  // Identify the source of weather data.
  WeatherDataIO WeatherDataSource;
  if (!WeatherDataSource.OpenWeatherDataFile()) return -1;

  // Holds first weather record.
  WeatherDataRecordType firstRecord;
  WeatherDataSource.GetLineWeatherData();
  firstRecord = WeatherDataSource.GetWeatherRecord();
  int dayOfYear;
  int firstDayOfYear =
    GetDayOfYear((int)firstRecord[YEAR], (int)firstRecord[MONTH], (int)firstRecord[DAY]);

  // calculated as days after first day in record, assumes all days within current year
  int daysAfterPlanting;

  // Holds current weather record.
  WeatherDataRecordType thisRecord;

  // Used if first record is not good.
  double previousETo = KcTable.GetAverageReportedETo();

  // Heading for console output
  cout << endl  << " DAP" << '\t' << "Kc" << '\t' << "ETc" << endl;

  while (WeatherDataSource.GetLineWeatherData())
  {
    thisRecord = WeatherDataSource.GetWeatherRecord();
    dayOfYear = GetDayOfYear((int)thisRecord[YEAR], (int)thisRecord[MONTH], (int)thisRecord[DAY]);
    daysAfterPlanting = dayOfYear - firstDayOfYear;

    ETo = CalculateETo(thisRecord);

    if ((ETo < 0.0) || isnan(ETo))// bad data record
    {
      ETo = previousETo;
    }
    else // good data record
    {
      previousETo = ETo;
    }

    // Determine the specific Kc value for this point in the crop's growth
    Kc = KcTable.DetermineKc(daysAfterPlanting);

    // Calculate ETc
    ETc = ETo * Kc;
    printf("%4d\t%.2lf\t%.2lf\n", daysAfterPlanting, Kc, ETc);
  }

  // Finished
  cout << "Program Finished" << endl;
  cout << "Press <enter> to end program: ";
  string endProgram;
  getline(cin, endProgram); cout << endl; // http://www.cplusplus.com/doc/tutorial/basic_io/
  return 0;
}
