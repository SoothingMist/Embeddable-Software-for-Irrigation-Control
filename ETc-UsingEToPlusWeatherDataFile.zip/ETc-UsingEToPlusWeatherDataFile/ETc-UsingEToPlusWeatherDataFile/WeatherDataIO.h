
#ifndef Class_WeatherDataIO
#define Class_WeatherDataIO 

//-------------------------------
// User configuration variables

// Physical location of the weather station.
// Longitude is not required for these calculations.
// Station location and elevation are given in:
// ftp://ftp.ncdc.noaa.gov/pub/data/noaa/isd-history.txt
// Latitude units are degrees. Elevation units are meters above sealevel.
// Positive latitude refers to north. Negative refers to south.
// Positive longitude refers to east. Negative refers to west.
//
// This particular station is the National Weather Station in Mekele, Ethiopia.
// These coordinates are used since they are those of the station.
// ETo is calculated based on the location of the data gathering, not the farm,
// which may be some distance from the station.
#define stationLatitude +13.467
#define stationElevation +2254.3

// The input file containing daily weather data.
// data: https://www.ncdc.noaa.gov/cdo-web/search
// data details: ftp://ftp.ncdc.noaa.gov/pub/data/gsod/GSOD_DESC.txt
//
// This is a constructed dataset for one growing season. Its purpose is to ensure one record per day.
// The data is constructed by using data from several different years.
// This was done to create continuous data as a test case.
// The idea is to show what is possible if reliable weather data can be obtained.
//
// We continue to use this data constructed from years of Gondar weather data
// since there is no recent historical data for Mekele.
#define weatherDataFilename "../WeatherData/Gondar-Ethiopia-GSOD-CDO2789257804178-20181116-GrowingSeason.csv"

// The average hours of sunshine per day in a given month at the station's location.
// Vector gives data for Months 1..12. Index 0 is unused.
//
// Had started to use this website but its data in other cases is suspect.
// Wrote to them about my concerns and recieved no reply.
// https://www.worlddata.info/africa/ethiopia/climate-amhara.php
// Took the vector for Amhara since there was nothing for Gondar and Amhara is closest.
//double hoursSunshinePerDay[13] = { 0.0, 8.1, 8.3, 7.9, 8.5, 7.3, 6.3, 8.5, 4.6, 6.3, 9.0, 7.2, 8.1 };
//
// Went to this website. Its data does not seem realistic but something was needed.
// The problem may be the difference between "daylight" and "sunshine".
// https://www.weather-atlas.com/en/ethiopia/mekele-climate
static const double hoursSunshinePerDay[13] = { 0.0, 11.4, 11.7, 12.1, 12.4, 12.8, 12.9, 12.8, 12.6, 12.2, 11.8, 11.5, 11.3 };

//-------------------------------
// Notes

// Reading text data from file
// https://stackoverflow.com/questions/8365013/reading-line-from-text-file-and-putting-the-strings-into-a-vector

// STL string manipulation
// http://www.cplusplus.com/reference/string/string

// STL two-dimensional arrays
// https://stackoverflow.com/questions/12844475/why-cant-simple-initialize-with-braces-2d-stdarray
// http://cpptruths.blogspot.com/2011/10/multi-dimensional-arrays-in-c11.html

// STL interator example
// http://www.cplusplus.com/reference/list/list/list

// Source of original data
// https://data.noaa.gov/dataset/dataset/global-surface-summary-of-the-day-gsod

//-------------------------------

#include <math.h>

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <array>
#include <list>
#include <vector>
using namespace std;

// Vector location of specific record elements
enum
{
  MeanTempF, MeanDewPointF, MeanSeaLevelMb, MeanStationPressureMb, MeanVisibilityMi, MeanWindSpeedKt,
  MaxSustainedWindSpeedKt, MaxWindGustKt, MaxTempF, MinTempF, PrecipitationIn, totalNumElements
};

// Type of record holding daily weather readings
#define WeatherDataRecordType array<float, totalNumElements>

class WeatherDataIO
{

private:

  size_t numUsableElements;
  ifstream WeatherData;
  string line, header;
  WeatherDataRecordType thisRecord;
  int year, month, day;

public:

  WeatherDataRecordType GetWeatherRecord();
  bool OpenWeatherDataFile();
  bool GetLineWeatherData();
  int GetYear();
  int GetMonth();
  int GetDay();
  double GetHoursOfDaylight(int month);
  WeatherDataIO();
  ~WeatherDataIO();
};

#endif
