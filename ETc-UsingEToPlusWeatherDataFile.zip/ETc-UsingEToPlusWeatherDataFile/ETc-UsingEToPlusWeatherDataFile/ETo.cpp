
/* ETo.cpp : Calculate ETo, evapotranspiration for a reference crop

Page and Equation references are to:

Allen, R.G., Pereira, L.S., Raes, D., Smith, M. (1998)
FAO Irrigation and Drainage Paper No. 56 - Crop Evapotranspiration.
United Nations Report. http://academic.uprm.edu/abe/backup2/tomas/fao%2056.pdf

Page references are to numbered pages as displayed by Adobe Acrobat Reader when the document is loaded.
This free reader can be downloaded from

This program calculates ETo, the first phase of calculating ETc. see p6, fig 4.

Note the calculation spreadsheet, box 11, p 67.

We use daily weather data and so follow ex 18, p 72.

We assume single-crop under normal conditions.

*/

#include "WeatherDataIO.h"

const double PI = 3.14159265358979323846;
const double TwoPi = 2.0 * PI;
const double SolarConstant = 0.0820; // p 46, eq 21

// p 46, eq 23
#define InverseRelativeDistance(J) 1.0 + (0.033 * cos(TwoPi * J / 365.0))

// p 46, eq 24
#define SolarDeclination(J) 0.409 * sin((TwoPi * J / 365.0) - 1.39)

// p 46, eq 25
#define SunsetHourAngle(latitudeRadians, solarDeclination) acos(-tan(latitudeRadians) * tan(solarDeclination))

// Convert kilometers-per-hour to kilometers-per-second
// https://www.unitjuggler.com/convert-speed-from-kmh-to-kms.html
#define KMH_to_KMS(KMH) KMH * 3600.0

// Convert knots to kilometers-per-hour
// https://www.unitjuggler.com/convert-speed-from-kt-to-kmh.html
#define Knots_to_KMH(Knots) Knots * 0.53995680346039

// Convert knots to kilometers-per-second
// https://www.unitjuggler.com/convert-speed-from-kt-to-kms.html
#define Knots_to_KMS(Knots) Knots * 1943.8444924574

// Convert knots to meters-per-second
// https://www.metric-conversions.org/speed/knots-to-meters-per-second.htm
#define Knots_to_MPS(Knots) Knots * 0.51444445

// Convert Fahrenheit to Celsius
// https://www.almanac.com/content/temperature-conversion
#define Fahrenheit_to_Celsius(Fahrenheit) (Fahrenheit - 32.0) * 5.0 / 9.0

// Convert Fahrenheit to Kelvin
// https://www.thoughtco.com/convert-fahrenheit-to-kelvin-609231
#define Fahrenheit_to_Kelvin(Fahrenheit) (Fahrenheit + 459.67) * 5.0 / 9.0

// Convert dewpoint in centigrade to vapor pressure.
// eq 48, p 58
// We use dewpoint because that is recorded in the data
// Relative Humidity, RH, is not available in the data
#define VaporPressure(dewpointTempC) 0.611 * exp((17.27 * dewpointTempC) / (dewpointTempC + 237.3))

// Convert relative humidity of vapor pressure.
// eq 17, p 38
// Relative Humidity, RH, is not available in the data
//#define VaporPressure(saturationVaporPressureMin, saturationVaporPressureMax, RHmin, RHmax)  ((saturationVaporPressureMin * RHmax / 100.0) + (saturationVaporPressureMax * RHmin / 100.0)) / 2.0;

// References to functions in other blocks of code.
extern int GetDayOfYear(int Y, int M, int D);

double CalculateETo(int presentYear, int presentMonth, int presentDay, double actualDurationSunshine, WeatherDataRecordType thisRecord)
{
  {
    double J = (double)GetDayOfYear(presentYear, presentMonth, presentDay);

    // Physical location of the weather station.
    // Longitude is not required for these calculations.
    // Weathersation locations are given in this document:
    // ftp://ftp.ncdc.noaa.gov/pub/data/noaa/isd-history.txt
    // Want this to ultimately be a table lookup for the baseline location data.
    double latitudeDecimalDegrees = stationLatitude;
    double latitudeRadians = ((latitudeDecimalDegrees * PI) / 180.0); // p 46, eq 22

    // These calculations provide the actual values for the equations defined earlier using the 
    // date and station location as specified.
    double inverseRelativeDistance = (InverseRelativeDistance(J));
    double solarDeclination = (SolarDeclination(J));
    double sunsetHourAngle = (SunsetHourAngle(latitudeRadians, solarDeclination));

    // p 46, eq 21
    double extraterrestrialRadiation = 24.0 * 60.0 * SolarConstant * inverseRelativeDistance *
      ((sunsetHourAngle * sin(latitudeRadians) * sin(solarDeclination)) +
        (cos(latitudeRadians) * cos(solarDeclination) * sin(sunsetHourAngle))) / PI;

    // p 44, eq 20
    double equivalentEvaporation = (0.408 * extraterrestrialRadiation);

    // p 48, eq 34 (Daylight Hours)
    double maxDurationSunshine = (24.0 * sunsetHourAngle / PI);

    // The average amount of sunshine per day in a given month.
    // It happens that poor data yields an actual sunshine that is greater than the maximum possible.
    if (actualDurationSunshine > maxDurationSunshine) actualDurationSunshine = maxDurationSunshine;

    // p 50, paragraph following eq 35
    const double overcastExtraterrestrialRadiationFraction = 0.25;
    const double cleardayExtraterrestrialRadiationFraction = 0.50;

    // eq 35, p 50
    double incomingSolarRadiation = (overcastExtraterrestrialRadiationFraction +
      (cleardayExtraterrestrialRadiationFraction * actualDurationSunshine / maxDurationSunshine)) *
      extraterrestrialRadiation;

    // eq 36, p 51, when callibrated values are available (p 52, ex 11 uses this equation)
    double clearskySolarRadiation =
      (overcastExtraterrestrialRadiationFraction + cleardayExtraterrestrialRadiationFraction) *
      extraterrestrialRadiation;
    // eq 37, p 51, when calibrated values are not available
    //double clearskySolarRadiation = (0.75 + (2.0 * 10e-5 * stationElevation)) * extraterrestrialRadiation;

    // eq 38, p 51
    const double albedoCanopyReflectionCoefficient = 0.23; // for the hypothetical grass reference crop
    double netIncomingShortwaveRadiation = (1.0 - albedoCanopyReflectionCoefficient) * incomingSolarRadiation;

    // Get weather data elements.
    // Our data gives degrees in Fahrenheit.
    // Temperatures: F Fahrenheit, C Centigrade (Celcius), K Kelvin
    double tempMaxC = Fahrenheit_to_Celsius(thisRecord[MaxTempF]);
    double tempMinC = Fahrenheit_to_Celsius(thisRecord[MinTempF]);
    double tempAvgC = Fahrenheit_to_Celsius(thisRecord[MeanTempF]);
    double windSpeedMPS = Knots_to_MPS(thisRecord[MeanWindSpeedKt]);
    const double windSpeedHeight = 2.0; // needs to be verified for the specific station but this is the standard height
                                        // the document gives a calculation to adjust for other heights
    // p 56, eq 47
    double windSpeedUz = windSpeedMPS;
    double windspeedU2 = windSpeedUz * (4.87 / log((67.8 * windSpeedHeight) - 5.42));

    // eq 7, p 31
    double atmosphericPressure = 101.3 * pow((293.0 - (0.0065 * stationElevation)) / 293.0, 5.26);

    // eq 13, p 37
    double slopeVaporPressureCurve = (4098.0 * (0.6108 * exp((17.27 * tempAvgC) / (tempAvgC + 237.3)))) /
      pow((tempAvgC + 237.3), 2.0);

    // eq 8, p 32
    double psychrometricConstant = 0.665e-3 * atmosphericPressure;

    // eq 11, p 36
    double saturationVaporPressureMax = (0.6108 * exp((17.27 * tempMaxC) / (tempMaxC + 237.3)));
    double saturationVaporPressureMin = (0.6108 * exp((17.27 * tempMinC) / (tempMinC + 237.3)));

    // eq 48, p 58
    // We use dewpoint because that is recorded in the data
    // Relative Humidity, RH, is not available in the data
    double actualVaporPressure = VaporPressure(Fahrenheit_to_Celsius(thisRecord[MeanDewPointF]));

    // Some of the following equations require temperatures in Kelvin.
    double tempMinK = Fahrenheit_to_Kelvin(thisRecord[MinTempF]);
    double tempMaxK = Fahrenheit_to_Kelvin(thisRecord[MaxTempF]);
    double tempAvgK = Fahrenheit_to_Kelvin(thisRecord[MeanTempF]);

    // eq 39, p 52
    const double StefanBoltzmannConstant = 4.903e-9;
    double netOutgoingLongwaveRadiation = (StefanBoltzmannConstant *
      ((pow(tempMaxK, 4.0) + pow(tempMinK, 4.0)) / 2.0)) *
      (0.34 - (0.14 * sqrt(actualVaporPressure))) *
      ((1.35 * incomingSolarRadiation / clearskySolarRadiation) - 0.35);

    // eq 40, p 53
    double netRadiation = netIncomingShortwaveRadiation - netOutgoingLongwaveRadiation;

    //eq 42, p 54
    const double soilFluxDensity = 0.0;

    // http://bioma.jrc.ec.europa.eu/components/componentstools/evapotranspiration/help/Saturation_vapor_pressure.html
    double esTmin = 0.6108 * exp((17.27 * tempMinC) / (tempMinC + 237.3));
    double esTmax = 0.6108 * exp((17.27 * tempMaxC) / (tempMaxC + 237.3));
    double saturationVaporPressure = (esTmax + esTmin) / 2.0;

    // eq 6, p 24
    double denominator = (slopeVaporPressureCurve + (psychrometricConstant * (1.0 + (0.34 * windspeedU2))));
    double numeratorA = (0.408 * slopeVaporPressureCurve * (netRadiation - soilFluxDensity));
    double resultA = numeratorA / denominator;
    double numeratorB = psychrometricConstant * 900.0 * windspeedU2 *
      (saturationVaporPressure - actualVaporPressure) / (tempAvgC + 273.0);
    double resultB = numeratorB / denominator;
    double referenceEvapotranspiration = (resultA + resultB);
 
    // Corresponds to the data used for testing ETo via CropWat:
    // http://www.fao.org/land-water/databases-and-software/cropwat/en/.
    // They are apparently using a simplified version of the calculations described in the
    // baseline document. For instance, they seem to use incoming solar radiation instead of net radiation.
    // That is the best I can tell from my own analysis and without having access to their source code.
    // The result is that this program delivers results that are 2-4% lower than CropWat.
    // 
    // Testing ETo against the examples in the baseline document went well.
    //
    // Formatting cout: http://faculty.cs.niu.edu/~mcmahon/CS241/c241man/node83.html
    printf("%4i %5i %3i\t", presentYear, presentMonth, presentDay);
    if (isnan(tempMinC)) printf("   *\t");
    else printf("%.2lf\t", tempMinC);
    if (isnan(tempMaxC)) printf("   *\t");
    else printf("%.2lf\t", tempMaxC);
    if (isnan(actualVaporPressure)) printf("   *\t\t");
    else printf("%.2lf\t\t", actualVaporPressure);
    if (isnan(windSpeedMPS)) printf("   *\t\t");
    else printf("%.2lf\t\t", windSpeedMPS);
    if (isnan(actualDurationSunshine)) printf("   *\t\t\t");
    else printf("%.2lf\t\t\t", actualDurationSunshine);
    if (isnan(incomingSolarRadiation)) printf("   *\t\t\t");
    else printf("%.2lf\t\t\t", incomingSolarRadiation);
    if (isnan(referenceEvapotranspiration)) printf("   *");
    else printf("%.2lf", referenceEvapotranspiration);

    if (isnan(referenceEvapotranspiration)) return -1.0; // bad data record
    else return referenceEvapotranspiration; // good data record
  }
}
