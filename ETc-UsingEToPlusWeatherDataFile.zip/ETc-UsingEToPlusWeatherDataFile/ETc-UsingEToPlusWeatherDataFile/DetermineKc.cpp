
// Look-up table for Kc relative to the number of days after planting.
// There is the implied assumption that days-after-planting relates to crop stage.
// That may or may not be the case in a specific circumstance.
// That is where human-supervision comes in. The farmer should adjust for crop stage.
// This version of the code does not allow for that but that would not be impossible
// to implement if a human-oriented data interface were provided. We are not there yet.

// How many mm water should be available to the crop on each day.
// This is different for each crop. Various documents suggest this number for Teff.
// Teff is the crop of choice for this software module. Teff is a primary crop in Ethiopia.
double GetCropDailyWaterNeed() { return 8.0; }

// Average ETo for the growing season for the particular weather station location.
// This value is used in lieu of a value for previous ETo when the first weather data record
// does not yield a valid ETo calculation.
// This particular value is an average of the ETo reported by Araya in their paper, Table 1.
double GetAverageReportedET0() { return 25.17; }

double DetermineKc(double daysAfterPlanting)
{
  // Note: https://stackoverflow.com/questions/3554205/c-multi-dimensional-array-initialization

  // Data Format: days after planting, Kc.
  // Source: Araya, A., Stroosnijderb, L., Girmayc, G., Keesstrab, S.D. (2010)
  // "Crop coefficient, yield response to water stress and water productivity of Teff".
  // Agricultural Water Management, Volume 98, Issue 5, March 2011, Pages 775-783,
  // https://www.sciencedirect.com/science/article/pii/S037837741000380X.
  // Kc developed from Table 1, p 5, in paper. They also relate Kc to plant growth stage.
  // Eto is multiplied by Kc to get Etc.
  //
  // Table 12, p 110 in the baseline document, was developed over a large range of plantings.
  // Thus the need for adjusting its values under certain circumstances.
  // As this project moves on, we will use values developed for Teff under specific planting and
  // climatic conditions.Table 12 has nothing on Teff.Therefore, Teff tabulated values will be
  // used directly, without adjustment. These were developed under specific circumstances over a crop year.

  const static int KcTeffTableLength = 14;
  const static int KcTeffTableLengthMinusOne = KcTeffTableLength - 1;
  const static double KcTeffTable[KcTeffTableLength][2] =
  {
     0.0, 0.89,
     7.0, 0.89,
    14.0, 0.90,
    21.0, 0.91,
    28.0, 1.00,
    35.0, 1.09,
    42.0, 1.08,
    49.0, 1.08,
    56.0, 1.10,
    63.0, 1.10,
    70.0, 0.90,
    77.0, 0.52,
    84.0, 0.19,
    85.0, 0.19
  };

  double Kc = KcTeffTable[0][1]; // initialized here to avoid "uninitialized variable" warning
  if(daysAfterPlanting < 0.0) Kc = KcTeffTable[0][1];
  else if (daysAfterPlanting >= KcTeffTable[KcTeffTableLengthMinusOne][0])
    Kc = KcTeffTable[KcTeffTableLengthMinusOne][1];
  else
  {
    for (int i = 0; i < KcTeffTableLength; i++)
    {
      if (daysAfterPlanting == KcTeffTable[i][0])
      {
        Kc = KcTeffTable[i][1];
        break;
      }
      else if (daysAfterPlanting < KcTeffTable[i][0])
      {
        Kc = KcTeffTable[i - 1][1];
        break;
      }
    }
  }

  return Kc;
}
