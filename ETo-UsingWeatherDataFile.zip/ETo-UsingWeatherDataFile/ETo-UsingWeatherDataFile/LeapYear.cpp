
// https://www.programiz.com/cpp-programming/examples/leap-year

bool LeapYear(int year)
{
  bool result;

  if (year % 4 == 0)
  {
    if (year % 100 == 0)
    {
      if (year % 400 == 0) result = true;
      else result = false;
    }
    else result = true;
  }
  else result = false;

  return result;
}
