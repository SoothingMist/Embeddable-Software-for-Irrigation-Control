
#include "WeatherDataIO.h"
#include "TrimString.h"

double WeatherDataIO::GetHoursOfDaylight(int month) { return hoursSunshinePerDay[month]; }
WeatherDataRecordType WeatherDataIO::GetWeatherRecord() { return thisRecord; }
int WeatherDataIO::GetYear() { return year; }
int WeatherDataIO::GetMonth() { return month; }
int WeatherDataIO::GetDay() { return day; }
WeatherDataIO::~WeatherDataIO() { if(WeatherData.is_open()) WeatherData.close(); }

WeatherDataIO::WeatherDataIO()
{
  year = -1;
  month = -1;
  day = -1;
  numUsableElements = totalNumElements;
  for(size_t i = 0; i < numUsableElements; i++) thisRecord[i] = -999.0;
}
  
bool WeatherDataIO::OpenWeatherDataFile()
{
  // Open the input datafile
  if (WeatherData.is_open()) WeatherData.close();
  WeatherData = ifstream(weatherDataFilename);

  // Check if input file was opened
  if (!WeatherData.is_open())
  {
    cout << "Error opening input file: " << endl << weatherDataFilename << endl;
    return false;
  }

  // Get header line
  if (getline(WeatherData, line))
  {
    // Briefly check header
    if (line.substr(0, 7) != "STN---,")
    {
      cout << "header check: " << line.substr(0, 7) << endl;
      cout << "Incorrect header in first line of input file: " << endl << weatherDataFilename << endl;
      return false;
    }
  }
  else
  {
    cout << "Input file is empty: " << endl << weatherDataFilename << endl;
    return false;
  }

  // Save the full header in case needed later
  header = "Station + WBAN Codes + DateTime (YYYY-MM-DD),Mean Temperature (fahrenheit),Mean Dew Point (fahrenheit),Mean Sea Level Pressure (millibars),Mean Station Pressure (millibars),Mean visibility (miles),Mean Wind Speed (knots),Max Sustained Wind Speed (knots),Max Wind Gust (knots),Max Temperature (fahrenheit),Min Temperature (fahrenheit),Precipitation (inches)";

  // Success
  cout << "Successfully opened and read header line from input file: " << endl << weatherDataFilename << endl;
  return true;
}

bool WeatherDataIO::GetLineWeatherData()
{
  // Process each line of data
  if (getline(WeatherData, line))
  {
    //cout << line << endl;

    size_t index1, index2;
    string elementString;
    string lineID;
    size_t thisElement = 0;

    line = removeAllSpaces(line);

    // Extract the line's Station ID, WBAN code, and YearMonthDay
    index2 = line.find(',');
    index2 = line.find(',', index2 + 1);
    index2 = line.find(',', index2 + 1);
    lineID = line.substr(0, index2);
    lineID = replaceCharacters(lineID, ",", " ");

    // Extract Year, Month, Day as seperate numbers
    index1 = lineID.rfind(" ");
    index1++;
    year = atoi(lineID.substr(index1, 4).c_str());
    index1 += 4;
    month = atoi(lineID.substr(index1, 2).c_str());
    index1 += 2;
    day = atoi(lineID.substr(index1, 2).c_str());

    // Extract the mean temperature
    index1 = index2 + 1;
    index2 = line.find(',', index1);
    elementString = line.substr(index1, index2 - index1);
    if (elementString.find("999.9") != string::npos) thisRecord[thisElement] = NAN;
    else thisRecord[thisElement] = stof(elementString);
    index2 = line.find(',', index2 + 1); // skip the count

    // Extract the mean dew point
    thisElement++;
    index1 = index2 + 1;
    index2 = line.find(',', index1);
    elementString = line.substr(index1, index2 - index1);
    if (elementString.find("999.9") != string::npos) thisRecord[thisElement] = NAN;
    else thisRecord[thisElement] = stof(elementString);
    index2 = line.find(',', index2 + 1); // skip the count

    // Extract the mean sea level pressure
    thisElement++;
    index1 = index2 + 1;
    index2 = line.find(',', index1);
    elementString = line.substr(index1, index2 - index1);
    if (elementString.find("999.9") != string::npos) thisRecord[thisElement] = NAN;
    else thisRecord[thisElement] = stof(elementString);
    index2 = line.find(',', index2 + 1); // skip the count

    // Extract the mean station pressure
    thisElement++;
    index1 = index2 + 1;
    index2 = line.find(',', index1);
    elementString = line.substr(index1, index2 - index1);
    if (elementString.find("999.9") != string::npos) thisRecord[thisElement] = NAN;
    else thisRecord[thisElement] = stof(elementString);
    index2 = line.find(',', index2 + 1); // skip the count

    // Extract the mean visibility
    thisElement++;
    index1 = index2 + 1;
    index2 = line.find(',', index1);
    elementString = line.substr(index1, index2 - index1);
    if (elementString.find("999.9") != string::npos) thisRecord[thisElement] = NAN;
    else thisRecord[thisElement] = stof(elementString);
    index2 = line.find(',', index2 + 1); // skip the count

    // Extract the mean wind speed
    thisElement++;
    index1 = index2 + 1;
    index2 = line.find(',', index1);
    elementString = line.substr(index1, index2 - index1);
    if (elementString.find("999.9") != string::npos) thisRecord[thisElement] = NAN;
    else thisRecord[thisElement] = stof(elementString);
    index2 = line.find(',', index2 + 1); // skip the count

    // Extract max sustained wind speed
    thisElement++;
    index1 = index2 + 1;
    index2 = line.find(',', index1);
    elementString = line.substr(index1, index2 - index1);
    if (elementString.find("999.9") != string::npos) thisRecord[thisElement] = NAN;
    else thisRecord[thisElement] = stof(elementString);

    // Extract max wind gust
    thisElement++;
    index1 = index2 + 1;
    index2 = line.find(',', index1);
    elementString = line.substr(index1, index2 - index1);
    if (elementString.find("999.9") != string::npos) thisRecord[thisElement] = NAN;
    else thisRecord[thisElement] = stof(elementString);

    // Extract max temperature
    // Note the removal of the possible flag
    thisElement++;
    index1 = index2 + 1;
    index2 = line.find(',', index1);
    elementString = line.substr(index1, index2 - index1);
    if (!isdigit((elementString.substr(elementString.size() - 1, 1).c_str())[0]))
      elementString = elementString.substr(0, elementString.size() - 1);
    if (elementString.find("999.9") != string::npos) thisRecord[thisElement] = NAN;
    else thisRecord[thisElement] = stof(elementString);

    // Extract min temperature
    // Note the removal of the possible flag
    thisElement++;
    index1 = index2 + 1;
    index2 = line.find(',', index1);
    elementString = line.substr(index1, index2 - index1);
    if (!isdigit((elementString.substr(elementString.size() - 1, 1).c_str())[0]))
      elementString = elementString.substr(0, elementString.size() - 1);
    if (elementString.find("999.9") != string::npos) thisRecord[thisElement] = NAN;
    else thisRecord[thisElement] = stof(elementString);

    // Extract precipitation
    thisElement++;
    index1 = index2 + 1;
    index2 = line.find(',', index1);
    elementString = line.substr(index1, index2 - index1);
    if ((elementString.find("999.9") != string::npos) || (elementString.find("99.99") != string::npos))
    {
      thisRecord[thisElement] = 0.0; // in this case, non-reporting often means nothing to report, thus 0.0
    }
    else thisRecord[thisElement] = stof(elementString.substr(0, elementString.length() - 1)); // remove flag

    // Have successfully extracted this record's data elements
    return true;
  }
  else
  {
    cout << "No more data in file" << endl;
    return false;
  }
}
