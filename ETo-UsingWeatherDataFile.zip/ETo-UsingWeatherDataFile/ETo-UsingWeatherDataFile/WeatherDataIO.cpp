
#include <sstream>
#include "WeatherDataIO.h"

double WeatherDataIO::GetStationLatitude() { return thisRecord[LATITUDE]; };
double WeatherDataIO::GetStationElevation() { return thisRecord[ELEVATION]; };
double WeatherDataIO::GetHoursOfDaylight(int month) { return hoursSunshinePerDay[month]; }
WeatherDataRecordType WeatherDataIO::GetWeatherRecord() { return thisRecord; }
int WeatherDataIO::GetYear() { return (int)thisRecord[YEAR]; }
int WeatherDataIO::GetMonth() { return (int)thisRecord[MONTH]; }
int WeatherDataIO::GetDay() { return (int)thisRecord[DAY]; }
WeatherDataIO::~WeatherDataIO() { if(WeatherData.is_open()) WeatherData.close(); }

WeatherDataIO::WeatherDataIO()
{
  for(size_t i = 0; i < numAttributes; i++) thisRecord[i] = NAN;
}
  
bool WeatherDataIO::OpenWeatherDataFile()
{
  // Open the input datafile
  if (WeatherData.is_open()) WeatherData.close();
  WeatherData = ifstream(weatherDataFilename);

  // Check if input file was opened
  if (!WeatherData.is_open())
  {
    cout << "Error opening input file: " << endl << weatherDataFilename << endl;
    return false;
  }

  // Get header line
  if (getline(WeatherData, header))
  {
    // Briefly check header
    if (header.substr(0, 7) != "STATION")
    {
      cout << "header check: " << header.substr(0, 7) << endl;
      cout << "Incorrect header in first line of input file: " << endl << weatherDataFilename << endl;
      return false;
    }
  }
  else
  {
    cout << "Input file is empty: " << endl << weatherDataFilename << endl;
    return false;
  }

  // Success
  cout << "Successfully opened and read header line from input file: " << endl << weatherDataFilename << endl;
  return true;
}

bool WeatherDataIO::GetLineWeatherData()
{
  // Process each line of data
  if (getline(WeatherData, line))
  {
    //cout << line << endl;

    size_t index1, index2;
    string elementString;

    //line = removeAllSpaces(line);
    stringstream strLine(line);

    // Extract the line's Station ID and dd/mm/yyyy
    getline(strLine, elementString, ',');

    // Extract Year, Month, Day as seperate numbers
    getline(strLine, elementString, ',');
    index1 = 0;
    index2 = elementString.find("/", index1);
    thisRecord[DAY] = stof(elementString.substr(index1, index2 - index1));
    index1 = index2 + 1;
    index2 = elementString.find("/", index1);
    thisRecord[MONTH]= stof(elementString.substr(index1, index2 - index1));
    index1 = index2 + 1;
    thisRecord[YEAR]= stof(elementString.substr(index1, 4));

    // Extract the station latitude
    getline(strLine, elementString, ',');
    thisRecord[LATITUDE] = stof(elementString);

    // Extract the station longitude
    getline(strLine, elementString, ',');

    // Extract the station elevation
    getline(strLine, elementString, ',');
    thisRecord[ELEVATION] = stof(elementString);

    // Extract the station name
    // There are sometimes commas in the name
    getline(strLine, elementString, ',');
    if (elementString.substr(0, 1) == "\"")
    {
      string extra;
      getline(strLine, extra, ',');
      elementString += extra;
    }

    // Extract the mean temperature
    getline(strLine, elementString, ',');
    if (elementString.find("9999.9") != string::npos) thisRecord[TEMP] = NAN;
    else thisRecord[TEMP] = stof(elementString);

    // Extract mean temperature attribute
    getline(strLine, elementString, ',');

    // Extract the mean dew point
    getline(strLine, elementString, ',');
    if (elementString.find("9999.9") != string::npos) thisRecord[DEWP] = NAN;
    else thisRecord[DEWP] = stof(elementString);

    // Extract mean dew point attribute
    getline(strLine, elementString, ',');

    // Extract the mean sea level pressure
    getline(strLine, elementString, ',');
    if (elementString.find("9999.9") != string::npos) thisRecord[SLP] = NAN;
    else thisRecord[SLP] = stof(elementString);

    // Extract the mean sea level pressure attribute
    getline(strLine, elementString, ',');

    // Extract the mean station pressure
    getline(strLine, elementString, ',');
    if (elementString.find("9999.9") != string::npos) thisRecord[STP] = NAN;
    else thisRecord[STP] = stof(elementString);

    // Extract the mean station pressure attribute
    getline(strLine, elementString, ',');

    // Extract the mean visibility
    getline(strLine, elementString, ',');
    if (elementString.find("999.9") != string::npos) thisRecord[VISIB] = NAN;
    else thisRecord[VISIB] = stof(elementString);

    // Extract the mean visibility attribute
    getline(strLine, elementString, ',');

    // Extract the mean wind speed
    getline(strLine, elementString, ',');
    if (elementString.find("999.9") != string::npos) thisRecord[WDSP] = NAN;
    else thisRecord[WDSP] = stof(elementString);

    // Extract the mean wind speed attribute
    getline(strLine, elementString, ',');

    // Extract max sustained wind speed
    getline(strLine, elementString, ',');
    if (elementString.find("999.9") != string::npos) thisRecord[MXSPD] = NAN;
    else thisRecord[MXSPD] = stof(elementString);

    // Extract max wind gust
    getline(strLine, elementString, ',');
    if (elementString.find("999.9") != string::npos) thisRecord[GUST] = NAN;
    else thisRecord[GUST] = stof(elementString);

    // Extract max temperature
    // Note the removal of the possible flag
    getline(strLine, elementString, ',');
    if (!isdigit((elementString.substr(elementString.size() - 1, 1).c_str())[0]))
      elementString = elementString.substr(0, elementString.size() - 1);
    if (elementString.find("9999.9") != string::npos) thisRecord[MAX] = NAN;
    else thisRecord[MAX] = stof(elementString);

    // Extract max temperature attribute
    getline(strLine, elementString, ',');

    // Extract min temperature
    // Note the removal of the possible flag
    getline(strLine, elementString, ',');
    if (!isdigit((elementString.substr(elementString.size() - 1, 1).c_str())[0]))
      elementString = elementString.substr(0, elementString.size() - 1);
    if (elementString.find("9999.9") != string::npos) thisRecord[MIN] = NAN;
    else thisRecord[MIN] = stof(elementString);

    // Extract min temperature attribute
    getline(strLine, elementString, ',');

    // Extract precipitation
    getline(strLine, elementString, ',');
    if ((elementString.find("99.99") != string::npos))
      thisRecord[PRCP] = 0.0; // in this case, non-reporting often means nothing to report, thus 0.0
    else thisRecord[PRCP] = stof(elementString);

    // Have successfully extracted this record's data elements
    return true;
  }
  else
  {
    cout << "No more data in file" << endl;
    return false;
  }
}
