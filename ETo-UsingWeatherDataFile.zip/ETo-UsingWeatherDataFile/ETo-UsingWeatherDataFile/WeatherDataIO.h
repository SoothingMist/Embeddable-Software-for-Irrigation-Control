
#ifndef Class_WeatherDataIO
#define Class_WeatherDataIO 

//-------------------------------
// User configuration variables

// The input file containing daily weather data.
// data: https://data.noaa.gov/dataset/dataset/global-surface-summary-of-the-day-gsod
// data details: https://www.ncei.noaa.gov/data/global-summary-of-the-day/doc/readme.txt
//
// This particular station is the National Weather Station in Uvalde Airport, Texas, USA.
// This is the dataset for one growing season.
#define weatherDataFilename "../../WeatherData/72220212985-GrowingSeason.csv"

// Parameters about the weather station.
// Longitude is not required for these calculations.
// Station location and elevation are given either in the GSOD file or at
// ftp://ftp.ncdc.noaa.gov/pub/data/noaa/isd-history.txt
// Latitude units are degrees. Elevation units are meters.
// Positive latitude refers to north. Negative refers to south.
// Positive longitude refers to east. Negative refers to west.
// These values are read from the station's datafile.
// Attribute names come directly from the datafile's header.
enum { DAY, MONTH, YEAR, LATITUDE, ELEVATION, TEMP, DEWP, 
       SLP, STP, VISIB, WDSP, MXSPD, GUST, MAX, MIN, PRCP, numAttributes };
#define WeatherDataRecordType array<double, numAttributes>

// The average hours of sunshine per day in a given month.
// Vector gives data for Months 1..12. Index 0 is unused.
// Source: https://www.weather-atlas.com/en/texas-usa/san-antonio-climate#daylight_sunshine
// Note that we are using hours of sunshine, not hours of daylight.
// Hours of Daylight refers to the lenght of time between sunrise and sunset.
// Hours of Sunshine refers to how long the sun actually shines, relative to cloud 
// cover, fog, and other such obstructions.
static const double hoursSunshinePerDay[13] =
  { 0.0, 6.4, 6.7, 6.5, 7.4, 8.0, 9.3, 10.3, 9.9, 8.4, 7.3, 5.4, 5.3 };


//-------------------------------
// Notes

// Reading text data from file
// https://stackoverflow.com/questions/8365013/reading-line-from-text-file-and-putting-the-strings-into-a-vector

// STL string manipulation
// http://www.cplusplus.com/reference/string/string

// STL two-dimensional arrays
// https://stackoverflow.com/questions/12844475/why-cant-simple-initialize-with-braces-2d-stdarray
// http://cpptruths.blogspot.com/2011/10/multi-dimensional-arrays-in-c11.html

// STL interator example
// http://www.cplusplus.com/reference/list/list/list

// Source of original data
// https://data.noaa.gov/dataset/dataset/global-surface-summary-of-the-day-gsod

// Reading csv files
// https://java2blog.com/read-csv-file-in-cpp/#:~:text=To%20read%20a%20CSV%20file%2C,variable%20as%20its%20second%20argument

//-------------------------------

#include <math.h>

#include <iostream>
#include <fstream>
#include <string>
#include <array>
#include <list>
#include <vector>
using namespace std;

class WeatherDataIO
{

private:

  ifstream WeatherData;
  string line, header;
  WeatherDataRecordType thisRecord;

public:

  double GetStationLatitude();
  double GetStationElevation();
  WeatherDataRecordType GetWeatherRecord();
  bool OpenWeatherDataFile();
  bool GetLineWeatherData();
  int GetYear();
  int GetMonth();
  int GetDay();
  double GetHoursOfDaylight(int month);
  WeatherDataIO();
  ~WeatherDataIO();
};

#endif
