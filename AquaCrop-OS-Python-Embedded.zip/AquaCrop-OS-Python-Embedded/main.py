
#***
# Added this to eliminate "module not found" errors.
# The issues forum says this is adequate but indicates other approaches.
# This particular approach is good but causes the code to run slower.
# Although I have not tested it, my understanding is that this is not necessary in Linux, only Windows.
import os
os.environ['DEVELOPMENT'] = 'DEVELOPMENT'

#***
# Import a class that gets weather data from an external source
import DailyWeatherRecords

from aquacrop import AquaCropModel, Soil, Crop, InitialWaterContent
from aquacrop.utils import prepare_weather, get_filepath

#***
# Can do away with the customary input file if an external weather-data source is used.
# This approach requires the least change to AquaCrop_os' code.
# The use of an external data feed is designed to support only one planting season.
external = False # set to True if an external source of weather data is used
weather_file_path = get_filepath('tunis_climate_shortened.txt')
if external:
  import pandas as pd
  import numpy as np
  DailyWeatherRecords.theseWeatherRecords = DailyWeatherRecords.DailyWeatherRecords(weather_file_path) # get weather records from an external source
  weather_df = pd.DataFrame(np.array([[0.0,0.0,0.0,0.0,pd.Timestamp('1979-10-01 00:00:00')],
                                      [0.0,0.0,0.0,0.0,pd.Timestamp('1980-04-13 00:00:00')]]),
      columns = ['MinTemp', 'MaxTemp', 'Precipitation', 'ReferenceET', 'Date'])
else:
  weather_df = prepare_weather(weather_file_path) # get weather records from a customary internal source

model_os = AquaCropModel(
            sim_start_time=f"{1979}/10/01",
            sim_end_time=f"{1980}/04/13",

            #***
            # weather_df value set above.
            #weather_df=prepare_weather(weather_file_path),
            weather_df = weather_df,

            soil=Soil(soil_type='SandyLoam'),
            crop=Crop('Wheat', planting_date='10/01', harvest_date='04/13'),
            initial_water_content=InitialWaterContent(value=['FC']),
        )

model_os.run_model(till_termination=True)
model_results = model_os.get_simulation_results().head()
#all_results = model_os.get_simulation_results().all()
print(model_results)
