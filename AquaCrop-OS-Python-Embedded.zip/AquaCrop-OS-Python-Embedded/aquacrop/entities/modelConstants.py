"""
    Constants Class
"""


class ModelConstants:
    """
        This class is responsible for storing the constant parameters
    of the model.

    TODO: Add all the constants to this class
    """

    NO_VALUE = -999
