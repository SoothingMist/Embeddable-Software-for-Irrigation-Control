
#***
# Facilitates external sources of weather data.

import pandas as pd
import numpy as np
import os

# A global variable which provides a pointer to a DailyWeatherRecords object.
# Initialized at None. Can then be set to point to that object if an external source
# of weather records is needed.
theseWeatherRecords = None

# For testing. Sums daily irrigation.
totalDailyIrrigation = 0

# Class for extracting weather data from an external source
class DailyWeatherRecords:
  def __init__(self, filename):
    if os.path.exists(filename):
      self._filename = filename
      self._weatherFile = open(filename, "rt")
      self._weatherFile.readline() # first record is the header
    else:
      self._weatherFile = None
      print("Weather file does not exist: " + filename)

  def GetNextRecord(self):
    if self._weatherFile is not None:
      thisRecord = self._weatherFile.readline()
      if thisRecord:
        thisRecord = thisRecord[0: len(thisRecord) - 1]
        values = thisRecord.split('\t')
        AquaCrop_os = \
          np.array([float(values[3]), float(values[4]), float(values[5]),
                    float(values[6]),
                    pd.Timestamp(values[2] + '-' + values[1] + '-' + values[0] + ' 00:00:00')])
        return AquaCrop_os
      else:
        print("No more records in " + self._filename)
        return None
    else:
      print("Weather file does not exist: " + self._filename)
      return None

  def __del__(self):
    if self._weatherFile is not None:
      self._weatherFile.close()
      self._weatherFile = None
