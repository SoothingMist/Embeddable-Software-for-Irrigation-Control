
// Server side C/C++ program to demonstrate irrigator activation.
// This is a Linux Server.

// https://www.geeksforgeeks.org/socket-programming-cc
// https://opensource.com/article/19/4/interprocess-communication-linux-networking

// Runs under Cygwin and on BeagleBone.

// Cygwin:
// cd "/cygdrive/d/Paper - Precision Irrigation/NetworkConnections/LinuxNetworking"
// BeagleBone:
// cd /media/microSD

// g++ ControlIrrigatorLED.cpp -o ControlIrrigatorLED.exe
// ./ControlIrrigatorLED.exe

#include <unistd.h>
#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>

#include<iostream>
#include<fstream>
#include<string>
using namespace std;

#define DEFAULT_BUFLEN 512
#define DEFAULT_PORT 27015
#define MAX_CONNECTS 1
const int MAX_MESSAGE_LENGTH = DEFAULT_BUFLEN - 2;

//===================== For controlling the LED ====================
//
// Ref: http://derekmolloy.ie/beaglebone-controlling-the-on-board-leds-using-c
//
// Assuming pump delivers 1mm water per second

// Select the LED to use
#define LED0_PATH "/sys/class/leds/beaglebone:green:usr0"

// Define a filestream for communicating with the LED
fstream fs;

void removeTrigger()
{
   // remove the trigger from the LED
   std::fstream fs;
   fs.open( LED0_PATH "/trigger", std::fstream::out);
   fs << "none";
   fs.close();
}

void turnOffLED()
{
	removeTrigger();
	fs.open (LED0_PATH "/brightness", std::fstream::out);
	fs << "0";
	fs.close();
}

void turnOnLED()
{
	removeTrigger();
	fs.open (LED0_PATH "/brightness", std::fstream::out);
	fs << "1";
	fs.close();
}



int main(int argc, char const *argv[])
{
  // ========================== Set Up Socket Connection ============================

  int server_fd, new_socket, valread;
  struct sockaddr_in address;
  int opt = 1;
  int addrlen = sizeof(address);
  char messageBuffer[DEFAULT_BUFLEN];
  messageBuffer[0] = '\0';

  // Creating socket file descriptor
  if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0)
  {
          perror("socket failed");
          exit(EXIT_FAILURE);
  }

  // Forcefully attaching socket to DEFAULT_PORT
  if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)))
  {
          perror("setsockopt");
          exit(EXIT_FAILURE);
  }
  address.sin_family = AF_INET;
  address.sin_addr.s_addr = INADDR_ANY;
  address.sin_port = htons( DEFAULT_PORT );

  // Forcefully attaching socket to DEFAULT_PORT
  if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0)
  {
          perror("bind failed");
          exit(EXIT_FAILURE);
  }
  printf("Server Ready. Waiting for connection.\n");
  if (listen(server_fd, MAX_CONNECTS) < 0)
  {
          perror("listen");
          exit(EXIT_FAILURE);
  }
  if ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen)) < 0)
  {
          perror("accept");
          exit(EXIT_FAILURE);
  } 

  // =========================================================================

  // Wait for first message. Then confirm receipt.
  valread = read(new_socket, messageBuffer, MAX_MESSAGE_LENGTH);
  messageBuffer[valread] = '\0';
  printf("%s\n", messageBuffer); fflush(stdout);
  strcpy(messageBuffer, "connection confirmed");
  send(new_socket, messageBuffer, strlen(messageBuffer), 0);
  printf("Confirmation message sent\n");

  // Receive and act on messages.
  // When "FINISHED" received, break.
  double waterNeeded_mm;
  int activateIrrigator;
  while(true)
  {
      valread = read(new_socket, messageBuffer, MAX_MESSAGE_LENGTH);
    messageBuffer[valread] = '\0';
    if(strcmp(messageBuffer, "FINISHED") == 0) break;
    waterNeeded_mm = atof(messageBuffer);
    printf("%lf mm water needed\n", waterNeeded_mm); fflush(stdout);
    // Making assumption that each mm requires 1 ms to deliver
    activateIrrigator = (int)(waterNeeded_mm + 0.5);
    // Turn LED on to simulate irrigator activation for a given length of time
    turnOnLED();
    // https://www.softwaretestinghelp.com/cpp-sleep
    sleep(activateIrrigator);
    turnOffLED();
    sprintf(messageBuffer, "%i", activateIrrigator);
    send(new_socket, messageBuffer, strlen(messageBuffer), 0);
  }

  // Close socket. Halt program.
  printf("%s\n", "FINISHED message encountered"); fflush(stdout);
  close(DEFAULT_PORT);
  return 0;
}
