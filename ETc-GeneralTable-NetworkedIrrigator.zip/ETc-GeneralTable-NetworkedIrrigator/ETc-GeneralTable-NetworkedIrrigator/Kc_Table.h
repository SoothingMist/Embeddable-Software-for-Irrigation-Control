#pragma once
#include <iostream>
using namespace std;

class Kc_Table
{
public:
  Kc_Table();
  ~Kc_Table();
  double GetCropDailyWaterNeed();
  double GetAverageReportedETo();
  double DetermineKc(double daysAfterPlanting, double meanWindSpeedMS, double minRH);

private:

  // Originally used for testing purposes.
  FILE* consoleOutput;

  // Specification for interpolation tables.
  // tableWidth is the number of columns.
  // DAP: days after planting.
  // y is either a given Kc or crop-height, depending on the table.
  enum { DAP, y, slope, tableWidth };

  // Growth Phases.
  // Nomenclature comes from Table 11.
  enum { initial, developmental, middle, late, numGrowthPhases };

  double cropDailyWaterNeed;
  double averageReportedETo;
  double Fw; // partial field wetting value

  void CalculateSlopes(double *table, int numGrowthPhases);
  double Interpolate(double* table, int numGrowthPhases, double daysAfterPlanting);

  // ============== Begin Configuration Variables ====================

  // These tables are for Maize (grain) grown in East Africa.

  // Look-up table for Kc relative to the number of days after planting.
  // There is the implied assumption that days-after-planting relates to crop stage.
  // That may or may not be the case in a specific circumstance.
  // That is where human-supervision comes in. The farmer should adjust for crop stage.
  // This version of the code does not allow for that but that would not be impossible
  // to implement if a human-oriented data interface were provided. We are not there yet.
  //
  // Calculating Kc at different crop stages based on generalized tables from the baseline document.
  // Tables 11 and 12 are employed.
  // There is the implied assumption that days-after-planting relates to crop stage.
  // That may or may not be the case in a specific circumstance.
  // That is where human-supervision comes in. The farmer should adjust for crop stage.
  // This version of the code does not allow for that but that would not be impossible
  // to implement if a human-oriented data interface were provided. We are not there yet.
  //
  // We use Maize Field Grain since that also is also an important crop in Ethiopia.
  // Tables 11 and 12 do not have values for Teff.
  //
  // The Kc table's basic format is fixed:
  // days after planting, Kc, slope
  // (slope entered as 0.0 since it is calculated by the class constructor)
  // See Fig 34, p 126 for how to get Kc values by combining Table 12, Page 110, and Table 11, Page 104.
  // An implied assumption is that the crop is harvested after the total growth period.
  double KcTableValues[numGrowthPhases + 1][tableWidth] =
  {
      0.0, 0.3, 0.0, // Kc init from Table 12
     30.0, 0.3, 0.0, // Kc init
     80.0, 1.2, 0.0, // Kc mid
    140.0, 1.2, 0.0, // Kc mid
    180.0, 0.6, 0.0  // Kc end
  };

  // Typical crop height in meters at various growth stages.
  // Derived from Figure 1,
  // https://www.researchgate.net/publication/258104207_Influence_of_Plant_Population_and_Nitrogen-Fertilizer_at_Various_Levels_on_Growth_and_Growth_Efficiency_of_Maize/figures?lo=1
  // Their graph is for 260cm max crop height.
  // A disparity here is that the growth table, Table 11, uses four growth periods over 180 days.
  // The link above uses five growth periods over 120 days. Clearly, local information on the crop is needed.
  // Since there is no height data in the baseline document, we use the chart in the link as best we can.
  // The software will adapt to whatever table values are used.
  // Format: DAP, Estimated Crop Height, Slope
  // (slope entered as 0.0 since it is calculated by the class constructor)
  double cropHeightTableValues[numGrowthPhases + 1][tableWidth] =
  {
      0.0, 0.0, 0.0, // always zero
     30.0, 0.9, 0.0, // initial
     80.0, 1.7, 0.0, // developmental
    140.0, 1.9, 0.0, // middle
    180.0, 2.0, 0.0  // late; max crop height; DAP here should be the same as DAP in the last row of the Kc table
  };
};
