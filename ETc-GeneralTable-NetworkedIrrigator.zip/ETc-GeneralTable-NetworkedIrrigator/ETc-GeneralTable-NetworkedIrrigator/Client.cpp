// Client.cpp 
//

#include "Client.h"

Client::Client(const char* address, const char* port)
{
  // Initialize class attributes.
  // MSVS will say "hints" is not initialized.
  // That is taken care of in connectToServer.
  ConnectSocket = INVALID_SOCKET;
  result = NULL;
  ptr = NULL;
  recvbuflen = DEFAULT_BUFLEN;
  MAX_BUFFER = DEFAULT_BUFLEN - 1;
  recvbuf[0] = '\0';
  sendbuf = NULL;
  isConnected = false;

  if ((address != NULL) && (port != NULL))
  {
    strcpy(serverAddress, address);
    strcpy(serverPort, port);
  }
  else if ((address == NULL) && (port == NULL))
  {
    strcpy(serverAddress, DEFAULT_ADDRESS);
    strcpy(serverPort, DEFAULT_PORT);
  }
  else
  {
    printf("Error in Client parameters. Both parameters (server, port) have to be ");
    printf("either NULL or contain a valid const char.\n");
    return;
  }

  connectToServer();
}

bool Client::checkConnection() { return isConnected; }

bool Client::sendMessage(char *sendbuf)
{
  // Send an initial buffer
  iResult = send(ConnectSocket, sendbuf, (int)strlen(sendbuf), 0);
  if (iResult == SOCKET_ERROR)
  {
    printf("send failed with error: %d\n", WSAGetLastError());
    closesocket(ConnectSocket);
    WSACleanup();
    return false;
  }

  //printf("Bytes Sent: %ld\n", iResult);
  return true;
}

int Client::receiveMessage(char receivedMessage[DEFAULT_BUFLEN])
{
  receivedMessage[0] = '\0';
  {
    iResult = recv(ConnectSocket, recvbuf, recvbuflen, 0);
    if (iResult > 0)
    {
      if (iResult < DEFAULT_BUFLEN) recvbuf[iResult] = '\0';
      //printf("Client Received %d Bytes\n", iResult);
      //printf("Client Received Message: %s\n", recvbuf);
      strcpy(receivedMessage, recvbuf);
    }
    else if (iResult != 0) printf("recv failed with error: %d\n", WSAGetLastError());
  }
  return iResult;
}

Client::~Client()
{
  printf("\n=======================================\n");
  printf("Client attempting to close connection to server: %s:%s\n",
    serverAddress, serverPort);
  // shutdown the connection since no more data will be sent
  char message[] = "FINISHED";
  sendMessage(message);
  iResult = shutdown(ConnectSocket, SD_SEND);

  // cleanup
  closesocket(ConnectSocket);
  WSACleanup();
  
  // Check for error
  if (iResult == SOCKET_ERROR)
  {
    printf("shutdown failed with error: %d\n", WSAGetLastError());
    printf("Client failed attempt to close connection to server: %s:%s\n",
      serverAddress, serverPort);
  }
  else
    printf("Client successfully closed connection to server: %s:%s\n",
      serverAddress, serverPort);
  printf("=======================================\n");
}

void Client::connectToServer()
{
  printf("\n=======================================\n");
  printf("Client attempting to connect to server: %s:%s\n",
    serverAddress, serverPort);

  // Initialize Winsock
  iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
  if (iResult != 0) printf("WSAStartup failed with error: %d\n", iResult);

  ZeroMemory(&hints, sizeof(hints));
  hints.ai_family = AF_UNSPEC;
  hints.ai_socktype = SOCK_STREAM;
  hints.ai_protocol = IPPROTO_TCP;

  // Resolve the server address and port
  iResult = getaddrinfo(serverAddress, serverPort, &hints, &result);
  if (iResult != 0) printf("getaddrinfo failed with error: %d\n", iResult);

  // Attempt to connect to an address until one succeeds
  for (ptr = result; ptr != NULL; ptr = ptr->ai_next)
  {
    // Create a SOCKET for connecting to server
    ConnectSocket =
      socket(ptr->ai_family, ptr->ai_socktype, ptr->ai_protocol);
    if (ConnectSocket == INVALID_SOCKET)
      printf("socket failed with error: %ld\n", WSAGetLastError());

    // Connect to server.
    iResult = connect(ConnectSocket, ptr->ai_addr, (int)ptr->ai_addrlen);
    if (iResult == SOCKET_ERROR)
    {
      closesocket(ConnectSocket);
      ConnectSocket = INVALID_SOCKET;
      continue;
    }
    break;
  }

  freeaddrinfo(result);

  if (ConnectSocket == INVALID_SOCKET)
  {
    printf("Unable to connect to server!\n");

    WSACleanup();
    printf("Client failed to connect to server: %s:%s\n",
      serverAddress, serverPort);
  }
  else
  {
    printf("Client successfully connected to server: %s:%s\n",
      serverAddress, serverPort);
    isConnected = true;
  }

  printf("=======================================\n");
}
