
// Disables security warnings
// https://stackoverflow.com/questions/16883037/remove-secure-warnings-crt-secure-no-warnings-from-projects-by-default-in-vis
// With new Visual Studio, also had to set SDL Checks to No (/sdl-) and Warning Level to 2 (/W2)
#define _CRT_SECURE_NO_WARNINGS

#pragma once

// Client code originated here:
// https://docs.microsoft.com/en-us/windows/win32/winsock/finished-server-and-client-code

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdlib.h>
#include <stdio.h>

// Need to link with Ws2_32.lib, Mswsock.lib, and Advapi32.lib
#pragma comment (lib, "Ws2_32.lib")
#pragma comment (lib, "Mswsock.lib")
#pragma comment (lib, "AdvApi32.lib")

#define DEFAULT_BUFLEN 512
#define DEFAULT_PORT "27015"

// Network address for server running on localhost
#define DEFAULT_ADDRESS "127.0.0.1"
// Network address for server running on BeagleBone
//#define DEFAULT_ADDRESS "192.168.7.2"

class Client
{

private:
  bool isConnected;
  WSADATA wsaData;
  SOCKET ConnectSocket;
  struct addrinfo *result, *ptr, hints;
  const char *sendbuf;
  char recvbuf[DEFAULT_BUFLEN];
  char serverAddress[DEFAULT_BUFLEN];
  char serverPort[DEFAULT_BUFLEN];
  int iResult;
  int recvbuflen;
  int MAX_BUFFER;
  void connectToServer();

public:
  Client(const char *address, const char *port);
  ~Client();
  bool checkConnection();
  int receiveMessage(char receivedMessage[DEFAULT_BUFLEN]);
  bool sendMessage(char* messageText);
};
